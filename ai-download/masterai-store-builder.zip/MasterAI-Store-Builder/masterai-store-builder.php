<?php
/**
 * Plugin Name: MasterAI Store Builder
 * Plugin URI: https://wordpress.org/plugins/masterai-store-builder
 * Description: One-click WooCommerce setup with industry-specific templates. Launch your online store in minutes!
 * Version: 1.0.0
 * Author: Sushil Mohan
 * Author URI: https://profiles.wordpress.org/masterai/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: masterai-store-builder
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 * WC tested up to: 8.5
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define plugin constants
define('MasterAI_VERSION', '1.0.0');
define('MasterAI_PLUGIN_FILE', __FILE__);
define('MasterAI_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MasterAI_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MasterAI_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main MasterAI Class
 */
final class MasterAI_Builder
{

    /**
     * Single instance of the class
     */
    protected static $_instance = null;



    /**
     * Main Instance
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->init_hooks();
        $this->includes();
        $this->init();
    }

    /**
     * Hook into actions and filters
     */
    private function init_hooks()
    {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        add_action('masterai_builder_deferred_install_demo_content', array('MasterAI_Installer', 'run_demo_import'));

        add_action('plugins_loaded', array($this, 'check_dependencies'), 11);
        add_action('admin_notices', array($this, 'admin_notices'));

        // HPOS Compatibility
        add_action('before_woocommerce_init', function () {
            if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
                \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
            }
        });
    }

    /**
     * Include required files
     */
    private function includes()
    {
        // Core classes
        require_once MasterAI_PLUGIN_DIR . 'includes/class-masterai-installer.php';
        require_once MasterAI_PLUGIN_DIR . 'includes/class-masterai-onboarding.php';
        require_once MasterAI_PLUGIN_DIR . 'includes/class-masterai-template-manager.php';
        require_once MasterAI_PLUGIN_DIR . 'includes/class-masterai-demo-importer.php';
        require_once MasterAI_PLUGIN_DIR . 'includes/class-masterai-theme-customizer.php';
        require_once MasterAI_PLUGIN_DIR . 'includes/class-masterai-ajax.php';
        require_once MasterAI_PLUGIN_DIR . 'includes/class-masterai-order-overlay.php';



        // Admin
        if (is_admin()) {
            require_once MasterAI_PLUGIN_DIR . 'includes/class-masterai-admin.php';
            MasterAI_Admin::instance();
        }

        // Industrial Filter (Conditional Include)
        require_once MasterAI_PLUGIN_DIR . 'includes/class-masterai-industrial-filter.php';
        MasterAI_Industrial_Filter::init();
    }

    /**
     * Initialize the plugin
     */
    private function init()
    {
        // Initialize classes
        MasterAI_Ajax::instance();
        MasterAI_Order_Overlay::instance();




    }



    /**
     * Check if WooCommerce is active
     */
    public function check_dependencies()
    {
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            return false;
        }
        return true;
    }

    /**
     * WooCommerce missing notice
     */
    public function woocommerce_missing_notice()
    {
        $class = 'notice notice-error';
        $message = sprintf(
            /* translators: %s: Plugin install URL */
            __('MasterAI Store Builder requires WooCommerce to be installed and active. <a href="%s">Install WooCommerce</a>', 'masterai-store-builder'),
            admin_url('plugin-install.php?s=woocommerce&tab=search&type=term')
        );
        printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), wp_kses_post($message));
    }

    /**
     * Admin notices
     */
    public function admin_notices()
    {
        // Show setup wizard notice if not completed
        if (!get_option('masterai_builder_onboarding_complete') && current_user_can('manage_options')) {
            $wizard_url = admin_url('admin.php?page=masterai-wizard');
            ?>
            <div class="notice notice-info is-dismissible masterai-setup-notice">
                <p>
                    <strong><?php esc_html_e('Welcome to MasterAI Store Builder!', 'masterai-store-builder'); ?></strong>
                    <?php esc_html_e('Let\'s set up your store in just 5 minutes.', 'masterai-store-builder'); ?>
                    <a href="<?php echo esc_url($wizard_url); ?>" class="button button-primary">
                        <?php esc_html_e('Start Setup Wizard', 'masterai-store-builder'); ?>
                    </a>
                </p>
            </div>
            <?php
        }
    }

    /**
     * Plugin activation
     */
    public function activate()
    {
        // Set default options
        if (!get_option('masterai_builder_version')) {
            update_option('masterai_builder_version', MasterAI_VERSION);
        }

        // Flag for redirect to wizard
        set_transient('masterai_builder_activation_redirect', true, 30);

        // Run installer
        MasterAI_Installer::install();


    }

    /**
     * Plugin deactivation
     */
    public function deactivate()
    {
        // Clean up transients
        delete_transient('masterai_builder_activation_redirect');


    }
}

/**
 * Returns the main instance of MasterAI_Builder
 */
function MasterAI()
{
    return MasterAI_Builder::instance();
}

// Initialize the plugin
MasterAI();
