/**
 * Product URL Importer Scripts
 */
(function ($) {
    'use strict';

    $(document).ready(function () {
        var $btnStart = $('#masterai-start-extraction');
        var $inputUrl = $('#masterai-product-url');
        var productData = {};

        // Step 2 -> Step 3: Start Extraction
        $btnStart.on('click', function () {
            var url = $inputUrl.val();
            if (!url) {
                alert('Please enter a product URL');
                return;
            }

            // Move to Step 3
            $('.masterai-importer-step').removeClass('active');
            $('#masterai-step-3').addClass('active');

            startExtraction(url);
        });

        function startExtraction(url) {
            updateProgress(10);
            console.log('Starting extraction for:', url);

            $.ajax({
                url: masterai_builder_importer.ajax_url,
                type: 'POST',
                data: {
                    action: 'masterai_builder_extract_product',
                    nonce: masterai_builder_importer.nonce,
                    product_url: url
                },
                success: function (response) {
                    console.log('Extraction response:', response);
                    if (response && response.success) {
                        simulateExtraction(response.data);
                    } else {
                        var msg = 'Extraction failed';
                        if (response && response.data && response.data.message) {
                            msg = response.data.message;
                        } else if (response === -1 || response === '0') {
                            msg = 'Security check failed. Please refresh the page.';
                        }
                        alert(msg);
                        $('.masterai-importer-step').removeClass('active');
                        $('#masterai-step-2').addClass('active');
                    }
                },
                error: function (xhr, status, error) {
                    console.error('AJAX Error:', error);
                    console.error('Status:', status);
                    console.error('Response:', xhr.responseText);
                    alert('An error occurred during extraction. Check console for details.');
                    $('.masterai-importer-step').removeClass('active');
                    $('#masterai-step-2').addClass('active');
                }
            });
        }

        function simulateExtraction(data) {
            productData = data;
            var steps = [
                { id: 'masterai-status-title', delay: 1000, progress: 30 },
                { id: 'masterai-status-price', delay: 2000, progress: 50 },
                { id: 'masterai-status-images', delay: 3500, progress: 80 },
                { id: 'masterai-status-desc', delay: 5000, progress: 100 }
            ];

            steps.forEach(function (step) {
                setTimeout(function () {
                    $('#' + step.id).removeClass('pending').addClass('complete');
                    $('#' + step.id + ' .masterai-status-icon').html('<span class="dashicons dashicons-yes"></span>');
                    updateProgress(step.progress);

                    if (step.progress === 100) {
                        setTimeout(function () {
                            showReview();
                        }, 500);
                    }
                }, step.delay);
            });
        }

        function updateProgress(percent) {
            $('#masterai-progress-percent').text(percent + '%');
            $('.masterai-progress-fill').css('width', percent + '%');
        }

        function showReview() {
            $('.masterai-importer-step').removeClass('active');
            $('#masterai-step-4').addClass('active');

            // Populate fields
            $('#masterai-review-title').val(productData.title);
            $('#masterai-review-price').val(productData.price);
            $('#masterai-review-compare-price').val(productData.compare_price);
            $('#masterai-review-description').val(productData.description);

            if (productData.images && productData.images.length > 0) {
                $('#masterai-review-main-image').attr('src', productData.images[0]);

                var thumbsHtml = '';
                productData.images.forEach(function (img) {
                    thumbsHtml += '<img src="' + img + '">';
                });
                $('#masterai-review-thumbs').html(thumbsHtml);
            }

            var specsHtml = '';
            productData.specs.forEach(function (spec) {
                specsHtml += '<li><span class="dashicons dashicons-arrow-right-alt2"></span> ' + spec + '</li>';
            });
            $('#masterai-review-specs').html(specsHtml);
        }

        // Save actions
        $('#masterai-save-draft, #masterai-publish-now').on('click', function () {
            var status = $(this).attr('id') === 'masterai-save-draft' ? 'draft' : 'publish';

            // Collect edited data
            productData.title = $('#masterai-review-title').val();
            productData.price = $('#masterai-review-price').val();
            productData.compare_price = $('#masterai-review-compare-price').val();
            productData.description = $('#masterai-review-description').val();
            productData.category = $('#masterai-review-category').val();

            $(this).prop('disabled', true).text('Processing...');

            $.ajax({
                url: masterai_builder_importer.ajax_url,
                type: 'POST',
                data: {
                    action: 'masterai_builder_import_product',
                    nonce: masterai_builder_importer.nonce,
                    product_data: productData,
                    status: status
                },
                success: function (response) {
                    if (response.success) {
                        alert('Product imported successfully!');
                        window.location.href = response.data.edit_url;
                    } else {
                        alert(response.data.message);
                        $(this).prop('disabled', false).text('Try Again');
                    }
                }
            });
        });

        // Dashboard button click handler
        $(document).on('click', '.masterai-import-btn-dashboard', function (e) {
            e.preventDefault();
            window.location.href = $(this).attr('href');
        });
    });

})(jQuery);
