/**
 * MasterAI Wizard JS
 */

jQuery(document).ready(function ($) {
    'use strict';

    const MasterAIWizard = {
        currentStep: 'welcome',
        selectedIndustry: '',
        selectedThemeName: '',
        aiEnabled: masteraiWizard.ai_enabled || false,
        wizardData: {},

        init: function () {
            this.bindEvents();
            this.initColorPickers();
            //            this.initMediaUploader(); // Replaced by WizardLogoUpload
            WizardLogoUpload.init();
            this.initAI();
            this.initIndustryPreview();
            this.initThemeSelection();
        },

        bindEvents: function () {
            // Theme Selection
            $(document).on('click', '.select-theme-btn', this.handleThemeSelection.bind(this));
            $(document).on('click', '.preview-btn', this.handleThemePreview.bind(this));

            // Theme Upload


            // Skip Theme
            $(document).on('change', '#use_default_theme', this.handleSkipTheme.bind(this));

            // Industry card selection
            $(document).on('click', '.masterai-industry-card', this.selectIndustry.bind(this));

            // Color preset selection
            $(document).on('click', '.color-preset', this.selectColorPreset.bind(this));

            // Navigation buttons
            $(document).on('click', '.masterai-btn-next', this.handleNext.bind(this));
            $(document).on('click', '.masterai-btn-back', this.handleBack.bind(this));

            // Radio card selection
            $(document).on('change', '.masterai-radio-card input[type="radio"]', this.selectRadioCard);

            // Skip wizard


            // Product selection
            $(document).on('change', '.masterai-product-card input[type="checkbox"]', this.toggleProductSelection);

            // Shipping selection
            $(document).on('change', '.masterai-shipping-card input[type="checkbox"]', this.handleShippingSelection);

            // Auto-update domestic shipping label
            $(document).on('change', '#store_country', this.handleCountryChange);

            // Handle browser back button
            window.addEventListener('popstate', (event) => {
                if (event.state && event.state.step) {
                    this.goToStep(event.state.step, false); // false = don't push state
                } else {
                    // Default to welcome or whatever is in URL params
                    const urlParams = new URLSearchParams(window.location.search);
                    const step = urlParams.get('step') || 'welcome';
                    this.goToStep(step, false);
                }
            });

            // Initial load check? (PHP does hiding, but we ensure progress bar matches)
            const urlParams = new URLSearchParams(window.location.search);
            const currentStep = urlParams.get('step') || 'welcome';
            this.updateProgressBar(currentStep);

            // If install step, start auto-install (preview)
            if (currentStep === 'install') {
                this.populateAndShowPreview();
            }

            // Preview Actions
            $(document).on('click', '#masterai-start-install-btn', this.handleStartInstall.bind(this));
            $(document).on('click', '.masterai-btn-back-preview', this.handleBack.bind(this));

            // Navigation via progress bar
            $(document).on('click', '.masterai-progress-bar .step.complete', this.handleStepClick.bind(this));
        },

        handleStepClick: function (e) {
            const $step = $(e.currentTarget);
            const stepKey = $step.data('step');

            // Optional: Add confirmation if user has unsaved changes? 
            // For now, allow direct navigation as it acts like "Back"
            this.goToStep(stepKey);
        },

        handleStartInstall: function (e) {
            e.preventDefault();
            $('#masterai-install-preview').fadeOut(300, () => {
                $('.masterai-install-progress').fadeIn(300);
                this.startInstallation();
            });
        },

        populateAndShowPreview: function () {
            // 1. Gather Data
            const industry = $('#selected_industry').val() || this.selectedIndustry || 'General';
            const theme = $('#selected_theme').val() || 'storefront';
            const isDefault = $('#use_default_theme').is(':checked');
            const themeName = isDefault ? 'Storefront' : (this.selectedThemeName || 'Storefront');

            const storeName = $('#store_name').val() || 'My Store';
            const storeTagline = $('#store_description').val() || ''; // distinct from tagline but okay for preview

            const productsCount = $('input[name="selected_products[]"]:checked').length;

            const country = $('#store_country option:selected').text();
            const currency = $('#store_currency option:selected').text().split(' ')[0]; // Extract code

            // 2. Populate DOM
            $('#preview-store-name').text(storeName);
            $('#preview-tagline').text(storeTagline);

            $('#summary-industry').text(industry.charAt(0).toUpperCase() + industry.slice(1));
            $('#summary-theme').text(themeName);
            $('#summary-products').text(productsCount + ' Products');
            $('#summary-location').text(country + ' (' + currency + ')');

            // Theme Image (using screenshot from theme card if available)
            // Try finding by button data attribute which is reliable
            let themeImgSrc = '';
            const $themeButton = $(`.select-theme-btn[data-theme="${theme}"]`);

            if ($themeButton.length) {
                const $card = $themeButton.closest('.masterai-theme-card');
                themeImgSrc = $card.find('.theme-screenshot img').attr('src');
            }

            // Fallback for Storefront if not found in DOM (e.g. if skipped/hidden)
            if (!themeImgSrc && theme === 'storefront') {
                themeImgSrc = '' + masteraiWizard.assets_url + 'images/theme-placeholder.svg';
            }

            const $previewImg = $('#masterai-theme-preview-img');
            const $previewPlaceholder = $('#masterai-theme-preview-placeholder');

            if (themeImgSrc) {
                $previewImg.attr('src', themeImgSrc);
                $previewImg.show();
                $previewPlaceholder.hide();

                // Handle load error by reverting to placeholder
                $previewImg.off('error').on('error', function () {
                    $(this).hide();
                    $previewPlaceholder.css('display', 'flex'); // using css to enforce flex
                });
            } else {
                $previewImg.hide();
                $previewImg.attr('src', ''); // Clear src
                $previewPlaceholder.css('display', 'flex');
            }

            // Ensure visibility
            $('.masterai-install-progress').hide();
            $('#install-complete').hide();
            $('#masterai-install-preview').show();
        },

        initThemeSelection: function () {
            // Initialize upload handler if media frame exists
            // To be implemented with custom file input or WP media
        },

        // Theme Data for Client-Side Filtering
        themes: {
            'storefront': {
                slug: 'storefront',
                industries: ['all']
            },
            'deli': {
                slug: 'deli',
                industries: ['food-drink', 'health-beauty']
            },
            'boutique': {
                slug: 'boutique',
                industries: ['fashion-apparel', 'jewelry-accessories']
            },
            'electro': {
                slug: 'electro',
                industries: ['electronics-computers']
            }
        },

        updateThemeStep: function () {
            const industryCode = this.selectedIndustry || $('#selected_industry').val();
            const industryData = this.getIndustryData(industryCode);

            // Update Title
            const $heading = $('.masterai-step-theme .masterai-theme-section:first h3');
            if (industryData) {
                $heading.text('Recommended for ' + industryData.title);
            } else {
                $heading.text('Recommended for Your Store');
            }

            // Filter/Reorder Themes
            this.filterThemes(industryCode);
        },

        getIndustryData: function (code) {
            const industryData = {
                'fashion-apparel': { title: 'Fashion & Apparel' },
                'food-drink': { title: 'Food & Beverage' },
                'electronics-computers': { title: 'Electronics & Gadgets' },
                'health-beauty': { title: 'Health & Beauty' },
                'jewelry-accessories': { title: 'Jewelry & Accessories' },
                'home-furniture': { title: 'Home & Decor' },
                // Add mapping for others if needed, referencing initIndustryPreview data
                'digital-goods': { title: 'Digital Products' },
                'art-photography': { title: 'Art & Photography' }
            };
            // Also check the object used in initIndustryPreview if strictly needed
            // but for now this mapping covers the main PHP mock data keys
            return industryData[code];
        },

        filterThemes: function (industry) {
            const self = this;
            const $grid = $('.masterai-theme-grid');
            const $cards = $('.masterai-theme-card');

            // We'll move recommended cards to the FIRST grid (Recommended) and others to second
            const $recGrid = $('.masterai-theme-section:first .masterai-theme-grid');
            const $otherGrid = $('.masterai-theme-section:last .masterai-theme-grid');

            // Detach all cards to Resort
            // Actually, simplest is to just show/hide "Recommended" badge and move them?
            // But the HTML structure has two distinct grids.
            // Let's gather all cards first
            const cardsArray = [];
            $('.masterai-theme-card').each(function () {
                cardsArray.push($(this));
            });

            // Clear grids
            $recGrid.empty();
            $otherGrid.empty();

            cardsArray.forEach($card => {
                const slug = $card.find('.preview-btn').data('theme'); // or select-theme-btn
                const theme = self.themes[slug];
                let isRecommended = false;

                if (theme) {
                    if (theme.industries.includes('all') || theme.industries.includes(industry)) {
                        isRecommended = true;
                    }
                }

                // If Storefront, always recommend if nothing else matches? 
                // Logic: If user selected 'fashion', Boutique is recommended. Storefront is also 'all'.
                // So both go to recommended.

                // Reset badge
                $card.find('.badge-recommended').remove();
                $card.removeClass('recommended');

                if (isRecommended) {
                    $card.addClass('recommended');
                    $card.prepend('<span class="badge-recommended">Recommended</span>');
                    $recGrid.append($card);
                } else {
                    $otherGrid.append($card);
                }
            });

            // Hide "More Options" wrapper if empty?
            if ($otherGrid.children().length === 0) {
                $otherGrid.closest('.masterai-theme-section').hide();
            } else {
                $otherGrid.closest('.masterai-theme-section').show();
            }
        },

        handleThemeSelection: function (e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const theme = $btn.data('theme');

            // Update UI
            $('.masterai-theme-card').removeClass('selected');
            $btn.closest('.masterai-theme-card').addClass('selected');

            // Update hidden input
            $('#selected_theme').val(theme);
            this.selectedThemeName = $btn.closest('.masterai-theme-card').find('h4').text();

            // Uncheck skip option
            $('#use_default_theme').prop('checked', false);

            // Remove validation popover if exists
            $('.masterai-validation-popover').remove();

            // Enable next
            $('.masterai-btn-next').prop('disabled', false);

            // Scroll to next button
            $('html, body').animate({
                scrollTop: $('.masterai-footer').offset().top
            }, 500);
        },

        handleThemePreview: function (e) {
            e.preventDefault();
            const themeSlug = $(e.currentTarget).data('theme');
            let previewImage = $(`.select-theme-btn[data-theme="${themeSlug}"]`)
                .closest('.masterai-theme-card')
                .find('.theme-screenshot img')
                .attr('src');

            if (!previewImage) {
                previewImage = '' + masteraiWizard.assets_url + 'images/theme-placeholder.svg';
            }

            const modalHtml = `
                <div id="masterai-theme-preview-modal" class="masterai-modal-overlay" style="display:flex;">
                    <div class="masterai-wizard-modal full-screen-preview" style=" padding:0; box-shadow:none;">
                        <button class="masterai-modal-close" style="z-index:99999;right:20px; top:20px;" type="button">&times;</button>
                        <div class="masterai-modal-content full-screen-preview" style="margin:0; width:100%; height:100%; border:none; border-radius:0;">
                            <div class="preview-header">
                                 <div class="left-controls" style="display: flex; gap: 15px; align-items: center;">
                                    <h3 style="margin: 0; color: white;">Theme Preview</h3>
                                    <div class="preview-controls">
                                        <button class="device-btn active" data-device="desktop"><span class="dashicons dashicons-desktop"></span></button>
                                        <button class="device-btn" data-device="tablet"><span class="dashicons dashicons-tablet"></span></button>
                                        <button class="device-btn" data-device="smartphone"><span class="dashicons dashicons-smartphone"></span></button>
                                    </div>
                                 </div>
                                <!-- <button type="button" class="button button-primary select-preview-theme" data-theme="${themeSlug}">Use This Theme</button> -->
                            </div>
                            <div class="preview-frame-container desktop">
                                <img src="${previewImage}" alt="${themeSlug} preview" />
                            </div>
                        </div>
                    </div>
                </div>
            `;

            $('body').append(modalHtml);

            // Bind internal modal events
            $('#masterai-theme-preview-modal .masterai-modal-close').on('click', function () {
                $('#masterai-theme-preview-modal').remove();
            });

            $('#masterai-theme-preview-modal .device-btn').on('click', function () {
                const device = $(this).data('device');
                $('.device-btn').removeClass('active');
                $(this).addClass('active');

                const $frame = $('.preview-frame-container img');
                if (device === 'desktop') {
                    $frame.css('width', '100%');
                } else if (device === 'tablet') {
                    $frame.css('width', '768px');
                } else if (device === 'smartphone') {
                    $frame.css('width', '375px');
                }
            });

            $('#masterai-theme-preview-modal .select-preview-theme').on('click', (e) => {
                const slug = $(e.currentTarget).data('theme');
                // Trigger selection on the main card
                $(`.select-theme-btn[data-theme="${slug}"]`).click();
                $('#masterai-theme-preview-modal').remove();
            });
        },



        handleSkipTheme: function (e) {
            if ($(e.currentTarget).is(':checked')) {
                $('#selected_theme').val('storefront'); // Default
                $('.masterai-theme-card').removeClass('selected');
                $('.masterai-btn-next').prop('disabled', false);
                // Remove validation popover if exists
                $('.masterai-validation-popover').remove();
            } else {
                $('#selected_theme').val('');
                if ($('.masterai-theme-card.selected').length === 0) {
                    //$('.masterai-btn-next').prop('disabled', true);
                }
            }
        },

        initIndustryPreview: function () {
            const industryData = {
                fashion: {
                    title: 'Fashion & Apparel',
                    features: [
                        'Size & Color Variations',
                        'Lookbook Gallery',
                        'Product Zoom',
                        'Related Products'
                    ],
                    icon: 'dashicons-admin-customizer'
                },
                food: {
                    title: 'Food & Beverage',
                    features: [
                        'Menu Layouts',
                        'Nutritional Info',
                        'Local Delivery Setup',
                        'Reservation System Ready'
                    ],
                    icon: 'dashicons-food'
                },
                digital: {
                    title: 'Digital Products',
                    features: [
                        'Instant Downloads',
                        'License Key Management',
                        'File Access Control',
                        'Customer Dashboard'
                    ],
                    icon: 'dashicons-download'
                },
                beauty: {
                    title: 'Beauty & Wellness',
                    features: [
                        'Booking Integration',
                        'Before/After Gallery',
                        'Ingredient Lists',
                        'Video Tutorials'
                    ],
                    icon: 'dashicons-heart'
                },
                home: {
                    title: 'Home & Decor',
                    features: [
                        '360 Product View',
                        'Room Visualizer',
                        'Dimensions Guide',
                        'Bundle Offers'
                    ],
                    icon: 'dashicons-admin-home'
                },
                courses: {
                    title: 'Courses & Coaching',
                    features: [
                        'Lesson Dripping',
                        'Student Progress',
                        'Quiz Integration',
                        'Membership Levels'
                    ],
                    icon: 'dashicons-welcome-learn-more'
                },
                handmade: {
                    title: 'Art & Handmade',
                    features: [
                        'Artist Portfolio',
                        'Custom Commissions',
                        'Gallery Layout',
                        'Storytelling Section'
                    ],
                    icon: 'dashicons-art'
                },
                jewelry: {
                    title: 'Jewelry & Accessories',
                    features: [
                        'High-Res Macro Zoom',
                        'Material Selection',
                        'Gift Wrapping Options',
                        'Authenticity Certificate'
                    ],
                    icon: 'dashicons-awards'
                },
                services: {
                    title: 'Services & Bookings',
                    features: [
                        'Appointment Calendar',
                        'Staff Management',
                        'Service Menu',
                        'Deposit Payments'
                    ],
                    icon: 'dashicons-businessman'
                },
                industrial: {
                    title: 'Industrial & Hardware',
                    features: [
                        'Advanced Search',
                        'Tolerance Filter',
                        'Material Guide',
                        'Bulk Pricing'
                    ],
                    icon: 'dashicons-hammer'
                },
                electronics: {
                    title: 'Electronics & Gadgets',
                    features: [
                        'Technical Specs',
                        'Compare Products',
                        'Warranty Info',
                        'Store Pickup'
                    ],
                    icon: 'dashicons-smartphone'
                },
                pets: {
                    title: 'Pet Supplies',
                    features: [
                        'Pet Personality',
                        'Auto-ship',
                        'Ingredient Info',
                        'Vet Consultation'
                    ],
                    icon: 'dashicons-pets'
                }
            };

            const previewModal = $('#masterai-industry-preview-modal');
            const previewTitle = $('#masterai-preview-title');
            const previewList = $('.masterai-preview-features');
            const previewImage = $('.masterai-preview-image span');
            const selectIndustryBtn = $('.masterai-select-industry-btn');
            let currentPreviewIndustry = '';

            // Open Modal
            $(document).on('click', '.view-demo', function (e) {
                e.preventDefault();
                e.stopPropagation(); // Prevent card selection
                const industry = $(this).data('industry');
                currentPreviewIndustry = industry;
                const data = industryData[industry];

                if (data) {
                    previewTitle.text(data.title);
                    const featuresHtml = data.features.map(f =>
                        '<li><span class="dashicons dashicons-yes" style="color:#4caf50; margin-right:8px;"></span>' + f + '</li>'
                    ).join('');
                    previewList.html(featuresHtml);

                    // Update icon placeholder
                    previewImage.attr('class', 'dashicons ' + data.icon).css({
                        'font-size': '60px',
                        'width': '60px',
                        'height': '60px',
                        'color': '#667eea'
                    });

                    previewModal.fadeIn();
                }
            });

            // Close Modal
            $(document).on('click', '.masterai-modal-close', function () {
                previewModal.fadeOut();
            });

            // Select Industry from Modal
            selectIndustryBtn.on('click', function () {
                if (currentPreviewIndustry) {
                    // Find the card and trigger click
                    const $card = $('.masterai-industry-card[data-industry="' + currentPreviewIndustry + '"]');
                    if ($card.length) {
                        $('.masterai-industry-card').removeClass('selected');
                        $card.addClass('selected');
                        $('#selected_industry').val(currentPreviewIndustry);

                        // Manually trigger the selection logic just in case
                        MasterAIWizard.selectedIndustry = currentPreviewIndustry;
                        $('.masterai-btn-next').prop('disabled', false);

                        // Highlight visual feedback
                        $card.css('border-color', '#4caf50');
                        setTimeout(() => {
                            $card.css('border-color', '');
                        }, 500);

                        // Hide modal
                        previewModal.fadeOut();

                        // Auto-advance
                        $('.masterai-btn-next').trigger('click');
                    }
                }
            });

            // Close on outside click
            $(window).on('click', function (e) {
                if ($(e.target).is(previewModal)) {
                    previewModal.fadeOut();
                }
            });
        },

        handleBack: function (e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const prevStep = $btn.data('prev-step');

            if (prevStep) {
                this.goToStep(prevStep);
            } else {
                window.history.back();
            }
        },

        handleShippingSelection: function () {
            const $checkbox = $(this);
            const $card = $checkbox.closest('.masterai-shipping-card');

            if ($checkbox.is(':checked')) {
                $card.addClass('selected');
                $card.find('.shipping-body').css('opacity', '1').css('pointer-events', 'auto');
            } else {
                $card.removeClass('selected');
                $card.find('.shipping-body').css('opacity', '0.5').css('pointer-events', 'none');
            }
        },

        handleCountryChange: function () {
            const countryText = $('#store_country option:selected').text();
            $('.domestic-country').text(countryText);
        },

        selectIndustry: function (e) {
            e.preventDefault();
            const $card = $(e.currentTarget);
            const industry = $card.data('industry');

            // Remove previous selection
            $('.masterai-industry-card').removeClass('selected');

            // Mark as selected
            $card.addClass('selected');

            // Store selection
            this.selectedIndustry = industry;
            $('#selected_industry').val(industry);

            // Remove validation popover if exists
            $('.masterai-validation-popover').remove();

            // Enable next button
            $('.masterai-btn-next').prop('disabled', false);
        },


        selectColorPreset: function (e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const primary = $btn.data('primary');
            const secondary = $btn.data('secondary');

            $('#primary_color').val(primary).trigger('change');
            $('#secondary_color').val(secondary).trigger('change');
        },

        selectRadioCard: function () {
            $('.masterai-radio-card').removeClass('selected');
            $(this).closest('.masterai-radio-card').addClass('selected');
            $('.masterai-btn-next').prop('disabled', false);
        },

        toggleProductSelection: function () {
            const $checkbox = $(this);
            const $card = $checkbox.closest('.masterai-product-card');

            if ($checkbox.is(':checked')) {
                $card.addClass('selected');
            } else {
                $card.removeClass('selected');
            }
        },

        handleNext: function (e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const nextStep = $btn.data('next-step');

            // Validate current step
            if (!this.validateStep()) {
                return;
            }

            // Collect step data
            const stepData = this.collectStepData();

            // Save step data via AJAX if not the install step
            if (nextStep !== 'install') {
                const self = this;
                $btn.prop('disabled', true).addClass('updating-message');

                this.saveStepData(stepData, function () {
                    $btn.prop('disabled', false).removeClass('updating-message');
                    self.goToStep(nextStep);
                }, function (msg) {
                    // On error
                    $btn.prop('disabled', false).removeClass('updating-message');
                    alert('Error saving step: ' + (msg || 'Unknown error'));
                });
            } else {
                // Go to install step
                this.goToStep('install');
            }
        },

        goToStep: function (step) {
            // Hide all steps
            $('.masterai-step-container').hide();

            // Show new step
            const $newStep = $('#step-' + step);
            $newStep.fadeIn(300);

            // Update URL (SPA feel)
            const newUrl = new URL(window.location.href);
            newUrl.searchParams.set('step', step);
            window.history.pushState({ step: step }, '', newUrl);

            // Update Progress Bar
            this.initStoreDescriptionAI();
            this.updateProgressBar(step);

            // Start installation preview if needed
            if (step === 'install') {
                this.populateAndShowPreview();
            }

            // Update theme step if needed
            if (step === 'theme') {
                this.updateThemeStep();
            }

            // Scroll to top
            $('html, body').animate({ scrollTop: 0 }, 300);
        },

        updateProgressBar: function (activeStep) {
            const steps = ['welcome', 'industry', 'theme', 'products', 'details', 'settings', 'install'];
            const activeIndex = steps.indexOf(activeStep);

            $('.masterai-progress-bar .step').each(function () {
                const stepKey = $(this).data('step');
                const index = steps.indexOf(stepKey);

                $(this).removeClass('active complete');

                if (index < activeIndex) {
                    $(this).addClass('complete');
                } else if (index === activeIndex) {
                    $(this).addClass('active');
                }
            });
        },

        validateStep: function () {
            const $step = $('.masterai-step:visible');
            let valid = true;
            let message = '';

            // Industry step
            if ($step.hasClass('masterai-step-industry')) {
                if (!this.selectedIndustry && !$('#selected_industry').val()) {
                    message = 'Please select an industry';
                    valid = false;
                }
            }

            // Theme step
            if ($step.hasClass('masterai-step-theme')) {
                if (!$('#selected_theme').val() && !$('#use_default_theme').is(':checked')) {
                    message = 'Please select a theme';
                    valid = false;
                }
            }

            // Details step
            if ($step.hasClass('masterai-step-details')) {
                const storeName = $('#store_name').val();
                if (!storeName || storeName.trim() === '') {
                    message = 'Please enter a store name';
                    valid = false;
                }
            }

            if (!valid && message) {
                this.showValidationPopover(message, $('.masterai-btn-next:visible'));
            }

            return valid;
        },

        showValidationPopover: function (message, $target) {
            // Remove existing popover
            $('.masterai-validation-popover').remove();

            if (!$target.length) return;

            const $popover = $('<div class="masterai-validation-popover">' + message + '</div>');
            $target.closest('.masterai-next-wrapper').append($popover);

            // Hide after 3 seconds
            setTimeout(() => {
                $popover.fadeOut(300, function () {
                    $(this).remove();
                });
            }, 3000);
        },

        collectStepData: function () {
            const $step = $('.masterai-step:visible');
            let data = {};
            let step = '';

            // Determine current step
            if ($step.hasClass('masterai-step-welcome')) {
                step = 'welcome';
                data = {
                    start_mode: $('input[name="start_mode"]:checked').val()
                };
            } else if ($step.hasClass('masterai-step-industry')) {
                step = 'industry';
                data = {
                    industry: $('#selected_industry').val() || this.selectedIndustry
                };
            } else if ($step.hasClass('masterai-step-theme')) {
                step = 'theme';
                data = {
                    theme: $('#selected_theme').val(),
                    use_default: $('#use_default_theme').is(':checked') ? 1 : 0
                };
            } else if ($step.hasClass('masterai-step-products')) {
                step = 'products';
                var selectedProducts = [];
                $('input[name="selected_products[]"]:checked').each(function () {
                    selectedProducts.push($(this).val());
                });
                data = {
                    selected_products: selectedProducts
                };
            } else if ($step.hasClass('masterai-step-details')) {
                step = 'details';
                data = {
                    store_name: $('#store_name').val(),
                    store_description: $('#store_description').val(),
                    logo_id: $('#logo_id').val(), // ✅ IMPORTANT: Include this
                    logo_width: $('#logo_width').val(),
                    primary_color: $('#primary_color').val(),
                    secondary_color: $('#secondary_color').val()
                };
            } else if ($step.hasClass('masterai-step-settings')) {
                step = 'settings';
                data = {
                    currency: $('#store_currency').val(),
                    country: $('#store_country').val(),
                    offer_physical: $('input[name="offer_physical"]').is(':checked') ? 1 : 0,
                    offer_digital: $('input[name="offer_digital"]').is(':checked') ? 1 : 0,
                    offer_services: $('input[name="offer_services"]').is(':checked') ? 1 : 0,
                    shipping_domestic: $('input[name="shipping_domestic"]').is(':checked') ? 1 : 0,
                    shipping_domestic_rate: $('input[name="shipping_domestic_rate"]').val(),
                    shipping_international: $('input[name="shipping_international"]').is(':checked') ? 1 : 0,
                    shipping_international_rate: $('input[name="shipping_international_rate"]').val()
                };
            }

            return {
                step: step,
                data: data
            };
        },

        saveStepData: function (stepData, callback, errorCallback) {
            $.ajax({
                url: masteraiWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'masterai_builder_save_wizard_step',
                    nonce: masteraiWizard.nonce,
                    step: stepData.step,
                    data: stepData.data
                },
                success: function (response) {
                    if (response.success && callback) {
                        callback();
                    } else {
                        // Fallback: Proceed anyway if just saving data failed but allow nav?
                        // Or alert user?
                        console.error('Save step failed:', response);
                        if (errorCallback) errorCallback(response.data.message);
                        // For now, if save fails, we should usually stop. But for UX, maybe just log and proceed?
                        // Let's enforce callback if it's just a data save error to avoid blocking, 
                        // unless it's critical. 
                        // Actually, sticking to errorCallback is safer.
                    }
                },
                error: function (xhr, status, error) {
                    console.error('AJAX Error:', error);
                    if (errorCallback) errorCallback('Connection error');
                }
            });
        },

        startInstallation: function () {
            const steps = ['theme', 'pages', 'products', 'settings', 'navigation'];
            let currentStepIndex = 0;

            const updateProgress = function (step, status) {
                const $step = $('.progress-step[data-step="' + step + '"]');
                const icon = status === 'complete' ? 'dashicons-yes-alt' : 'dashicons-minus';
                $step.find('.dashicons').removeClass('dashicons-minus dashicons-update-alt').addClass(icon);

                if (status === 'complete') {
                    $step.addClass('complete');
                }
            };

            const processStep = function () {
                if (currentStepIndex >= steps.length) {
                    // Installation complete
                    $('#install-status').text('Installation Complete!');
                    $('#progress-fill').css('width', '100%');
                    $('#progress-percent').text('100');

                    setTimeout(function () {
                        $('#install-complete').fadeIn();
                        $('.masterai-install-progress').fadeOut();
                    }, 1000);
                    return;
                }

                const step = steps[currentStepIndex];
                const progress = ((currentStepIndex + 1) / steps.length) * 100;

                updateProgress(step, 'complete');
                $('#progress-fill').css('width', progress + '%');
                $('#progress-percent').text(Math.round(progress));

                currentStepIndex++;
                setTimeout(processStep, 800); // Simulate step processing
            };

            // Start installation via AJAX
            $.ajax({
                url: masteraiWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'masterai_builder_install_template',
                    nonce: masteraiWizard.nonce
                },
                success: function (response) {
                    if (response.success) {
                        processStep();
                    } else {
                        alert('Installation failed: ' + (response.data.message || 'Unknown error'));
                    }
                },
                error: function () {
                    alert('Installation failed. Please try again.');
                }
            });
        },



        initColorPickers: function () {
            if ($.fn.wpColorPicker) {
                $('.masterai-color-picker').wpColorPicker();
            }
        },

        initMediaUploader: function () {
            let mediaUploader;

            $(document).on('click', '.masterai-upload-logo', function (e) {
                e.preventDefault();

                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }

                mediaUploader = wp.media({
                    title: 'Choose Logo',
                    button: {
                        text: 'Use this logo'
                    },
                    multiple: false
                });

                mediaUploader.on('select', function () {
                    const attachment = mediaUploader.state().get('selection').first().toJSON();
                    $('#logo_id').val(attachment.id);
                    $('.logo-preview').html('<img src="' + attachment.url + '" style="max-width: 100%; max-height: 100%;">');
                    $('.masterai-upload-logo').text('Change Logo');
                    $('.masterai-remove-logo').show();
                });

                mediaUploader.open();
            });

            $(document).on('click', '.masterai-remove-logo', function (e) {
                e.preventDefault();
                $('#logo_id').val('');
                $('.logo-preview').html('<span class="dashicons dashicons-format-image"></span>');
                $('.masterai-upload-logo').text('Upload Logo');
                $(this).hide();
            });

            $('#skip-logo').on('click', function (e) {
                e.preventDefault();
                $('#logo_id').val('');
            });
        },

        initAI: function () {
            // Open Modal
            $(document).on('click', '#masterai-enable-ai', function (e) {
                e.preventDefault();
                $('#masterai-ai-modal').fadeIn();
            });

            // Close Modal
            $(document).on('click', '.masterai-modal-close', function (e) {
                e.preventDefault();
                $('#masterai-ai-modal').fadeOut();
            });

            // Save Key
            $(document).on('click', '#masterai-save-ai-key', function (e) {
                e.preventDefault();
                const key = $('#masterai_builder_gemini_key').val();
                const $btn = $(this);
                $btn.prop('disabled', true).text('Saving...');

                $.ajax({
                    url: masteraiWizard.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'masterai_builder_save_gemini_key',
                        nonce: masteraiWizard.nonce,
                        key: key
                    },
                    success: function (response) {
                        if (response.success) {
                            alert('AI Enabled Successfully!');
                            MasterAIWizard.aiEnabled = true;
                            $('#masterai-ai-modal').fadeOut();
                            $('#masterai-enable-ai').html('<span class="dashicons dashicons-yes"></span> AI Enabled').addClass('enabled');
                        } else {
                            alert('Error: ' + response.data.message);
                        }
                    },
                    complete: function () {
                        $btn.prop('disabled', false).text('Save & Enable');
                    }
                });
            });

            // AI Modal Trigger
            $(document).on('click', '.masterai-ai-modal-trigger', function (e) {
                e.preventDefault();

                if (!MasterAIWizard.aiEnabled) {
                    $('#masterai-ai-modal h2').text('AI Product Writer');
                    $('#masterai-ai-modal p:first').text('To create AI product, add your free Gemini API Key');
                    $('#masterai-ai-modal').fadeIn();
                    return;
                }

                $('#masterai-ai-creation-modal').fadeIn();
                $('#masterai-ai-input-prompt').focus();
            });

            // Close Modal
            $(document).on('click', '.masterai-modal-close', function () {
                $('#masterai-ai-creation-modal').fadeOut();
            });

            // Generate Product
            $(document).on('click', '#masterai-ai-generate-btn', function (e) {
                e.preventDefault();
                const prompt = $('#masterai-ai-input-prompt').val();
                const price = $('#masterai-ai-input-price').val();

                if (!prompt) {
                    alert('Please enter a product name or hint.');
                    return;
                }

                // Show Loading
                $('.masterai-ai-step-input').hide();
                $('.masterai-ai-step-loading').show();
                $('.masterai-ai-step-preview').hide();

                $.ajax({
                    url: masteraiWizard.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'masterai_builder_generate_product',
                        nonce: masteraiWizard.nonce,
                        prompt: prompt,
                        price: price
                    },
                    success: function (response) {
                        if (response.success) {
                            const data = response.data;

                            // Generate Image with Puter.js
                            puter.ai.txt2img(data.title)
                                .then(function (imageElement) {
                                    const imageBase64 = imageElement.src;
                                    data.image_data = imageBase64;

                                    const imageHtml = `<img src="${imageBase64}" alt="${data.title}">`;

                                    const previewHtml = `
                                        <div class="masterai-ai-preview-container">
                                            <div class="masterai-ai-preview-left">
                                                <div class="masterai-ai-preview-card-v2">
                                                    <div class="preview-image-square">
                                                        ${imageHtml}
                                                    </div>
                                                    <div class="card-basic-info">
                                                        <h4>${data.title}</h4>
                                                        <span class="price">${data.price_html || masteraiWizard.currency_symbol + data.price}</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="masterai-ai-preview-right">
                                                <div class="masterai-ai-preview-details">
                                                    <h3>${data.title}</h3>
                                                    <div class="detail-item">
                                                        <span class="label">Price:</span>
                                                        <span class="value">${data.price_html || masteraiWizard.currency_symbol + data.price}</span>
                                                    </div>
                                                    <div class="detail-item">
                                                        <span class="label">Category:</span>
                                                        <span class="value">${data.categories ? data.categories.join(', ') : 'Uncategorized'}</span>
                                                    </div>
                                                    <div class="detail-item description">
                                                        <span class="label">Description:</span>
                                                        <p>${data.description || 'No description generated.'}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    `;

                                    $('.masterai-ai-preview-card').html(previewHtml);
                                    $('#masterai-ai-add-btn').data('product', data);

                                    $('.masterai-ai-step-loading').hide();
                                    $('.masterai-ai-step-preview').show();
                                })
                                .catch(function (error) {
                                    console.error("Puter Image Gen Failed:", error);

                                    const placeholderUrl = `${masteraiWizard.assets_url}images/product-placeholder.svg`;
                                    data.image_data = placeholderUrl;
                                    data.is_placeholder = true;

                                    const imageHtml = `<img src="${placeholderUrl}" alt="${data.title}">`;

                                    const previewHtml = `
                                        <div class="masterai-ai-preview-container">
                                            <div class="masterai-ai-preview-left">
                                                <div class="masterai-ai-preview-card-v2">
                                                    <div class="preview-image-square">
                                                        ${imageHtml}
                                                    </div>
                                                    <div class="card-basic-info">
                                                        <h4>${data.title}</h4>
                                                        <span class="price">${data.price_html || masteraiWizard.currency_symbol + data.price}</span>
                                                    </div>
                                                </div>
                                                <div class="masterai-ai-notice warning" style="margin-top: 15px; font-size: 12px; color: #64748b; background: #f8fafc; padding: 10px; border-radius: 6px; border-left: 3px solid #f59e0b;">
                                                    <span class="dashicons dashicons-warning" style="font-size: 14px; width: 14px; height: 14px;"></span>
                                                    AI Image Generation failed. Using a placeholder.
                                                </div>
                                            </div>
                                            <div class="masterai-ai-preview-right">
                                                <div class="masterai-ai-preview-details">
                                                    <h3>${data.title}</h3>
                                                    <div class="detail-item">
                                                        <span class="label">Price:</span>
                                                        <span class="value">${data.price_html || masteraiWizard.currency_symbol + data.price}</span>
                                                    </div>
                                                    <div class="detail-item">
                                                        <span class="label">Category:</span>
                                                        <span class="value">${data.categories ? data.categories.join(', ') : 'Uncategorized'}</span>
                                                    </div>
                                                    <div class="detail-item description">
                                                        <span class="label">Description:</span>
                                                        <p>${data.description || 'No description generated.'}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    `;

                                    $('.masterai-ai-preview-card').html(previewHtml);
                                    $('#masterai-ai-add-btn').data('product', data);

                                    $('.masterai-ai-step-loading').hide();
                                    $('.masterai-ai-step-preview').show();
                                });

                        } else {
                            alert('Error: ' + (response.data ? response.data.message : 'Unknown error'));
                            $('.masterai-ai-step-loading').hide();
                            $('.masterai-ai-step-input').show();
                        }
                    },
                    error: function () {
                        alert('Server error occurred.');
                        $('.masterai-ai-step-loading').hide();
                        $('.masterai-ai-step-input').show();
                    }
                });
            });

            // Retry
            $(document).on('click', '#masterai-ai-retry-btn', function () {
                $('.masterai-ai-step-preview').hide();
                $('.masterai-ai-step-input').show();
            });

            // Add Product to Grid
            $(document).on('click', '#masterai-ai-add-btn', function () {
                const data = $(this).data('product');
                const $btn = $(this);

                if (data) {
                    $btn.prop('disabled', true).text('Saving...');

                    $.ajax({
                        url: masteraiWizard.ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'masterai_builder_save_product_image',
                            nonce: masteraiWizard.nonce,
                            product_id: data.id,
                            image_data: data.image_data
                        },
                        success: function (response) {
                            if (response.success) {
                                data.image_url = response.data.image_url;
                                MasterAIWizard.appendGeneratedProduct(data);
                                $('#masterai-ai-creation-modal').fadeOut();
                                $('.masterai-ai-step-preview').hide();
                                $('.masterai-ai-step-input').show();
                                $('#masterai-ai-input-prompt').val('');
                                $('#masterai-ai-input-price').val('');
                            } else {
                                alert('Failed to save image: ' + response.data.message);
                            }
                        },
                        complete: function () {
                            $btn.prop('disabled', false).text('Add Product');
                        }
                    });
                }
            });
        },

        initStoreDescriptionAI: function () {
            $(document).on('click', '.masterai-ai-description-btn', function (e) {
                e.preventDefault();
                const $btn = $(this);
                const storeName = $('#store_name').val();
                // Get selected industry from step 2 (hidden input or memory)
                const industry = $('#selected_industry').val() || MasterAIWizard.selectedIndustry;

                if (!storeName) {
                    alert('Please enter a Store Name first.');
                    $('#store_name').focus();
                    return;
                }

                $btn.prop('disabled', true).html('<span class="dashicons dashicons-update masterai-spin"></span> Generating...');
                $('#masterai-ai-description-results').slideUp();

                $.ajax({
                    url: masteraiWizard.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'masterai_builder_generate_store_description',
                        nonce: masteraiWizard.nonce,
                        store_name: storeName,
                        industry: industry
                    },
                    success: function (response) {
                        if (response.success && response.data.descriptions) {
                            let html = '<div class="masterai-ai-suggestions" style="background:#f0f4ff; padding:15px; border-radius:6px; border:1px solid #dbeafe;">';
                            html += '<strong style="display:block; margin-bottom:10px; color:#1e40af;">Suggestions (Click to use):</strong>';
                            html += '<ul style="margin:0; padding-left:20px;">';

                            response.data.descriptions.forEach(desc => {
                                html += `<li style="margin-bottom:8px; cursor:pointer;" class="masterai-ai-suggestion-item"><a>${desc}</a></li>`;
                            });

                            html += '</ul></div>';

                            $('#masterai-ai-description-results').html(html).slideDown();
                        } else {
                            alert('AI Error: ' + (response.data.message || 'Unknown error'));
                        }
                    },
                    error: function () {
                        alert('Connection error. Please try again.');
                    },
                    complete: function () {
                        $btn.prop('disabled', false).html('<span class="dashicons dashicons-superhero"></span> Generate with AI');
                    }
                });
            });

            // Handle selection
            $(document).on('click', '.masterai-ai-suggestion-item', function (e) {
                e.preventDefault();
                const text = $(this).text();
                $('#store_description').val(text).focus();
                $('#masterai-ai-description-results').slideUp();
            });
        },

        appendGeneratedProduct: function (data) {
            const productHtml = `
                <label class="masterai-product-card selected">
                    <input type="checkbox" name="selected_products[]" value="${data.id}" checked>
                    <div class="product-card-content">
                        <div class="product-image">
                            ${data.image_url ?
                    `<img src="${data.image_url}" alt="${data.title}" style="width:100%; height:100%; object-fit:cover; border-radius:8px;">` :
                    `<span class="dashicons dashicons-superhero" style="font-size: 48px; width: 48px; height: 48px; color: #667eea; display: flex; align-items: center; justify-content: center; height: 100%;"></span>`
                }
                        </div>
                        <div class="product-info">
                            <h4>${data.title}</h4>
                            <span class="price">${data.price_html || masteraiWizard.currency_symbol + data.price}</span>
                        </div>
                        <div class="check-icon"><span class="dashicons dashicons-yes"></span></div>
                    </div>
                </label>
            `;
            $('.masterai-products-grid').append(productHtml);
        }
    };

    /**
     * Logo Upload Handler
     */
    var WizardLogoUpload = {

        init: function () {
            this.bindEvents();
        },

        bindEvents: function () {
            $(document).on('click', '.masterai-upload-logo', this.openMediaUploader.bind(this));
            $(document).on('click', '.masterai-remove-logo', this.removeLogo.bind(this));
            $(document).on('input', '#logo_width', this.updateLogoWidth.bind(this));
        },

        updateLogoWidth: function (e) {
            var width = $(e.target).val();
            $('#logo_width_display').text(width + 'px');
            $('#logo-preview img').css('max-width', width + 'px');
        },

        openMediaUploader: function (e) {
            e.preventDefault();

            var self = this;

            // Create media frame
            var frame = wp.media({
                title: 'Select Store Logo',
                button: { text: 'Use this logo' },
                multiple: false,
                library: { type: 'image' }
            });

            // Handle selection
            frame.on('select', function () {
                var attachment = frame.state().get('selection').first().toJSON();
                self.setLogo(attachment);
            });

            // Open frame
            frame.open();
        },

        setLogo: function (attachment) {
            // Set hidden field value
            $('#logo_id').val(attachment.id);

            // Update preview
            var img = $('<img>')
                .attr('src', attachment.url)
                .attr('alt', 'Store Logo')
                .css({
                    'max-width': '150px',
                    'height': 'auto'
                });

            $('#logo-preview').html(img);

            // Update button text
            $('.masterai-upload-logo').text('Change Logo');

            // Show remove button and resizing control
            $('.masterai-remove-logo').show();
            $('.masterai-logo-width-control').slideDown();

            console.log('✅ Logo set:', attachment.id);
        },

        removeLogo: function (e) {
            e.preventDefault();

            // Clear hidden field
            $('#logo_id').val('');

            // Reset preview
            $('#logo-preview').html('<span class="dashicons dashicons-format-image"></span>');

            // Update button text
            $('.masterai-upload-logo').text('Upload Logo');

            // Hide remove button and resizing control
            $('.masterai-remove-logo').hide();
            $('.masterai-logo-width-control').slideUp();

            console.log('❌ Logo removed');
        }
    };

    MasterAIWizard.init();
});
