/**
 * MasterAI Admin JS
 */

jQuery(document).ready(function ($) {
    'use strict';

    console.log('MasterAI Admin JS loaded');

    // Initialize color pickers
    if ($.fn.wpColorPicker) {
        $('.masterai-color-field').wpColorPicker();
    }

    // Remove demo content
    $('#masterai-remove-demo').on('click', function (e) {
        e.preventDefault();

        if (!confirm(masteraiAdmin.strings.confirm_remove_demo)) {
            return;
        }

        const $btn = $(this);
        const originalText = $btn.text();

        $btn.text(masteraiAdmin.strings.removing).prop('disabled', true);

        $.ajax({
            url: masteraiAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'masterai_builder_remove_demo_content',
                nonce: masteraiAdmin.nonce
            },
            success: function (response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message || 'Error removing demo content');
                    $btn.text(originalText).prop('disabled', false);
                }
            },
            error: function () {
                alert('Error removing demo content');
                $btn.text(originalText).prop('disabled', false);
            }
        });
    });

    // Install demo content
    $('#masterai-install-demo').on('click', function (e) {
        e.preventDefault();

        const $btn = $(this);
        const originalText = $btn.text();

        $btn.text(masteraiAdmin.strings.installing || 'Installing...').prop('disabled', true);

        $.ajax({
            url: masteraiAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'masterai_builder_install_demo_content',
                nonce: masteraiAdmin.nonce
            },
            success: function (response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message || 'Error installing demo content');
                    $btn.text(originalText).prop('disabled', false);
                }
            },
            error: function () {
                alert('Error installing demo content');
                $btn.text(originalText).prop('disabled', false);
            }
        });
    });

    // Reset wizard
    $('#masterai-reset-wizard').on('click', function (e) {
        e.preventDefault();

        if (!confirm('Are you sure you want to reset the setup wizard? This will clear all your setup preferences.')) {
            return;
        }

        const $btn = $(this);
        const originalText = $btn.text();

        $btn.text('Resetting...').prop('disabled', true);

        $.ajax({
            url: masteraiAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'masterai_builder_reset_wizard',
                nonce: masteraiAdmin.nonce
            },
            success: function (response) {
                if (response.success) {
                    window.location.href = response.data.redirect;
                } else {
                    alert(response.data.message || 'Error resetting wizard');
                    $btn.text(originalText).prop('disabled', false);
                }
            },
            error: function () {
                alert('Error resetting wizard');
                $btn.text(originalText).prop('disabled', false);
            }
        });
    });

    // Dismiss setup notice
    $(document).on('click', '.masterai-setup-notice .notice-dismiss', function () {
        $.post(masteraiAdmin.ajaxurl, {
            action: 'masterai_builder_dismiss_setup_notice',
            nonce: masteraiAdmin.nonce
        });
    });

    // Generate Legal Pages
    $('#masterai-generate-legal-btn').on('click', function (e) {
        e.preventDefault();

        const $btn = $(this);
        const $msg = $btn.next('.masterai-legal-message');
        const originalText = $btn.text();

        $btn.text('Generating...').prop('disabled', true);
        $msg.text('').removeClass('success error');

        $.ajax({
            url: masteraiAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'masterai_builder_generate_legal_pages',
                nonce: masteraiAdmin.nonce
            },
            success: function (response) {
                if (response.success) {
                    $msg.text(response.data.message).addClass('success').css('color', 'green');
                    $btn.text('Generated');
                } else {
                    $msg.text(response.data.message).addClass('error').css('color', 'red');
                    $btn.text(originalText).prop('disabled', false);
                }
            },
            error: function () {
                $msg.text('Error connecting to server.').addClass('error').css('color', 'red');
                $btn.text(originalText).prop('disabled', false);
            }
        });
    });
    // Toggle Industrial Filter
    $('#masterai-toggle-industrial-filter').on('change', function () {
        const isChecked = $(this).is(':checked');

        // Optional: Show saving state

        $.ajax({
            url: masteraiAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'masterai_builder_toggle_industrial_filter',
                nonce: masteraiAdmin.nonce,
                enabled: isChecked ? 1 : 0
            },
            success: function (response) {
                if (response.success) {
                    // console.log('Filter toggled');
                } else {
                    alert(response.data.message || 'Error toggling filter');
                    // Revert checkbox if failed
                    $(this).prop('checked', !isChecked);
                }
            },
            error: function () {
                alert('Error connecting to server');
                $(this).prop('checked', !isChecked);
            }
        });
    });
    // Dashboard Tabs
    $('.masterai-tabs-nav a').on('click', function (e) {
        e.preventDefault();
        var tabId = $(this).attr('href');

        // Hide all tabs
        $('.masterai-tab-content').removeClass('active');
        $('.masterai-tabs-nav li').removeClass('active');

        // Show selected tab
        $(tabId).addClass('active');
        $(this).parent('li').addClass('active');
    });

    // Fetch Exchange Rates
    $('#masterai-fetch-rates').on('click', function (e) {
        e.preventDefault();

        const $btn = $(this);
        const $status = $('#masterai-fetch-rates-status');
        const originalText = $btn.text();

        // Collect enabled currencies from the form
        var enabledCurrencies = {};
        $('input[name^="enabled_currencies"]:checked').each(function () {
            // Extract currency code from name="enabled_currencies[CODE][enabled]"
            var name = $(this).attr('name');
            var match = name.match(/\[([A-Z]{3})\]/);

            if (match && match[1]) {
                var code = match[1];
                var rate = $('input[name="enabled_currencies[' + code + '][rate]"]').val();
                var adjustment = $('input[name="enabled_currencies[' + code + '][adjustment]"]').val();

                enabledCurrencies[code] = {
                    enabled: 1,
                    rate: rate,
                    adjustment: adjustment
                };
            }
        });

        // Also get the API key if entered
        var apiKey = $('#exchange_api_key').val();

        $btn.text('Fetching...').prop('disabled', true);
        $status.text('').removeClass('success error');

        $.ajax({
            url: masteraiAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'masterai_builder_fetch_exchange_rates',
                nonce: masteraiAdmin.nonce,
                enabled_currencies: enabledCurrencies,
                exchange_api_key: apiKey
            },
            success: function (response) {
                if (response.success) {
                    $status.text('✓ Rates updated successfully! Reloading...').css('color', 'green');
                    $btn.text(originalText).prop('disabled', false);

                    // Reload to show new rates
                    setTimeout(function () {
                        location.reload();
                    }, 1500);
                } else {
                    $status.text('✗ ' + (response.data.message || 'Error fetching rates')).css('color', 'red');
                    $btn.text(originalText).prop('disabled', false);
                }
            },
            error: function () {
                $status.text('✗ Error connecting to server').css('color', 'red');
                $btn.text(originalText).prop('disabled', false);
            }
        });
    });
});
