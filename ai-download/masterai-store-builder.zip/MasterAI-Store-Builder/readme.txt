=== MasterAI Store Builder ===
Contributors: masterai
Tags: woocommerce, builder, wizard, onboarding, store
Requires at least: 5.8
Tested up to: 6.9
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Launch your professional WooCommerce store in 5 minutes with industry-specific templates and a streamlined setup wizard.

== Description ==

MasterAI Store Builder is an all-in-one solution designed to help you launch a fully functioning, professional WooCommerce store in minutes. It replaces the complex setup process with a streamlined, intelligent wizard used by thousands of store owners.

**🚀 Key Features:**

*   **5-Minute Setup**: Complete wizard-based installation for new stores.
*   **Industry-Specific Templates**: Professionally designed templates for Fashion, Food, Digital, Beauty, Home, Courses, Handmade, Jewelry, Services, and **Industrial**.
*   **Industrial Mode**: Specialized B2B features including a **product filter for Inner/Outer Diameter & Material**, ideal for parts and hardware stores.
*   **One-Click Demo Content**: Pre-loaded samples to populate your store instantly.
*   **Auto Configuration**: Pages, menus, payments, and shipping settings configured automatically based on your industry.
*   **Simplified Shipping**: Visual setup for Domestic vs. International shipping zones.
*   **Brand Customization**: Apply your logo and brand colors across the entire store instantly.
*   **AI Product Writer**: Generate compelling product titles and descriptions automatically using **Google Gemini AI**.
*   **AI Product Images**: Create unique product mockups on the fly with **Puter.js**.

**💡 Why This Plugin?**

*   **Eliminate Setup Friction**: Skip the technical headaches.
*   **Conversion-First Design**: Layouts designed to sell.
*   **Smart Defaults**: We handle the technical settings so you can focus on business.

**⚠️ External Service Disclosures:**

This plugin relies on several external services to provide its advanced features. By using this plugin, you acknowledge and agree to the use of these services:

1.  **Google Gemini AI**: Used for generating product titles and descriptions. This requires a user-provided API key. [Privacy Policy](https://policies.google.com/privacy)
2.  **Puter.js**: Used for AI-based image generation during the onboarding process. Bundled locally. [Privacy Policy](https://puter.com/privacy)

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/masterai-store-builder` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. The setup wizard will launch automatically to guide you through the process.

== Screenshots ==

1. **Store Setup Wizard** - A clean, step-by-step interface to configure your store.
2. **Industry Selection** - Choose from tailored industry templates.
3. **Product Generation** - Use AI to quickly generate product content.

== Changelog ==

= 1.0.0 =
* Initial release.
