<?php
/**
 * Industrial Industry Template Configuration
 */

return array(
    'name' => 'Industrial & Hardware',
    'slug' => 'industrial',
    'theme' => 'storefront', // Default theme

    'colors' => array(
        'primary' => '#2c3e50', // Dark Blue/Grey
        'secondary' => '#e67e22', // Industrial Orange
    ),

    'pages' => array(
        'about' => 'About Us',
        'contact' => 'Contact Us',
        'technical' => 'Technical Specs',
    ),

    'menu_items' => array(
        'primary' => array(
            'Home',
            'Shop',
            'Technical Specs',
            'About Us',
            'Contact Us',
        ),
        'footer' => array(
            'Shipping & Returns',
            'Privacy Policy',
            'Terms & Conditions',
        ),
    ),

    'widgets' => array(
        'sidebar' => array(
            'woocommerce_product_categories',
            'woocommerce_product_search',
        ),
    ),

    'demo_products_count' => 10,

    'features' => array(
        'industrial_filter' => true,
        'bulk_pricing' => true,
        'technical_specs_tab' => true,
    ),
);
