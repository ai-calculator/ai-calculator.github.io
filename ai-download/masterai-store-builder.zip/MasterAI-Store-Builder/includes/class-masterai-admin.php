<?php
/**
 * MasterAI Admin
 *
 * @package MasterAI_Builder
 */

if (!defined('ABSPATH')) {
    exit;
}

class MasterAI_Admin
{

    /**
     * Single instance
     */
    protected static $_instance = null;

    /**
     * Get instance
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Constructor
     */
    public function __construct()
    {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_menu', array($this, 'reorder_admin_menu'), 999);
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));

        // Initialize onboarding
        new MasterAI_Onboarding();
    }

    /**
     * Reorder admin menu items
     */
    public function reorder_admin_menu()
    {
        global $submenu;

        if (isset($submenu['masterai-dashboard'])) {
            $dashboard_menu = $submenu['masterai-dashboard'];
            $wizard_key = false;
            $wizard_item = null;

            // Find the wizard page
            foreach ($dashboard_menu as $key => $item) {
                if ($item[2] === 'masterai-wizard') {
                    $wizard_key = $key;
                    $wizard_item = $item;
                    break;
                }
            }

            // Move it to the top
            if ($wizard_key !== false && $wizard_item) {
                unset($dashboard_menu[$wizard_key]);

                // We need to preserve keys if possible, but for simple reordering array_values + unshift works
                // or just creating a new array
                $new_menu = array();
                $new_menu[] = $wizard_item;

                foreach ($dashboard_menu as $item) {
                    $new_menu[] = $item;
                }

                $submenu['masterai-dashboard'] = $new_menu;
            }
        }
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu()
    {
        // Main dashboard page
        add_menu_page(
            __('MasterAI', 'masterai-store-builder'),
            __('MasterAI Store Builder', 'masterai-store-builder'),
            'manage_options',
            'masterai-dashboard',
            array($this, 'render_dashboard'),
            'dashicons-store',
            56
        );

        // Submenu items
        add_submenu_page(
            'masterai-dashboard',
            __('Dashboard', 'masterai-store-builder'),
            __('Dashboard', 'masterai-store-builder'),
            'manage_options',
            'masterai-dashboard',
            array($this, 'render_dashboard')
        );

        add_submenu_page(
            'masterai-dashboard',
            __('Demo Content', 'masterai-store-builder'),
            __('Demo Content', 'masterai-store-builder'),
            'manage_options',
            'masterai-demo-content',
            array($this, 'render_demo_content_page')
        );

        add_submenu_page(
            'masterai-dashboard',
            __('Settings', 'masterai-store-builder'),
            __('Settings', 'masterai-store-builder'),
            'manage_options',
            'masterai-settings',
            array($this, 'render_settings_page')
        );
        add_submenu_page(
            'masterai-dashboard',
            __('Upgrade', 'masterai-store-builder'),
            __('Upgrade', 'masterai-store-builder'),
            'manage_options',
            'masterai-upgrade',
            array($this, 'render_upgrade_page')
        );
    }

    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook)
    {
        // Only load on our pages
        if (strpos($hook, 'masterai-') === false && $hook !== 'toplevel_page_masterai-dashboard') {
            return;
        }

        wp_enqueue_style('masterai-admin', MasterAI_PLUGIN_URL . 'assets/css/admin.css', array(), MasterAI_VERSION);
        wp_enqueue_script('masterai-admin', MasterAI_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), MasterAI_VERSION, true);

        // Color picker
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');

        // Media uploader
        wp_enqueue_media();

        // Localize script
        wp_localize_script('masterai-admin', 'masteraiAdmin', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'plugin_url' => MasterAI_PLUGIN_URL,
            'nonce' => wp_create_nonce('masterai-admin'),
            'strings' => array(
                'confirm_remove_demo' => esc_html__('Are you sure you want to remove all demo content? This cannot be undone.', 'masterai-store-builder'),
                'removing' => esc_html__('Removing...', 'masterai-store-builder'),
                'removed' => esc_html__('Demo content removed successfully', 'masterai-store-builder'),
            ),
        ));
    }

    /**
     * Render common admin header with title
     */
    public function render_admin_header($title = '')
    {
        ?>
        <div class="masterai-dashboard-header"
            style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h1 style="margin: 0;"><?php echo esc_html($title); ?></h1>
            <a href="https://productube.gumroad.com/l/MasterAI-WooCommerceStoreLauncher-Pro" target="_blank"
                class="button button-primary"
                style="background-color: #f39c12; border-color: #f39c12; display: flex; align-items: center;">
                <span class="dashicons dashicons-star-filled" style="vertical-align: middle; margin-right: 5px;"></span>
                <?php esc_html_e('Upgrade to Pro', 'masterai-store-builder'); ?>
            </a>
        </div>
        <?php
    }

    /**
     * Render dashboard page
     */
    public function render_dashboard()
    {
        $onboarding_complete = get_option('masterai_builder_onboarding_complete');
        $industry = get_option('masterai_builder_industry');
        $demo_installed = get_option('masterai_builder_demo_content_installed');

        ?>
        <div class="wrap masterai-dashboard">

            <?php $this->render_admin_header(esc_html__('MasterAI Dashboard', 'masterai-store-builder')); ?>

            <?php if (!$onboarding_complete): ?>
                <div class="notice notice-warning">
                    <p>
                        <strong><?php esc_html_e('Setup not complete', 'masterai-store-builder'); ?></strong>
                        <?php esc_html_e('Please complete the setup wizard to get started.', 'masterai-store-builder'); ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=masterai-wizard')); ?>" class="button button-primary">
                            <?php esc_html_e('Continue Setup', 'masterai-store-builder'); ?>
                        </a>
                    </p>
                </div>
            <?php else: ?>

                <div class="masterai-dashboard-layout">
                    <div class="masterai-layout-main">

                        <div class="masterai-welcome-panel">
                            <div class="welcome-panel-content">
                                <div class="masterai-welcome-header-flex"
                                    style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                                    <h2 style="margin: 0;"><?php esc_html_e('Welcome to Your Store!', 'masterai-store-builder'); ?></h2>
                                </div>
                                <p class="about-description">
                                    <?php
                                    /* translators: %s: Industry name */
                                    printf(esc_html__('Your %s store is ready to go. Here are some quick actions to get you started.', 'masterai-store-builder'), esc_html($industry));
                                    ?>
                                </p>

                                <div class="masterai-welcome-hero">
                                    <span class="masterai-welcome-icon dashicons dashicons-store"
                                        style="font-size: 40px; width: 40px; height: 40px; color: #2271b1; float: left; margin-right: 15px;"></span>
                                    <div class="masterai-hero-content">
                                        <h3 style="margin-top:0; font-size:1.4em;">
                                            <?php esc_html_e('Get Started with Your Store', 'masterai-store-builder'); ?>
                                        </h3>
                                        <p style="margin-bottom: 15px;">
                                            <?php esc_html_e('Add your first product or customize the demo items we added for you.', 'masterai-store-builder'); ?>
                                        </p>
                                        <a class="button button-primary masterai-button-hero"
                                            href="<?php echo esc_url(admin_url('post-new.php?post_type=product')); ?>"
                                            style="font-size: 1.1em; padding: 10px 20px;">
                                            <?php esc_html_e('Add Your First Product', 'masterai-store-builder'); ?>
                                        </a>
                                    </div>
                                </div>

                                <div class="masterai-welcome-grid-bottom">
                                    <div class="masterai-welcome-actions-col">
                                        <div class="masterai-action-group">
                                            <h3><span class="dashicons dashicons-admin-appearance"></span>
                                                <?php esc_html_e('Customize', 'masterai-store-builder'); ?></h3>
                                            <ul>
                                                <li><a
                                                        href="<?php echo esc_url(admin_url('customize.php')); ?>"><?php esc_html_e('Customize Design', 'masterai-store-builder'); ?></a>
                                                </li>
                                                <li><a
                                                        href="<?php echo esc_url(admin_url('nav-menus.php')); ?>"><?php esc_html_e('Edit Menus', 'masterai-store-builder'); ?></a>
                                                </li>
                                                <li><a
                                                        href="<?php echo esc_url(admin_url('admin.php?page=wc-settings')); ?>"><?php esc_html_e('Store Settings', 'masterai-store-builder'); ?></a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="masterai-action-group">
                                            <h3><span class="dashicons dashicons-rocket"></span>
                                                <?php esc_html_e('Launch', 'masterai-store-builder'); ?></h3>
                                            <ul>
                                                <li><a
                                                        href="<?php echo esc_url(admin_url('admin.php?page=wc-reports')); ?>"><?php esc_html_e('View Reports', 'masterai-store-builder'); ?></a>
                                                </li>
                                                <li><a
                                                        href="<?php echo esc_url(admin_url('edit.php?post_type=shop_order')); ?>"><?php esc_html_e('Manage Orders', 'masterai-store-builder'); ?></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="masterai-welcome-preview-col">
                                        <div class="masterai-mock-browser">
                                            <div class="masterai-browser-bar">
                                                <span class="dot red"></span>
                                                <span class="dot yellow"></span>
                                                <span class="dot green"></span>
                                                <div class="masterai-fake-url"><?php echo esc_url(home_url('/shop')); ?></div>
                                            </div>
                                            <div class="masterai-browser-content">
                                                <iframe src="<?php echo esc_url(home_url('/shop')); ?>" scrolling="no"></iframe>
                                                <a href="<?php echo esc_url(home_url('/shop')); ?>" target="_blank"
                                                    class="masterai-preview-overlay-btn">
                                                    <span class="dashicons dashicons-visibility"></span>
                                                    <?php esc_html_e('Visit Store', 'masterai-store-builder'); ?>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div> <!-- End Main -->

                    <div class="masterai-layout-side">

                        <div class="masterai-launch-checklist">
                            <h2><?php esc_html_e('Store Launch Checklist', 'masterai-store-builder'); ?></h2>

                            <?php
                            try {
                                $checklist = $this->get_launch_checklist();
                                $completed_count = count(array_filter($checklist, function ($item) {
                                    return $item['completed'];
                                }));
                                $total_count = count($checklist);
                                $progress = ($total_count > 0) ? ($completed_count / $total_count) * 100 : 0;
                                ?>

                                <div class="masterai-progress-container">
                                    <div class="masterai-progress-bar">
                                        <div class="masterai-progress-fill" style="width: <?php echo esc_attr($progress); ?>%;"></div>
                                    </div>
                                    <span
                                        class="masterai-progress-text"><?php
                                        $progress_percent = round($progress);
                                        $progress_text = sprintf(
                                            /* translators: %d: Completion percentage. */
                                            esc_html__('%d%% Complete', 'masterai-store-builder'),
                                            $progress_percent
                                        );
                                        echo esc_html($progress_text);
                                        ?></span>
                                </div>

                                <ul class="masterai-checklist-items">
                                    <?php foreach ($checklist as $item): ?>
                                        <li class="masterai-checklist-item <?php echo $item['completed'] ? 'completed' : 'pending'; ?>">
                                            <span
                                                class="dashicons <?php echo $item['completed'] ? 'dashicons-yes-alt' : 'dashicons-dismiss'; ?>"></span>
                                            <span class="checklist-label"><?php echo esc_html($item['label']); ?></span>
                                            <?php if (!$item['completed'] && !empty($item['action_url'])): ?>
                                                <a href="<?php echo esc_url($item['action_url']); ?>" class="button button-small action-button">
                                                    <?php echo esc_html($item['action_label']); ?>
                                                </a>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php
                            } catch (Exception $e) {
                                $checklist_error = sprintf(
                                    /* translators: %s: Error message. */
                                    esc_html__('Error loading checklist: %s', 'masterai-store-builder'),
                                    esc_html($e->getMessage())
                                );
                                echo '<div class="notice notice-error inline"><p>' . esc_html($checklist_error) . '</p></div>';
                            } catch (Error $e) {
                                $checklist_fatal_error = sprintf(
                                    /* translators: %s: Error message. */
                                    esc_html__('Fatal Error in checklist: %s', 'masterai-store-builder'),
                                    esc_html($e->getMessage())
                                );
                                echo '<div class="notice notice-error inline"><p>' . esc_html($checklist_fatal_error) . '</p></div>';
                            }
                            ?>
                        </div>



                        <!-- Daily Snapshot (Simplified Analytics) -->
                        <?php
                        try {
                            $stats = $this->get_daily_stats();
                            ?>
                            <div class="masterai-daily-snapshot">
                                <h2><?php esc_html_e('Daily Snapshot', 'masterai-store-builder'); ?> <span
                                        class="masterai-date-badge"><?php echo esc_html(date_i18n(get_option('date_format'))); ?></span>
                                </h2>

                                <div class="masterai-snapshot-grid">
                                    <div class="masterai-snapshot-card sales-card">
                                        <div class="snapshot-icon"><span class="dashicons dashicons-money-alt"></span></div>
                                        <div class="snapshot-content">
                                            <span class="snapshot-label"><?php esc_html_e('Sales Today', 'masterai-store-builder'); ?></span>
                                            <span class="snapshot-value"><?php echo wp_kses_post($stats['sales_today']); ?></span>
                                        </div>
                                    </div>

                                    <div class="masterai-snapshot-card orders-card">
                                        <div class="snapshot-icon"><span class="dashicons dashicons-cart"></span></div>
                                        <div class="snapshot-content">
                                            <span class="snapshot-label"><?php esc_html_e('Orders Today', 'masterai-store-builder'); ?></span>
                                            <span class="snapshot-value"><?php echo esc_html($stats['orders_today']); ?></span>
                                        </div>
                                    </div>

                                    <div class="masterai-snapshot-card product-card">
                                        <div class="snapshot-icon"><span class="dashicons dashicons-awards"></span></div>
                                        <div class="snapshot-content">
                                            <span
                                                class="snapshot-label"><?php esc_html_e('Top Product Today', 'masterai-store-builder'); ?></span>
                                            <?php if ($stats['top_product']): ?>
                                                <span
                                                    class="snapshot-value product-name"><?php echo esc_html($stats['top_product']['name']); ?></span>
                                                <span
                                                    class="snapshot-meta"><?php
                                                    $units_sold_text = sprintf(
                                                        /* translators: %d: Units sold. */
                                                        esc_html__('%d sold', 'masterai-store-builder'),
                                                        absint($stats['top_product']['count'])
                                                    );
                                                    echo esc_html($units_sold_text);
                                                    ?></span>
                                            <?php else: ?>
                                                <span
                                                    class="snapshot-value empty"><?php esc_html_e('No sales yet', 'masterai-store-builder'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        } catch (Exception $e) {
                            $stats_error = sprintf(
                                /* translators: %s: Error message. */
                                esc_html__('Error loading stats: %s', 'masterai-store-builder'),
                                esc_html($e->getMessage())
                            );
                            echo '<div class="notice notice-error"><p>' . esc_html($stats_error) . '</p></div>';
                        } catch (Error $e) {
                            $stats_fatal_error = sprintf(
                                /* translators: %s: Error message. */
                                esc_html__('Fatal Error in stats: %s', 'masterai-store-builder'),
                                esc_html($e->getMessage())
                            );
                            echo '<div class="notice notice-error"><p>' . esc_html($stats_fatal_error) . '</p></div>';
                        }
                        ?>
                    </div> <!-- End Side -->
                </div> <!-- End Layout -->

                <div class="masterai-feature-tabs">
                    <ul class="masterai-tabs-nav">
                        <li class="active" data-tab="demo"><a
                                href="#tab-demo"><?php esc_html_e('Demo Content', 'masterai-store-builder'); ?></a></li>
                        <li data-tab="legal"><a href="#tab-legal"><?php esc_html_e('Legal Pages', 'masterai-store-builder'); ?></a>
                        </li>
                        <li data-tab="enhancements"><a
                                href="#tab-enhancements"><?php esc_html_e('Industry Enhancements', 'masterai-store-builder'); ?></a>
                        </li>
                    </ul>

                    <div id="tab-demo" class="masterai-tab-content active">
                        <div class="masterai-demo-content-box">
                            <h2><?php esc_html_e('Manage Demo Content', 'masterai-store-builder'); ?></h2>
                            <p><?php esc_html_e('Your store includes demo products to help you get started. You can customize or replace them anytime.', 'masterai-store-builder'); ?>
                            </p>

                            <?php if ($demo_installed): ?>
                                <div class="notice notice-success inline">
                                    <p><?php esc_html_e('Demo content is currently installed.', 'masterai-store-builder'); ?></p>
                                </div>
                            <?php endif; ?>

                            <p>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=masterai-demo-content')); ?>"
                                    class="button button-secondary">
                                    <?php esc_html_e('Manage Demo Content', 'masterai-store-builder'); ?>
                                </a>
                            </p>
                        </div>
                    </div>

                    <div id="tab-legal" class="masterai-tab-content">
                        <div class="masterai-legal-pages-widget masterai-card">
                            <h2><?php esc_html_e('Legal Pages', 'masterai-store-builder'); ?></h2>
                            <p><?php esc_html_e('Auto-generate standard legal pages for your store.', 'masterai-store-builder'); ?>
                            </p>
                            <div class="masterai-legal-actions">
                                <button type="button" id="masterai-generate-legal-btn" class="button button-secondary">
                                    <?php esc_html_e('Generate Legal Pages', 'masterai-store-builder'); ?>
                                </button>
                                <span class="masterai-legal-message" style="margin-left: 10px; font-weight: bold;"></span>
                            </div>
                        </div>
                    </div>

                    <div id="tab-enhancements" class="masterai-tab-content">
                        <div class="masterai-enhancements-widget masterai-card">
                            <h2><?php esc_html_e('Industry Enhancements', 'masterai-store-builder'); ?></h2>
                            <p><?php esc_html_e('Specialized features based on your industry selection.', 'masterai-store-builder'); ?>
                            </p>

                            <div class="masterai-feature-toggle-row">
                                <div class="masterai-feature-info">
                                    <strong><?php esc_html_e('Industrial Product Filter', 'masterai-store-builder'); ?></strong>
                                    <p class="description">
                                        <?php esc_html_e('Advanced horizontal filter for technical products (Size, Material, Tolerance).', 'masterai-store-builder'); ?>
                                        <?php if ($industry !== 'industrial'): ?>
                                            <br><em
                                                style="color: #d63638;"><?php esc_html_e('Recommended for Industrial stores only.', 'masterai-store-builder'); ?></em>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <div class="masterai-feature-action">
                                    <?php
                                    $filter_enabled = get_option('masterai_builder_enable_industrial_filter', ($industry === 'industrial'));
                                    // Force consistency via option if not set
                                    if (get_option('masterai_builder_enable_industrial_filter') === false && $industry === 'industrial') {
                                        update_option('masterai_builder_enable_industrial_filter', true);
                                        $filter_enabled = true;
                                    }
                                    ?>
                                    <label class="masterai-switch">
                                        <input type="checkbox" id="masterai-toggle-industrial-filter" <?php checked($filter_enabled); ?>>
                                        <span class="masterai-slider round"></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render demo content management page
     */
    public function render_demo_content_page()
    {
        $demo_installed = get_option('masterai_builder_demo_content_installed');
        $demo_product_ids = get_option('masterai_builder_demo_product_ids', array());

        ?>
        <div class="wrap masterai-demo-content">
            <?php $this->render_admin_header(esc_html__('Demo Content Management', 'masterai-store-builder')); ?>

            <?php if ($demo_installed): ?>
                <div class="masterai-demo-content-box">
                    <h2><?php esc_html_e('Demo Products Installed', 'masterai-store-builder'); ?></h2>
                    <p><?php
                    $demo_products_text = sprintf(
                        /* translators: %d: Number of demo products installed. */
                        esc_html__('You have %d demo products installed. These are sample products to help you visualize your store.', 'masterai-store-builder'),
                        absint(count($demo_product_ids))
                    );
                    echo esc_html($demo_products_text);
                    ?>
                    </p>

                    <h3><?php esc_html_e('Options', 'masterai-store-builder'); ?></h3>

                    <div class="masterai-demo-options">
                        <div class="demo-option">
                            <h4><?php esc_html_e('Keep Demo Products', 'masterai-store-builder'); ?></h4>
                            <p><?php esc_html_e('Use them as templates and customize them with your own information.', 'masterai-store-builder'); ?>
                            </p>
                            <a href="<?php echo esc_url(admin_url('edit.php?post_type=product')); ?>" class="button">
                                <?php esc_html_e('Edit Products', 'masterai-store-builder'); ?>
                            </a>
                        </div>

                        <div class="demo-option">
                            <h4><?php esc_html_e('Remove All Demo Content', 'masterai-store-builder'); ?></h4>
                            <p><?php esc_html_e('Start with a clean slate and add your own products from scratch.', 'masterai-store-builder'); ?>
                            </p>
                            <button type="button" class="button button-secondary" id="masterai-remove-demo">
                                <?php esc_html_e('Remove All Demo Products', 'masterai-store-builder'); ?>
                            </button>
                        </div>

                        <div class="demo-option">
                            <h4><?php esc_html_e('Replace Gradually', 'masterai-store-builder'); ?></h4>
                            <p><?php esc_html_e('Add your products one by one and delete demos as you go.', 'masterai-store-builder'); ?>
                            </p>
                            <a href="<?php echo esc_url(admin_url('post-new.php?post_type=product')); ?>"
                                class="button button-primary">
                                <?php esc_html_e('Add New Product', 'masterai-store-builder'); ?>
                            </a>
                        </div>
                    </div>

                    <div class="masterai-demo-products-list">
                        <h3><?php esc_html_e('Demo Products', 'masterai-store-builder'); ?></h3>
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('Product', 'masterai-store-builder'); ?></th>
                                    <th><?php esc_html_e('Price', 'masterai-store-builder'); ?></th>
                                    <th><?php esc_html_e('Stock', 'masterai-store-builder'); ?></th>
                                    <th><?php esc_html_e('Actions', 'masterai-store-builder'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($demo_product_ids as $product_id): ?>
                                    <?php $product = wc_get_product($product_id); ?>
                                    <?php if ($product): ?>
                                        <tr>
                                            <td><strong><?php echo esc_html($product->get_name()); ?></strong></td>
                                            <td><?php echo wp_kses_post($product->get_price_html()); ?></td>
                                            <td><?php echo $product->is_in_stock() ? esc_html__('In stock', 'masterai-store-builder') : esc_html__('Out of stock', 'masterai-store-builder'); ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo esc_url(get_edit_post_link($product_id)); ?>" class="button button-small">
                                                    <?php esc_html_e('Edit', 'masterai-store-builder'); ?>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else: ?>
                <div class="notice notice-info">
                    <p><?php esc_html_e('No demo content is currently installed.', 'masterai-store-builder'); ?></p>
                </div>
                <p>
                    <button type="button" class="button button-primary" id="masterai-install-demo">
                        <?php esc_html_e('Install Demo Content', 'masterai-store-builder'); ?>
                    </button>
                    <span
                        class="description"><?php esc_html_e(' Imports sample products for your selected industry.', 'masterai-store-builder'); ?></span>
                </p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render settings page
     */
    public function render_settings_page()
    {
        if (isset($_POST['masterai_builder_save_settings']) && check_admin_referer('masterai_builder_save_settings', 'masterai_builder_settings_nonce')) {
            $this->save_settings();
            echo '<div class="notice notice-success"><p>' . esc_html__('Settings saved.', 'masterai-store-builder') . '</p></div>';
        }

        $store_name = get_option('masterai_builder_store_name', get_bloginfo('name'));
        $primary_color = get_option('masterai_builder_primary_color', '#FF6B6B');
        $secondary_color = get_option('masterai_builder_secondary_color', '#4ECDC4');

        ?>
        <div class="wrap masterai-settings">
            <?php $this->render_admin_header(esc_html__('MasterAI Settings', 'masterai-store-builder')); ?>

            <form method="post" action="">
                <?php wp_nonce_field('masterai_builder_save_settings', 'masterai_builder_settings_nonce'); ?>

                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="store_name"><?php esc_html_e('Store Name', 'masterai-store-builder'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="store_name" name="store_name" value="<?php echo esc_attr($store_name); ?>"
                                class="regular-text">
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="primary_color"><?php esc_html_e('Primary Color', 'masterai-store-builder'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="primary_color" name="primary_color"
                                value="<?php echo esc_attr($primary_color); ?>" class="masterai-color-field">
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="secondary_color"><?php esc_html_e('Secondary Color', 'masterai-store-builder'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="secondary_color" name="secondary_color"
                                value="<?php echo esc_attr($secondary_color); ?>" class="masterai-color-field">
                        </td>
                    </tr>
                </table>

                <hr>

                <h2 id="masterai-multi-currency-settings"><?php esc_html_e('Multi-Currency Settings', 'masterai-store-builder'); ?></h2>

                <?php
                $multi_currency_enabled = get_option('masterai_builder_multi_currency_enabled', false);
                $enabled_currencies = get_option('masterai_builder_enabled_currencies', array());
                $exchange_api_key = get_option('masterai_builder_exchange_rate_api_key', '');
                $currency_round_99 = get_option('masterai_builder_currency_round_99', true);

                $all_currencies = array(
                    'USD' => 'US Dollar',
                    'EUR' => 'Euro',
                    'GBP' => 'British Pound',
                    'CAD' => 'Canadian Dollar',
                    'AUD' => 'Australian Dollar',
                    'JPY' => 'Japanese Yen',
                    'CNY' => 'Chinese Yuan',
                    'BRL' => 'Brazilian Real',
                    'MXN' => 'Mexican Peso',
                );
                ?>

                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label
                                for="multi_currency_enabled"><?php esc_html_e('Enable Multi-Currency', 'masterai-store-builder'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" id="multi_currency_enabled" name="multi_currency_enabled" value="1" <?php checked($multi_currency_enabled); ?>>
                                <?php esc_html_e('Auto-convert prices based on visitor location', 'masterai-store-builder'); ?>
                            </label>
                            <p class="description">
                                <?php esc_html_e('Automatically detect visitor\'s country and show prices in their local currency.', 'masterai-store-builder'); ?>
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="currency_round_99"><?php esc_html_e('Round to .99', 'masterai-store-builder'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" id="currency_round_99" name="currency_round_99" value="1" <?php checked($currency_round_99); ?>>
                                <?php esc_html_e('Round converted prices to .99 (e.g., $10.50 → $10.99)', 'masterai-store-builder'); ?>
                            </label>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label
                                for="exchange_api_key"><?php esc_html_e('Exchange Rate API Key', 'masterai-store-builder'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="exchange_api_key" name="exchange_api_key"
                                value="<?php echo esc_attr($exchange_api_key); ?>" class="regular-text">
                            <p class="description">
                                <?php esc_html_e('Optional. Get a free API key from', 'masterai-store-builder'); ?>
                                <a href="https://www.exchangerate-api.com" target="_blank">exchangerate-api.com</a>
                                <?php esc_html_e('(1,500 requests/month free). Leave blank to use the free public API.', 'masterai-store-builder'); ?>
                            </p>
                        </td>
                    </tr>
                </table>

                <h3><?php esc_html_e('Enabled Currencies', 'masterai-store-builder'); ?></h3>
                <p class="description">
                    <?php esc_html_e('Select which currencies to enable and set their exchange rates. Rates can be fetched automatically or entered manually.', 'masterai-store-builder'); ?>
                </p>

                <table class="widefat" style="max-width: 800px; margin-top: 10px;">
                    <thead>
                        <tr>
                            <th style="width: 50px;"><?php esc_html_e('Enable', 'masterai-store-builder'); ?></th>
                            <th><?php esc_html_e('Currency', 'masterai-store-builder'); ?></th>
                            <th><?php esc_html_e('Exchange Rate', 'masterai-store-builder'); ?></th>
                            <th><?php esc_html_e('Price Adjustment (%)', 'masterai-store-builder'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($all_currencies as $code => $name): ?>
                            <?php
                            $is_enabled = isset($enabled_currencies[$code]);
                            $rate = $is_enabled && isset($enabled_currencies[$code]['rate']) ? $enabled_currencies[$code]['rate'] : 1;
                            $adjustment = $is_enabled && isset($enabled_currencies[$code]['adjustment']) ? $enabled_currencies[$code]['adjustment'] : 0;
                            ?>
                            <tr>
                                <td style="text-align: center;">
                                    <input type="checkbox" name="enabled_currencies[<?php echo esc_attr($code); ?>][enabled]" value="1" <?php checked($is_enabled); ?>>
                                </td>
                                <td><strong><?php echo esc_html($code); ?></strong> - <?php echo esc_html($name); ?></td>
                                <td>
                                    <input type="number" step="0.000001" name="enabled_currencies[<?php echo esc_attr($code); ?>][rate]"
                                        value="<?php echo esc_attr($rate); ?>" style="width: 120px;">
                                </td>
                                <td>
                                    <input type="number" step="1" name="enabled_currencies[<?php echo esc_attr($code); ?>][adjustment]"
                                        value="<?php echo esc_attr($adjustment); ?>" style="width: 80px;"> %
                                    <span
                                        class="description"><?php esc_html_e('(e.g., +5 for 5% markup)', 'masterai-store-builder'); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <p style="margin-top: 15px;">
                    <button type="button" class="button" id="masterai-fetch-rates">
                        <?php esc_html_e('Fetch Live Exchange Rates', 'masterai-store-builder'); ?>
                    </button>
                    <span id="masterai-fetch-rates-status" style="margin-left: 10px;"></span>
                </p>

                <hr>

                <h2><?php esc_html_e('Live Purchase Overlay (OBS)', 'masterai-store-builder'); ?></h2>
                <?php
                $order_overlay_enabled = get_option('masterai_builder_order_overlay_enabled', false);
                $order_overlay_category_id = absint(get_option('masterai_builder_order_overlay_category_id', 0));
                $product_categories = get_terms(array(
                    'taxonomy' => 'product_cat',
                    'hide_empty' => false,
                ));
                ?>

                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label
                                for="order_overlay_enabled"><?php esc_html_e('Enable Live Overlay', 'masterai-store-builder'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" id="order_overlay_enabled" name="order_overlay_enabled" value="1" <?php checked($order_overlay_enabled); ?>>
                                <?php esc_html_e('Show a live top-left purchase message for OBS/browser overlays', 'masterai-store-builder'); ?>
                            </label>
                            <p class="description">
                                <?php esc_html_e('Optional feature. Disabled by default.', 'masterai-store-builder'); ?>
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label
                                for="order_overlay_category_id"><?php esc_html_e('Product Category', 'masterai-store-builder'); ?></label>
                        </th>
                        <td>
                            <select id="order_overlay_category_id" name="order_overlay_category_id">
                                <option value="0" <?php selected($order_overlay_category_id, 0); ?>>
                                    <?php esc_html_e('All Categories', 'masterai-store-builder'); ?>
                                </option>
                                <?php
                                if (!is_wp_error($product_categories) && !empty($product_categories)) {
                                    foreach ($product_categories as $category) {
                                        ?>
                                        <option value="<?php echo esc_attr($category->term_id); ?>" <?php selected($order_overlay_category_id, $category->term_id); ?>>
                                            <?php echo esc_html($category->name); ?>
                                        </option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                            <p class="description">
                                <?php esc_html_e('Only orders containing products from this category will trigger the overlay.', 'masterai-store-builder'); ?>
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <?php esc_html_e('Overlay Shortcode', 'masterai-store-builder'); ?>
                        </th>
                        <td>
                            <code>[masterai_order_overlay]</code>
                            <p class="description">
                                <?php esc_html_e('Create a blank page, add this shortcode, and use that page URL in OBS Browser Source.', 'masterai-store-builder'); ?>
                            </p>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <button type="submit" name="masterai_builder_save_settings" class="button button-primary">
                        <?php esc_html_e('Save Settings', 'masterai-store-builder'); ?>
                    </button>
                </p>
            </form>

            <hr>

            <h2><?php esc_html_e('Reset Plugin', 'masterai-store-builder'); ?></h2>
            <p><?php esc_html_e('Start the setup wizard again from the beginning.', 'masterai-store-builder'); ?></p>
            <button type="button" class="button" id="masterai-reset-wizard">
                <?php esc_html_e('Reset Setup Wizard', 'masterai-store-builder'); ?>
            </button>
        </div>
        <?php
    }

    /**
     * Save settings
     */
    private function save_settings()
    {
        if (
            !isset($_POST['masterai_builder_settings_nonce']) ||
            !wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['masterai_builder_settings_nonce'])),
                'masterai_builder_save_settings'
            )
        ) {
            return;
        }

        if (isset($_POST['store_name'])) {
            update_option('masterai_builder_store_name', sanitize_text_field(wp_unslash($_POST['store_name'])));
            update_option('blogname', sanitize_text_field(wp_unslash($_POST['store_name'])));
        }

        if (isset($_POST['primary_color'])) {
            update_option('masterai_builder_primary_color', sanitize_hex_color(wp_unslash($_POST['primary_color'])));
        }

        if (isset($_POST['secondary_color'])) {
            update_option('masterai_builder_secondary_color', sanitize_hex_color(wp_unslash($_POST['secondary_color'])));
        }

        // Multi-currency settings
        $multi_currency_enabled = isset($_POST['multi_currency_enabled']) ? true : false;
        update_option('masterai_builder_multi_currency_enabled', $multi_currency_enabled);

        $currency_round_99 = isset($_POST['currency_round_99']) ? true : false;
        update_option('masterai_builder_currency_round_99', $currency_round_99);

        if (isset($_POST['exchange_api_key'])) {
            update_option('masterai_builder_exchange_rate_api_key', sanitize_text_field(wp_unslash($_POST['exchange_api_key'])));
        }

        // Save enabled currencies
        if (isset($_POST['enabled_currencies'])) {
            $enabled_currencies = array();
            $posted_currencies = wp_unslash($_POST['enabled_currencies']);
            foreach ($posted_currencies as $code => $data) {
                $code = sanitize_text_field($code);
                if (isset($data['enabled'])) {
                    $enabled_currencies[$code] = array(
                        'rate' => isset($data['rate']) ? (float) $data['rate'] : 1,
                        'adjustment' => isset($data['adjustment']) ? (float) $data['adjustment'] : 0,
                    );
                }
            }
            update_option('masterai_builder_enabled_currencies', $enabled_currencies);
        }

        // Live order overlay settings
        $order_overlay_enabled = isset($_POST['order_overlay_enabled']) ? true : false;
        update_option('masterai_builder_order_overlay_enabled', $order_overlay_enabled);

        $order_overlay_category_id = isset($_POST['order_overlay_category_id']) ? absint($_POST['order_overlay_category_id']) : 0;
        update_option('masterai_builder_order_overlay_category_id', $order_overlay_category_id);
    }

    /**
     * Render upgrade page
     */
    public function render_upgrade_page()
    {
        ?>
        <div class="wrap masterai-upgrade">
            <?php $this->render_admin_header(esc_html__('Upgrade to Premium', 'masterai-store-builder')); ?>

            <div class="masterai-upgrade-hero"
                style="background: #fff; padding: 40px; text-align: center; border-radius: 8px; margin-top: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <span class="dashicons dashicons-star-filled"
                    style="font-size: 64px; width: 64px; height: 64px; color: #FFD700; margin-bottom: 20px;"></span>
                <h2 style="font-size: 32px; margin-bottom: 15px;">
                    <?php esc_html_e('Unlock the Full Power of MasterAI Store Builder', 'masterai-store-builder'); ?>
                </h2>
                <p style="font-size: 18px; color: #666; max-width: 600px; margin: 0 auto 30px;">
                    <?php esc_html_e('Take your store to the next level with our premium features designed to boost sales and save time.', 'masterai-store-builder'); ?>
                </p>
                <a href="https://productube.gumroad.com/l/MasterAI-WooCommerceStoreLauncher-Pro" target="_blank"
                    class="button button-primary button-hero"
                    style="font-size: 20px; height: auto; padding: 10px 40px; background-color: #6C5CE7; border-color: #6C5CE7;">
                    <?php esc_html_e('Upgrade Now', 'masterai-store-builder'); ?>
                </a>
            </div>

            <div class="masterai-features-grid"
                style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 30px;">

                <!-- Home Page Builder -->
                <div class="masterai-feature-card"
                    style="background: #fff; padding: 25px; border-radius: 8px; border-left: 4px solid #6C5CE7; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: flex; flex-direction: column;">
                    <h3 style="display: flex; align-items: center; margin-top: 0;">
                        <span class="dashicons dashicons-layout" style="margin-right: 10px; color: #6C5CE7;"></span>
                        <?php esc_html_e('Advanced Home Page Builder', 'masterai-store-builder'); ?>
                    </h3>
                    <ul style="list-style: inherit; padding-left: 20px; margin-bottom: 20px; flex-grow: 1;">
                        <li><?php esc_html_e('Homepage Hero Banner / Carousel', 'masterai-store-builder'); ?></li>
                        <li><?php esc_html_e('Featured Collection Sections', 'masterai-store-builder'); ?></li>
                        <li><?php esc_html_e('Review & Rating Sections', 'masterai-store-builder'); ?></li>
                        <li><?php esc_html_e('Social Media Feeds (Instagram, Facebook, Pinterest)', 'masterai-store-builder'); ?></li>
                    </ul>
                    <a href="https://productube.gumroad.com/l/MasterAI-WooCommerceStoreLauncher-Pro" target="_blank"
                        class="button"
                        style="width: 100%; text-align: center; background-color: #f0f0f1; border-color: #dcdcde; color: #6C5CE7; margin-top: auto;">
                        <?php esc_html_e('Upgrade to Unlock', 'masterai-store-builder'); ?> <span class="dashicons dashicons-external"
                            style="font-size: 14px; margin-left: 5px;"></span>
                    </a>
                </div>

                <!-- Ecommerce Themes -->
                <div class="masterai-feature-card"
                    style="background: #fff; padding: 25px; border-radius: 8px; border-left: 4px solid #00B894; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: flex; flex-direction: column;">
                    <h3 style="display: flex; align-items: center; margin-top: 0;">
                        <span class="dashicons dashicons-admin-appearance" style="margin-right: 10px; color: #00B894;"></span>
                        <?php esc_html_e('10+ Premium Store Themes', 'masterai-store-builder'); ?>
                    </h3>
                    <ul style="list-style: inherit; padding-left: 20px; margin-bottom: 20px; flex-grow: 1;">
                        <li><?php esc_html_e('Professionally designed conversion-focused themes', 'masterai-store-builder'); ?></li>
                        <li><?php esc_html_e('Fully customizable & responsive', 'masterai-store-builder'); ?></li>
                        <li><?php esc_html_e('One-click import', 'masterai-store-builder'); ?></li>
                    </ul>
                    <a href="https://productube.gumroad.com/l/MasterAI-WooCommerceStoreLauncher-Pro" target="_blank"
                        class="button"
                        style="width: 100%; text-align: center; background-color: #f0f0f1; border-color: #dcdcde; color: #00B894; margin-top: auto;">
                        <?php esc_html_e('Upgrade to Unlock', 'masterai-store-builder'); ?> <span class="dashicons dashicons-external"
                            style="font-size: 14px; margin-left: 5px;"></span>
                    </a>
                </div>

                <!-- Product Import -->
                <div class="masterai-feature-card"
                    style="background: #fff; padding: 25px; border-radius: 8px; border-left: 4px solid #0984E3; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: flex; flex-direction: column;">
                    <h3 style="display: flex; align-items: center; margin-top: 0;">
                        <span class="dashicons dashicons-cloud-upload" style="margin-right: 10px; color: #0984E3;"></span>
                        <?php esc_html_e('Multi-Channel Product Import', 'masterai-store-builder'); ?>
                    </h3>
                    <ul style="list-style: inherit; padding-left: 20px; margin-bottom: 20px; flex-grow: 1;">
                        <li><?php esc_html_e('Import products from Amazon', 'masterai-store-builder'); ?></li>
                        <li><?php esc_html_e('Import from eBay & other marketplaces', 'masterai-store-builder'); ?></li>
                        <li><?php esc_html_e('Bulk import tools', 'masterai-store-builder'); ?></li>
                    </ul>
                    <a href="https://productube.gumroad.com/l/MasterAI-WooCommerceStoreLauncher-Pro" target="_blank"
                        class="button"
                        style="width: 100%; text-align: center; background-color: #f0f0f1; border-color: #dcdcde; color: #0984E3; margin-top: auto;">
                        <?php esc_html_e('Upgrade to Unlock', 'masterai-store-builder'); ?> <span class="dashicons dashicons-external"
                            style="font-size: 14px; margin-left: 5px;"></span>
                    </a>
                </div>

                <!-- Competitor Analyzer -->
                <div class="masterai-feature-card"
                    style="background: #fff; padding: 25px; border-radius: 8px; border-left: 4px solid #E17055; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: flex; flex-direction: column;">
                    <h3 style="display: flex; align-items: center; margin-top: 0;">
                        <span class="dashicons dashicons-chart-line" style="margin-right: 10px; color: #E17055;"></span>
                        <?php esc_html_e('Competition Analyzer', 'masterai-store-builder'); ?>
                    </h3>
                    <ul style="list-style: inherit; padding-left: 20px; margin-bottom: 20px; flex-grow: 1;">
                        <li><?php esc_html_e('Track competitor prices', 'masterai-store-builder'); ?></li>
                        <li><?php esc_html_e('Analyze market trends', 'masterai-store-builder'); ?></li>
                        <li><?php esc_html_e('Stay ahead of the competition', 'masterai-store-builder'); ?></li>
                    </ul>
                    <a href="https://productube.gumroad.com/l/MasterAI-WooCommerceStoreLauncher-Pro" target="_blank"
                        class="button"
                        style="width: 100%; text-align: center; background-color: #f0f0f1; border-color: #dcdcde; color: #E17055; margin-top: auto;">
                        <?php esc_html_e('Upgrade to Unlock', 'masterai-store-builder'); ?> <span class="dashicons dashicons-external"
                            style="font-size: 14px; margin-left: 5px;"></span>
                    </a>
                </div>

                <!-- Cart Recovery -->
                <div class="masterai-feature-card"
                    style="background: #fff; padding: 25px; border-radius: 8px; border-left: 4px solid #FD79A8; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: flex; flex-direction: column;">
                    <h3 style="display: flex; align-items: center; margin-top: 0;">
                        <span class="dashicons dashicons-cart" style="margin-right: 10px; color: #FD79A8;"></span>
                        <?php esc_html_e('Smart Cart Recovery', 'masterai-store-builder'); ?>
                    </h3>
                    <ul style="list-style: inherit; padding-left: 20px; margin-bottom: 20px; flex-grow: 1;">
                        <li><?php esc_html_e('Recover abandoned carts automatically', 'masterai-store-builder'); ?></li>
                        <li><?php esc_html_e('Exit-intent popups', 'masterai-store-builder'); ?></li>
                        <li><?php esc_html_e('Email recovery sequences', 'masterai-store-builder'); ?></li>
                    </ul>
                    <a href="https://productube.gumroad.com/l/MasterAI-WooCommerceStoreLauncher-Pro" target="_blank"
                        class="button"
                        style="width: 100%; text-align: center; background-color: #f0f0f1; border-color: #dcdcde; color: #FD79A8; margin-top: auto;">
                        <?php esc_html_e('Upgrade to Unlock', 'masterai-store-builder'); ?> <span class="dashicons dashicons-external"
                            style="font-size: 14px; margin-left: 5px;"></span>
                    </a>
                </div>

            </div>
        </div>
        <?php
    }

    /**
     * Get launch checklist items
     */
    private function get_launch_checklist()
    {
        // 1. Check for Logo
        $has_logo = current_theme_supports('custom-logo') && get_theme_mod('custom_logo');

        // 2. Publish first product
        $product_count = wp_count_posts('product')->publish;
        $has_product = $product_count > 0;

        // 3. Multi-Currency Enabled
        $multi_currency = get_option('masterai_builder_multi_currency_enabled') === '1';

        // 4. Store Location
        $store_location = get_option('woocommerce_default_country');
        $has_location = !empty($store_location);

        return array(
            array(
                'label' => __('Add Logo', 'masterai-store-builder'),
                'completed' => (bool) $has_logo,
                'action_label' => __('Add Logo', 'masterai-store-builder'),
                'action_url' => admin_url('customize.php?autofocus[control]=custom_logo'),
            ),
            array(
                'label' => __('Publish first product', 'masterai-store-builder'),
                'completed' => $has_product,
                'action_label' => __('Add Product', 'masterai-store-builder'),
                'action_url' => admin_url('post-new.php?post_type=product'),
            ),
            array(
                'label' => __('Multi-Currency Enabled', 'masterai-store-builder'),
                'completed' => $multi_currency,
                'action_label' => __('Enable', 'masterai-store-builder'),
                'action_url' => admin_url('admin.php?page=masterai-settings#masterai-multi-currency-settings'),
            ),
            array(
                'label' => __('Store Location Set', 'masterai-store-builder'),
                'completed' => $has_location,
                'action_label' => __('Set Location', 'masterai-store-builder'),
                'action_url' => admin_url('admin.php?page=masterai-wizard&step=settings'),
            ),
        );
    }

    /**
     * Get daily stats for snapshot
     */
    private function get_daily_stats()
    {
        $today = gmdate('Y-m-d');

        // Get orders created today
        $args = array(
            'date_created' => $today,
            'limit' => -1,
            'status' => array('completed', 'processing', 'on-hold'),
            'return' => 'ids',
        );
        $orders = wc_get_orders($args);

        $sales_today = 0;
        $orders_today = count($orders);
        $product_sales = array();

        foreach ($orders as $order_id) {
            $order = wc_get_order($order_id);
            if ($order) {
                $sales_today += $order->get_total();

                foreach ($order->get_items() as $item) {
                    $product_id = $item->get_product_id();
                    $quantity = $item->get_quantity();
                    if (!isset($product_sales[$product_id])) {
                        $product_sales[$product_id] = 0;
                    }
                    $product_sales[$product_id] += $quantity;
                }
            }
        }

        // Determine top product
        $top_product = null;
        if (!empty($product_sales)) {
            arsort($product_sales);
            $top_product_id = key($product_sales);
            $product = wc_get_product($top_product_id);
            if ($product) {
                $top_product = array(
                    'name' => $product->get_name(),
                    'count' => $product_sales[$top_product_id],
                );
            }
        }

        return array(
            'sales_today' => wc_price($sales_today),
            'orders_today' => $orders_today,
            'top_product' => $top_product
        );
    }
}
