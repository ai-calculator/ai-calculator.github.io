<?php
/**
 * Live Order Overlay (OBS-friendly)
 *
 * @package MasterAI_Builder
 */

if (!defined('ABSPATH')) {
    exit;
}

class MasterAI_Order_Overlay
{
    /**
     * Single instance
     *
     * @var MasterAI_Order_Overlay|null
     */
    protected static $_instance = null;

    /**
     * Event storage option key
     *
     * @var string
     */
    const EVENTS_OPTION_KEY = 'masterai_builder_order_overlay_events';

    /**
     * Get instance
     *
     * @return MasterAI_Order_Overlay
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Constructor
     */
    public function __construct()
    {
        add_shortcode('masterai_order_overlay', array($this, 'render_shortcode'));

        // Store live order events for stream overlays.
        add_action('woocommerce_order_status_processing', array($this, 'capture_order_event'));
        add_action('woocommerce_order_status_completed', array($this, 'capture_order_event'));

        // Public endpoint for the OBS browser source page.
        add_action('wp_ajax_masterai_builder_get_overlay_events', array($this, 'ajax_get_overlay_events'));
        add_action('wp_ajax_nopriv_masterai_builder_get_overlay_events', array($this, 'ajax_get_overlay_events'));
    }

    /**
     * Check if overlay feature is enabled.
     *
     * @return bool
     */
    private function is_enabled()
    {
        return (bool) get_option('masterai_builder_order_overlay_enabled', false);
    }

    /**
     * Capture a qualifying order and save it as an overlay event.
     *
     * @param int $order_id Order ID.
     */
    public function capture_order_event($order_id)
    {
        if (!$this->is_enabled() || !function_exists('wc_get_order')) {
            return;
        }

        $order = wc_get_order(absint($order_id));
        if (!$order) {
            return;
        }

        if ($order->get_meta('_masterai_overlay_notified', true)) {
            return;
        }

        $match_data = $this->get_matching_line_item_data($order);
        if (!$match_data['matched']) {
            return;
        }

        $customer_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
        if ($customer_name === '') {
            $customer_name = __('Someone', 'masterai-store-builder');
        }

        $product_label = $match_data['product_name'];
        if ($match_data['quantity'] > 1) {
            $product_label .= ' x' . absint($match_data['quantity']);
        }

        $timestamp = time();
        $event = array(
            'id' => uniqid('fc_overlay_', true),
            'message' => sprintf(
                /* translators: 1: customer name, 2: product info */
                __('%1$s purchased %2$s', 'masterai-store-builder'),
                $customer_name,
                $product_label
            ),
            'timestamp' => $timestamp,
        );

        $events = get_option(self::EVENTS_OPTION_KEY, array());
        if (!is_array($events)) {
            $events = array();
        }

        $events[] = $event;
        if (count($events) > 50) {
            $events = array_slice($events, -50);
        }

        update_option(self::EVENTS_OPTION_KEY, $events, false);

        $order->update_meta_data('_masterai_overlay_notified', '1');
        $order->save_meta_data();
    }

    /**
     * Get first matching line item data for category filtering.
     *
     * @param WC_Order $order WooCommerce order object.
     * @return array
     */
    private function get_matching_line_item_data($order)
    {
        $selected_category_id = absint(get_option('masterai_builder_order_overlay_category_id', 0));

        foreach ($order->get_items('line_item') as $item) {
            $product_id = $item->get_product_id();
            $variation_id = $item->get_variation_id();
            $lookup_product_id = $variation_id ? wp_get_post_parent_id($variation_id) : $product_id;
            if (!$lookup_product_id) {
                $lookup_product_id = $product_id;
            }

            if ($selected_category_id > 0 && !has_term($selected_category_id, 'product_cat', $lookup_product_id)) {
                continue;
            }

            return array(
                'matched' => true,
                'product_name' => $item->get_name(),
                'quantity' => (int) $item->get_quantity(),
            );
        }

        return array(
            'matched' => false,
            'product_name' => '',
            'quantity' => 0,
        );
    }

    /**
     * AJAX endpoint for overlay polling.
     */
    public function ajax_get_overlay_events()
    {
        if (!$this->is_enabled()) {
            wp_send_json_success(array(
                'events' => array(),
                'server_time' => time(),
                'enabled' => false,
            ));
        }

        $since = isset($_REQUEST['since']) ? absint($_REQUEST['since']) : 0;
        $events = get_option(self::EVENTS_OPTION_KEY, array());
        if (!is_array($events)) {
            $events = array();
        }

        if ($since > 0) {
            $events = array_values(array_filter($events, function ($event) use ($since) {
                return !empty($event['timestamp']) && absint($event['timestamp']) > $since;
            }));
        }

        wp_send_json_success(array(
            'events' => $events,
            'server_time' => time(),
            'enabled' => true,
        ));
    }

    /**
     * Shortcode renderer: [masterai_order_overlay]
     *
     * @return string
     */
    public function render_shortcode()
    {
        if (!$this->is_enabled()) {
            if (current_user_can('manage_options')) {
                return '<p>' . esc_html__('MasterAI live order overlay is disabled. Enable it in MasterAI -> Settings.', 'masterai-store-builder') . '</p>';
            }
            return '';
        }

        $config = array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'pollAction' => 'masterai_builder_get_overlay_events',
            'pollInterval' => 3000,
            'startSince' => time(),
        );

        $overlay_css = '
            #masterai-order-overlay-root {
                position: fixed;
                top: 20px;
                left: 20px;
                z-index: 999999;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                pointer-events: none;
            }
            .masterai-order-toast {
                background: rgba(17, 24, 39, 0.9);
                color: #fff;
                border-radius: 8px;
                padding: 12px 14px;
                font-size: 16px;
                font-weight: 600;
                letter-spacing: 0.2px;
                box-shadow: 0 10px 24px rgba(0, 0, 0, 0.25);
                max-width: 430px;
                opacity: 0;
                transform: translateY(-8px);
                transition: opacity 0.22s ease, transform 0.22s ease;
            }
            .masterai-order-toast.is-visible {
                opacity: 1;
                transform: translateY(0);
            }
        ';

        $config_json = wp_json_encode($config);
        if (!is_string($config_json)) {
            $config_json = '{}';
        }

        $overlay_js = sprintf(
            '(function(){var config=%1$s;var root=document.getElementById("masterai-order-overlay-root");if(!root){return;}var lastTimestamp=Number(config.startSince||0);var queue=[];var showing=false;function showNext(){if(showing||queue.length===0){return;}showing=true;var item=queue.shift();var toast=document.createElement("div");toast.className="masterai-order-toast";toast.textContent=item.message||"";root.appendChild(toast);requestAnimationFrame(function(){toast.classList.add("is-visible");});setTimeout(function(){toast.classList.remove("is-visible");setTimeout(function(){if(toast.parentNode){toast.parentNode.removeChild(toast);}showing=false;showNext();},230);},6000);}function poll(){var url=config.ajaxUrl+"?action="+encodeURIComponent(config.pollAction)+"&since="+encodeURIComponent(lastTimestamp);fetch(url,{credentials:"same-origin"}).then(function(response){return response.json();}).then(function(payload){if(!payload||!payload.success||!payload.data){return;}var data=payload.data;var events=Array.isArray(data.events)?data.events:[];events.forEach(function(eventItem){var ts=Number(eventItem.timestamp||0);if(ts>lastTimestamp){lastTimestamp=ts;}queue.push(eventItem);});showNext();}).catch(function(){});}poll();setInterval(poll,Number(config.pollInterval||3000));})();',
            $config_json
        );

        wp_register_style('masterai-order-overlay', false, array(), MasterAI_VERSION);
        wp_enqueue_style('masterai-order-overlay');
        wp_add_inline_style('masterai-order-overlay', esc_html($overlay_css));

        wp_register_script('masterai-order-overlay', '', array(), MasterAI_VERSION, true);
        wp_enqueue_script('masterai-order-overlay');
        wp_add_inline_script('masterai-order-overlay', $overlay_js);

        return '<div id="masterai-order-overlay-root" aria-live="polite"></div>';
    }
}
