<?php
/**
 * MasterAI AJAX Handler
 *
 * @package MasterAI_Builder
 */

if (!defined('ABSPATH')) {
    exit;
}

class MasterAI_Ajax
{

    /**
     * Single instance
     */
    protected static $_instance = null;

    /**
     * Get instance
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Constructor
     */
    public function __construct()
    {
        // Wizard actions
        add_action('wp_ajax_masterai_builder_save_wizard_step', array($this, 'save_wizard_step'));
        add_action('wp_ajax_masterai_builder_install_template', array($this, 'install_template'));
        add_action('wp_ajax_masterai_builder_get_industry_preview', array($this, 'get_industry_preview'));

        // Admin actions
        add_action('wp_ajax_masterai_builder_remove_demo_content', array($this, 'remove_demo_content'));
        add_action('wp_ajax_masterai_builder_install_demo_content', array($this, 'install_demo_content'));
        add_action('wp_ajax_masterai_builder_reset_wizard', array($this, 'reset_wizard'));

        // AI Actions
        add_action('wp_ajax_masterai_builder_save_gemini_key', array($this, 'save_gemini_key'));
        add_action('wp_ajax_masterai_builder_generate_product', array($this, 'generate_product'));
        add_action('wp_ajax_masterai_builder_save_product_image', array($this, 'save_product_image'));
        add_action('wp_ajax_masterai_builder_generate_legal_pages', array($this, 'generate_legal_pages'));

        // Feature Toggles
        add_action('wp_ajax_masterai_builder_toggle_industrial_filter', array($this, 'toggle_industrial_filter'));
        add_action('wp_ajax_masterai_builder_generate_store_description', array($this, 'generate_store_description'));

        // Multi-Currency Actions
        add_action('wp_ajax_masterai_builder_fetch_exchange_rates', array($this, 'fetch_exchange_rates'));


    }

    /**
     * Save wizard step data
     */
    public function save_wizard_step()
    {
        check_ajax_referer('masterai_builder_wizard_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        $step = isset($_POST['step']) ? sanitize_key($_POST['step']) : '';
        $data = isset($_POST['data']) ? $_POST['data'] : array();

        switch ($step) {
            case 'industry':
                $this->save_industry_step($data);
                break;

            case 'products':
                $this->save_products_step($data);
                break;

            case 'details':
                $this->save_details_step($data);
                break;

            case 'settings':
                $this->save_settings_step($data);
                break;
        }

        wp_send_json_success(array(
            'message' => __('Rates updated successfully', 'masterai-store-builder')
        ));
    }



    /**
     * Save industry selection
     */
    private function save_industry_step($data)
    {
        if (!empty($data['industry'])) {
            update_option('masterai_builder_industry', sanitize_key($data['industry']));
        }

        if (!empty($data['start_mode'])) {
            update_option('masterai_builder_start_mode', sanitize_key($data['start_mode']));
        }
    }

    /**
     * Save product selection
     */
    private function save_products_step($data)
    {
        $selected_products = isset($data['selected_products']) ? array_map('absint', $data['selected_products']) : array();
        update_option('masterai_builder_selected_products', $selected_products);
    }

    /**
     * Save store details
     */
    private function save_details_step($data)
    {
        if (!empty($data['store_name'])) {
            update_option('masterai_builder_store_name', sanitize_text_field($data['store_name']));
        }

        if (isset($data['store_description'])) {
            update_option('masterai_builder_store_description', sanitize_textarea_field($data['store_description']));
        }

        if (!empty($data['store_tagline'])) {
            update_option('masterai_builder_store_tagline', sanitize_text_field($data['store_tagline']));
        }

        if (isset($data['logo_id'])) {
            update_option('masterai_builder_logo_id', absint($data['logo_id']));
        }

        if (!empty($data['primary_color'])) {
            update_option('masterai_builder_primary_color', sanitize_hex_color($data['primary_color']));
        }

        if (!empty($data['secondary_color'])) {
            update_option('masterai_builder_secondary_color', sanitize_hex_color($data['secondary_color']));
        }
    }

    /**
     * Save business settings
     */
    private function save_settings_step($data)
    {
        $settings = array(
            'currency' => sanitize_text_field($data['currency'] ?? 'USD'),
            'country' => sanitize_text_field($data['country'] ?? 'US'),
            'offer_physical' => !empty($data['offer_physical']),
            'offer_digital' => !empty($data['offer_digital']),
            'offer_services' => !empty($data['offer_services']),
            // New Shipping Fields
            'shipping_domestic' => !empty($data['shipping_domestic']),
            'shipping_domestic_rate' => floatval($data['shipping_domestic_rate'] ?? 5.00),
            'shipping_international' => !empty($data['shipping_international']),
            'shipping_international_rate' => floatval($data['shipping_international_rate'] ?? 15.00),
        );

        update_option('masterai_builder_business_settings', $settings);
    }



    /**
     * Install template (main installation process)
     */
    public function install_template()
    {
        check_ajax_referer('masterai_builder_wizard_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        // Get all saved settings
        $industry = get_option('masterai_builder_industry');
        $start_mode = get_option('masterai_builder_start_mode', 'fresh');

        $settings = array(
            'store_name' => get_option('masterai_builder_store_name'),
            'store_description' => get_option('masterai_builder_store_description'),
            'store_tagline' => get_option('masterai_builder_store_tagline'),
            'logo_id' => get_option('masterai_builder_logo_id'),
            'primary_color' => get_option('masterai_builder_primary_color'),
            'secondary_color' => get_option('masterai_builder_secondary_color'),
            'skip_demo_products' => ($start_mode === 'existing'),
            'selected_products' => get_option('masterai_builder_selected_products', array()),
        );

        // Merge business settings
        $business_settings = get_option('masterai_builder_business_settings', array());
        $settings = array_merge($settings, $business_settings);



        // Start installation

        // 0. Install Theme based on Industry
        $theme_slug = 'astra'; // Fallback

        $industry_themes = array(
            'fashion' => 'botiga',
            'food' => 'neve',
            'digital' => 'oceanwp',
            'beauty' => 'astra',
            'home' => 'storefront',
            'courses' => 'astra',
            'handmade' => 'botiga',
            'jewelry' => 'botiga',
            'services' => 'neve',
            'industrial' => 'storefront',
        );

        if (isset($industry_themes[$industry])) {
            $theme_slug = $industry_themes[$industry];
        }

        try {
            update_option('masterai_builder_recommended_theme', sanitize_key($theme_slug));

            $result = MasterAI_Template_Manager::install_template($industry, $settings);

            if (is_wp_error($result)) {
                throw new Exception($result->get_error_message());
            }

            // Mark onboarding as complete
            update_option('masterai_builder_onboarding_complete', true);

            wp_send_json_success(array(
                'message' => __('Store installed successfully!', 'masterai-store-builder'),
                'redirect' => admin_url('admin.php?page=masterai-dashboard'),
            ));

        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => 'Error: ' . $e->getMessage(),
            ));
        } catch (Throwable $t) {
            wp_send_json_error(array(
                'message' => 'Fatal Error: ' . $t->getMessage(),
            ));
        }
    }

    /**
     * Get industry preview data
     */
    public function get_industry_preview()
    {
        check_ajax_referer('masterai_builder_wizard_nonce', 'nonce');

        $industry = isset($_POST['industry']) ? sanitize_key($_POST['industry']) : '';

        if (!$industry) {
            wp_send_json_error(array('message' => __('Invalid industry', 'masterai-store-builder')));
        }

        $industries = MasterAI_Installer::get_industries();

        if (!isset($industries[$industry])) {
            wp_send_json_error(array('message' => __('Industry not found', 'masterai-store-builder')));
        }

        $industry_data = $industries[$industry];

        // Add preview image URL
        $preview_image = MasterAI_PLUGIN_URL . 'assets/images/previews/' . $industry . '.jpg';

        wp_send_json_success(array(
            'industry' => $industry_data,
            'preview_image' => $preview_image,
        ));
    }

    /**
     * Remove demo content
     */
    public function remove_demo_content()
    {
        check_ajax_referer('masterai-admin', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        $demo_importer = new MasterAI_Demo_Importer();
        $count = $demo_importer->remove_demo_content();
        $remove_demo_message = sprintf(
            /* translators: %d: Number of removed demo products. */
            __('%d demo products removed successfully', 'masterai-store-builder'),
            $count
        );

        wp_send_json_success(array(
            'message' => $remove_demo_message,
        ));
    }

    /**
     * Install demo content (Admin Page)
     */
    public function install_demo_content()
    {
        check_ajax_referer('masterai-admin', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        $industry = get_option('masterai_builder_industry', 'fashion'); // Default to fashion if not set
        $demo_importer = new MasterAI_Demo_Importer();
        $demo_importer->import_products($industry);

        // Mark as installed
        update_option('masterai_builder_demo_content_installed', true);

        wp_send_json_success(array(
            'message' => __('Demo content installed successfully', 'masterai-store-builder'),
        ));
    }

    /**
     * Reset wizard
     */
    public function reset_wizard()
    {
        check_ajax_referer('masterai-admin', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        // Reset all wizard-related options
        delete_option('masterai_builder_onboarding_complete');
        delete_option('masterai_builder_industry');
        delete_option('masterai_builder_start_mode');
        delete_option('masterai_builder_store_name');
        delete_option('masterai_builder_store_tagline');
        delete_option('masterai_builder_logo_id');
        delete_option('masterai_builder_primary_color');
        delete_option('masterai_builder_secondary_color');
        delete_option('masterai_builder_business_settings');
        delete_option('masterai_builder_template_installed');

        wp_send_json_success(array(
            'message' => __('Wizard reset successfully', 'masterai-store-builder'),
            'redirect' => admin_url('admin.php?page=masterai-wizard'),
        ));
    }
    /**
     * Save Gemini API Key
     */
    public function save_gemini_key()
    {
        check_ajax_referer('masterai_builder_wizard_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        $key = isset($_POST['key']) ? sanitize_text_field($_POST['key']) : '';

        if (empty($key)) {
            wp_send_json_error(array('message' => __('API Key is required', 'masterai-store-builder')));
        }

        update_option('masterai_builder_gemini_key', $key);

        wp_send_json_success(array('message' => __('Key saved successfully', 'masterai-store-builder')));
    }

    /**
     * Generate Product with AI
     */
    public function generate_product()
    {
        check_ajax_referer('masterai_builder_wizard_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }



        $prompt = isset($_POST['prompt']) ? sanitize_text_field($_POST['prompt']) : '';
        $target_price = isset($_POST['price']) ? sanitize_text_field($_POST['price']) : '';
        $key = get_option('masterai_builder_gemini_key');

        if (empty($prompt) || empty($key)) {
            wp_send_json_error(array('message' => __('Missing prompt or API key', 'masterai-store-builder')));
        }

        $api_url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' . $key;

        $prompt_text = "Generate a WooCommerce product based on: '$prompt'. ";
        if (!empty($target_price)) {
            $prompt_text .= "The price should be exactly or close to $$target_price. ";
        }
        $prompt_text .= "Return ONLY valid JSON with no markdown formatting. Keys: title, description, price (number only), short_description.";

        $body = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array('text' => $prompt_text)
                    )
                )
            )
        );

        $response = wp_remote_post($api_url, array(
            'body' => json_encode($body),
            'headers' => array('Content-Type' => 'application/json'),
            'timeout' => 30
        ));

        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => $response->get_error_message()));
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        // Check for API errors
        if (isset($data['error'])) {
            $error_msg = isset($data['error']['message']) ? $data['error']['message'] : __('Unknown API Error', 'masterai-store-builder');
            $error_details = isset($data['error']['details']) ? ' Details: ' . json_encode($data['error']['details']) : '';
            wp_send_json_error(array('message' => 'Gemini API Error: ' . $error_msg . $error_details));
        }

        if (empty($data['candidates'][0]['content']['parts'][0]['text'])) {
            // Debug: Log the response if possible, or return raw response for debugging
            wp_send_json_error(array('message' => __('Invalid response from AI. Response: ', 'masterai-store-builder') . json_encode($data)));
        }

        $ai_text = $data['candidates'][0]['content']['parts'][0]['text'];

        // Clean markdown code blocks if present
        $ai_text = str_replace('```json', '', $ai_text);
        $ai_text = str_replace('```', '', $ai_text);

        $product_data = json_decode($ai_text, true);

        if (!$product_data) {
            wp_send_json_error(array('message' => __('Failed to parse AI response', 'masterai-store-builder')));
        }

        // Create Product
        if (class_exists('WC_Product_Simple')) {
            $product = new WC_Product_Simple();
            $product->set_name(isset($product_data['title']) ? $product_data['title'] : $prompt);
            $product->set_description(isset($product_data['description']) ? $product_data['description'] : '');
            $product->set_short_description(isset($product_data['short_description']) ? $product_data['short_description'] : '');

            // Use target price if provided, otherwise use AI generated price
            $final_price = !empty($target_price) ? $target_price : (isset($product_data['price']) ? $product_data['price'] : '10');
            $product->set_regular_price($final_price);

            $product->set_status('publish');
            $product->save();

            // Increment count
            $generated_count = (int) get_option('masterai_builder_ai_generated_count', 0);
            update_option('masterai_builder_ai_generated_count', $generated_count + 1);

            wp_send_json_success(array(
                'id' => $product->get_id(),
                'title' => $product->get_name(),
                'price' => $product->get_price(),
                'description' => $product->get_description(),
                'categories' => wp_get_post_terms($product->get_id(), 'product_cat', array('fields' => 'names')),
                'message' => __('Product created successfully', 'masterai-store-builder')
            ));
        } else {
            wp_send_json_error(array('message' => __('WooCommerce not active', 'masterai-store-builder')));
        }
    }

    /**
     * Save Product Image from Puter.js (Base64)
     */
    public function save_product_image()
    {
        check_ajax_referer('masterai_builder_wizard_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        $product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
        $image_data = isset($_POST['image_data']) ? $_POST['image_data'] : '';

        if (!$product_id || !$image_data) {
            wp_send_json_error(array('message' => __('Missing product ID or image data', 'masterai-store-builder')));
        }

        // Handle Base64 or Remote URL
        if (preg_match('/^data:image\/(\w+);base64,/', $image_data, $type)) {
            // Base64 logic
            $image_raw = substr($image_data, strpos($image_data, ',') + 1);
            $type = strtolower($type[1]);
            $image_raw = base64_decode($image_raw);

            if ($image_raw === false) {
                wp_send_json_error(array('message' => __('Base64 decode failed', 'masterai-store-builder')));
            }
        } elseif (filter_var($image_data, FILTER_VALIDATE_URL)) {
            // Remote URL logic
            $response = wp_remote_get($image_data);
            if (is_wp_error($response)) {
                wp_send_json_error(array('message' => __('Failed to fetch remote image: ', 'masterai-store-builder') . $response->get_error_message()));
            }

            $image_raw = wp_remote_retrieve_body($response);
            $content_type = wp_remote_retrieve_header($response, 'content-type');

            // Determine extension from content-type or URL
            $type = 'jpg'; // default
            if (strpos($content_type, 'image/png') !== false)
                $type = 'png';
            elseif (strpos($content_type, 'image/gif') !== false)
                $type = 'gif';
            elseif (strpos($content_type, 'image/webp') !== false)
                $type = 'webp';
            else {
                $ext = pathinfo(wp_parse_url($image_data, PHP_URL_PATH), PATHINFO_EXTENSION);
                if ($ext)
                    $type = $ext;
            }
        } else {
            wp_send_json_error(array('message' => __('Invalid image data format', 'masterai-store-builder')));
        }

        $product = wc_get_product($product_id);
        if (!$product) {
            wp_send_json_error(array('message' => __('Product not found', 'masterai-store-builder')));
        }

        // Save to Media Library
        $upload_dir = wp_upload_dir();
        $filename = 'product-' . $product_id . '-' . time() . '.' . $type;
        $upload_path = str_replace('/', DIRECTORY_SEPARATOR, $upload_dir['path']) . DIRECTORY_SEPARATOR . $filename;

        if (!file_put_contents($upload_path, $image_raw)) {
            wp_send_json_error(array('message' => __('Failed to save image file', 'masterai-store-builder')));
        }

        $attachment = array(
            'post_mime_type' => 'image/' . $type,
            'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
            'post_content' => '',
            'post_status' => 'inherit',
            'guid' => $upload_dir['url'] . '/' . $filename
        );

        $attach_id = wp_insert_attachment($attachment, $upload_path, $product_id);

        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attach_data = wp_generate_attachment_metadata($attach_id, $upload_path);
        wp_update_attachment_metadata($attach_id, $attach_data);

        $product->set_image_id($attach_id);
        $product->save();

        wp_send_json_success(array(
            'image_url' => wp_get_attachment_url($attach_id),
            'message' => __('Image saved successfully', 'masterai-store-builder')
        ));
    }



    /**
     * Find a published page by exact title.
     *
     * @param string $title Page title.
     * @return WP_Post|null
     */
    private function get_page_by_exact_title($title)
    {
        $query = new WP_Query(array(
            'post_type' => 'page',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'title' => $title,
            'no_found_rows' => true,
            'fields' => 'all',
        ));

        if (!empty($query->posts)) {
            return $query->posts[0];
        }

        return null;
    }

    public function generate_legal_pages()
    {
        check_ajax_referer('masterai-admin', 'nonce'); // Use 'masterai-admin' nonce from dashboard

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        $store_name = get_option('masterai_builder_store_name', get_bloginfo('name'));
        $settings = get_option('masterai_builder_business_settings', array());
        $country = isset($settings['country']) ? $settings['country'] : 'US';

        $pages_created = 0;
        $pages_existed = 0;

        // Privacy Policy
        $privacy_title = __('Privacy Policy', 'masterai-store-builder');
        $existing_privacy = $this->get_page_by_exact_title($privacy_title);

        if (!$existing_privacy) {
            $privacy_template = 
                /* translators: %s: Store name. */
                __("<h1>Privacy Policy</h1>\n<p>This Privacy Policy describes how your personal information is collected, used, and shared when you visit or make a purchase from %s (the 'Site').</p>\n<h2>PERSONAL INFORMATION WE COLLECT</h2>\n<p>When you visit the Site, we automatically collect certain information about your device, including information about your web browser, IP address, time zone, and some of the cookies that are installed on your device.</p>\n<p><strong>CONTACT US</strong></p>\n<p>For more information about our privacy practices, if you have questions, or if you would like to make a complaint, please contact us by e-mail.</p>", 'masterai-store-builder');
            $privacy_content = sprintf(
                $privacy_template,
                esc_html($store_name)
            );

            $page_id = wp_insert_post(array(
                'post_title' => $privacy_title,
                'post_content' => $privacy_content,
                'post_status' => 'publish',
                'post_type' => 'page',
            ));

            if (!is_wp_error($page_id)) {
                // Set as Privacy Policy page in WP settings
                update_option('wp_page_for_privacy_policy', $page_id);
                $pages_created++;
            }
        } else {
            $pages_existed++;
        }

        // Refund Policy
        $refund_title = __('Refund and Returns Policy', 'masterai-store-builder');
        $existing_refund = $this->get_page_by_exact_title($refund_title);

        if (!$existing_refund) {
            $refund_content = sprintf(
                __("<h1>Refund and Returns Policy</h1>\n<h3>Overview</h3>\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\n<h2>Refunds</h2>\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\n<h2>Need help?</h2>\n<p>Contact us for questions related to refunds and returns.</p>", 'masterai-store-builder')
            );

            $page_id = wp_insert_post(array(
                'post_title' => $refund_title,
                'post_content' => $refund_content,
                'post_status' => 'publish',
                'post_type' => 'page',
            ));

            if (!is_wp_error($page_id)) {
                $pages_created++;
            }
        } else {
            $pages_existed++;
        }

        if ($pages_created > 0) {
            $legal_pages_message = sprintf(
                /* translators: %d: Number of legal pages created. */
                __('%d legal pages created successfully.', 'masterai-store-builder'),
                $pages_created
            );
            wp_send_json_success(array(
                'message' => $legal_pages_message
            ));
        } elseif ($pages_existed > 0) {
            wp_send_json_error(array(
                'message' => __('Legal pages already exist.', 'masterai-store-builder')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to create pages.', 'masterai-store-builder')
            ));
        }
    }

    /**
     * Toggle Industrial Filter
     */
    public function toggle_industrial_filter()
    {
        check_ajax_referer('masterai-admin', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        $enabled = !empty($_POST['enabled']);
        update_option('masterai_builder_enable_industrial_filter', $enabled);

        wp_send_json_success(array(
            'message' => __('Preference saved', 'masterai-store-builder'),
            'enabled' => $enabled
        ));
    }
    /**
     * Generate Store Description with AI
     */
    public function generate_store_description()
    {
        check_ajax_referer('masterai_builder_wizard_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        $store_name = isset($_POST['store_name']) ? sanitize_text_field($_POST['store_name']) : '';
        $industry = isset($_POST['industry']) ? sanitize_key($_POST['industry']) : '';
        $key = get_option('masterai_builder_gemini_key');

        if (empty($key)) {
            wp_send_json_error(array('message' => __('AI API Key is missing. Please enable AI in the wizard header.', 'masterai-store-builder')));
        }

        if (empty($store_name)) {
            wp_send_json_error(array('message' => __('Please enter a store name first.', 'masterai-store-builder')));
        }

        $api_url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' . $key;

        $prompt_text = "Generate 3 short, catchy store descriptions (max 2 sentences each) for a WooCommerce store named '$store_name' in the '$industry' industry. Return ONLY a valid JSON array of strings.";

        $body = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array('text' => $prompt_text)
                    )
                )
            )
        );

        $response = wp_remote_post($api_url, array(
            'body' => json_encode($body),
            'headers' => array('Content-Type' => 'application/json'),
            'timeout' => 30
        ));

        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => $response->get_error_message()));
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        if (isset($data['error'])) {
            $error_msg = isset($data['error']['message']) ? $data['error']['message'] : __('Unknown API Error', 'masterai-store-builder');
            wp_send_json_error(array('message' => 'Gemini API Error: ' . $error_msg));
        }

        if (empty($data['candidates'][0]['content']['parts'][0]['text'])) {
            wp_send_json_error(array('message' => __('Invalid response from AI.', 'masterai-store-builder')));
        }

        $ai_text = $data['candidates'][0]['content']['parts'][0]['text'];

        // Clean markdown code blocks
        $ai_text = str_replace('```json', '', $ai_text);
        $ai_text = str_replace('```', '', $ai_text);

        $descriptions = json_decode($ai_text, true);

        if (!$descriptions || !is_array($descriptions)) {
            wp_send_json_error(array('message' => __('Failed to parse AI response.', 'masterai-store-builder')));
        }

        wp_send_json_success(array(
            'descriptions' => $descriptions,
            'message' => __('Descriptions generated successfully', 'masterai-store-builder')
        ));
    }

    /**
     * Fetch Exchange Rates for Multi-Currency
     */
    public function fetch_exchange_rates()
    {
        check_ajax_referer('masterai-admin', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        // Save submitted currencies if present (Auto-Save behavior)
        if (isset($_POST['enabled_currencies'])) {
            $enabled_currencies = array();
            foreach ($_POST['enabled_currencies'] as $code => $data) {
                if (isset($data['enabled'])) {
                    $enabled_currencies[$code] = array(
                        'rate' => floatval(isset($data['rate']) ? $data['rate'] : 1),
                        'adjustment' => floatval(isset($data['adjustment']) ? $data['adjustment'] : 0)
                    );
                }
            }
            update_option('masterai_builder_enabled_currencies', $enabled_currencies);
        }

        // Save API Key if submitted
        if (isset($_POST['exchange_api_key'])) {
            update_option('masterai_builder_exchange_rate_api_key', sanitize_text_field(wp_unslash($_POST['exchange_api_key'])));
        }

        // Get enabled currencies
        $enabled_currencies = get_option('masterai_builder_enabled_currencies', array());

        if (empty($enabled_currencies)) {
            wp_send_json_error(array('message' => __('No currencies enabled. Please enable at least one currency first.', 'masterai-store-builder')));
        }

        // Initialize currency converter
        $converter = new MasterAI_Currency_Converter();

        // Force refresh rates (clears cache and fetches new rates)
        $success = $converter->manual_update();

        if ($success) {
            // Get updated currencies
            $updated_currencies = get_option('masterai_builder_enabled_currencies', array());
            $currency_update_message = sprintf(
                /* translators: %d: Number of currencies updated. */
                __('%d currency rates updated successfully', 'masterai-store-builder'),
                count($updated_currencies)
            );

            wp_send_json_success(array(
                'message' => $currency_update_message,
                'rates' => $updated_currencies
            ));
        } else {
            wp_send_json_error(array('message' => __('Failed to fetch exchange rates. Please check your API key or try again.', 'masterai-store-builder')));
        }
    }
}
