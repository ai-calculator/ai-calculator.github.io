<?php
/**
 * MasterAI Template Manager
 *
 * @package MasterAI_Builder
 */

if (!defined('ABSPATH')) {
    exit;
}

class MasterAI_Template_Manager
{

    /**
     * Install template for industry
     */
    public static function install_template($industry, $settings = array())
    {
        // Load template configuration
        $config = self::get_template_config($industry);

        if (!$config) {
            return new WP_Error('invalid_industry', __('Invalid industry selected', 'masterai-store-builder'));
        }

        // Install in steps
        $steps = array(
            'theme' => array('self', 'install_theme'),
            'pages' => array('self', 'create_pages'),
            'products' => array('self', 'import_products'),
            'settings' => array('self', 'configure_woocommerce'),
            'navigation' => array('self', 'setup_navigation'),
        );

        $results = array();

        foreach ($steps as $step => $callback) {
            $result = call_user_func($callback, $industry, $config, $settings);
            $results[$step] = $result;

            if (is_wp_error($result)) {
                return $result;
            }
        }

        // Apply branding
        self::apply_branding($settings);

        // Mark as complete
        update_option('masterai_builder_template_installed', true);
        update_option('masterai_builder_industry', $industry);

        return $results;
    }

    /**
     * Get template configuration
     */
    private static function get_template_config($industry)
    {
        $config_file = MasterAI_PLUGIN_DIR . 'templates/' . $industry . '/config.php';

        if (!file_exists($config_file)) {
            return false;
        }

        return include $config_file;
    }

    /**
     * Install or activate theme
     */
    private static function install_theme($industry, $config, $settings)
    {
        $theme_slug = isset($config['theme']) ? $config['theme'] : 'storefront';
        update_option('masterai_builder_recommended_theme', sanitize_key($theme_slug));

        // Apply theme mods only when the selected theme is currently active.
        $active_theme = wp_get_theme();
        if ($active_theme && $active_theme->get_stylesheet() === $theme_slug) {
            self::apply_theme_mods($industry, $settings);
        }

        return true;
    }

    /**
     * Apply theme modifications
     */
    private static function apply_theme_mods($industry, $settings)
    {
        // Set header layout
        set_theme_mod('storefront_header_layout', 'default');

        // Set colors if provided
        if (!empty($settings['primary_color'])) {
            set_theme_mod('storefront_accent_color', $settings['primary_color']);
            set_theme_mod('storefront_button_background_color', $settings['primary_color']);
        }

        if (!empty($settings['secondary_color'])) {
            set_theme_mod('storefront_button_alt_background_color', $settings['secondary_color']);
        }

        // Set logo if provided
        if (!empty($settings['logo_id'])) {
            set_theme_mod('custom_logo', $settings['logo_id']);
        }
    }

    /**
     * Create essential pages
     */
    private static function create_pages($industry, $config, $settings)
    {
        $pages = array(
            'shop' => array(
                'title' => __('Shop', 'masterai-store-builder'),
                'content' => '',
                'template' => 'default',
            ),
            'cart' => array(
                'title' => __('Cart', 'masterai-store-builder'),
                'content' => '[woocommerce_cart]',
                'template' => 'default',
            ),
            'checkout' => array(
                'title' => __('Checkout', 'masterai-store-builder'),
                'content' => '[woocommerce_checkout]',
                'template' => 'default',
            ),
            'my-account' => array(
                'title' => __('My Account', 'masterai-store-builder'),
                'content' => '[woocommerce_my_account]',
                'template' => 'default',
            ),
            'about' => array(
                'title' => __('About Us', 'masterai-store-builder'),
                'content' => self::get_page_content('about', $industry),
                'template' => 'default',
            ),
            'contact' => array(
                'title' => __('Contact', 'masterai-store-builder'),
                'content' => self::get_page_content('contact', $industry),
                'template' => 'default',
            ),
        );

        $created_pages = array();

        foreach ($pages as $slug => $page_data) {
            // Check if page already exists
            $existing_page = get_page_by_path($slug);

            if (!$existing_page) {
                $page_id = wp_insert_post(array(
                    'post_title' => $page_data['title'],
                    'post_content' => $page_data['content'],
                    'post_status' => 'publish',
                    'post_type' => 'page',
                    'post_name' => $slug,
                ));

                if (!is_wp_error($page_id)) {
                    $created_pages[$slug] = $page_id;

                    // Set WooCommerce pages
                    switch ($slug) {
                        case 'shop':
                            update_option('woocommerce_shop_page_id', $page_id);
                            break;
                        case 'cart':
                            update_option('woocommerce_cart_page_id', $page_id);
                            break;
                        case 'checkout':
                            update_option('woocommerce_checkout_page_id', $page_id);
                            break;
                        case 'my-account':
                            update_option('woocommerce_myaccount_page_id', $page_id);
                            break;
                    }
                }
            } else {
                $created_pages[$slug] = $existing_page->ID;
            }
        }

        return $created_pages;
    }

    /**
     * Get page content template
     */
    private static function get_page_content($page_type, $industry)
    {
        $content_file = MasterAI_PLUGIN_DIR . 'templates/' . $industry . '/pages/' . $page_type . '.txt';

        if (file_exists($content_file)) {
            return file_get_contents($content_file);
        }

        // Default content
        $defaults = array(
            'about' => '<h2>About Our Store</h2><p>Welcome to our store! We\'re passionate about bringing you the best products with exceptional customer service.</p>',
            'contact' => '<h2>Get in Touch</h2><p>Have questions? We\'d love to hear from you. Send us a message and we\'ll respond as soon as possible.</p>',
        );

        return isset($defaults[$page_type]) ? $defaults[$page_type] : '';
    }

    /**
     * Import demo products
     */
    private static function import_products($industry, $config, $settings)
    {
        // Skip if user already has products or chose not to import
        if (!empty($settings['skip_demo_products'])) {
            return array('skipped' => true);
        }

        $demo_importer = new MasterAI_Demo_Importer();
        return $demo_importer->import_products($industry, $settings);
    }

    /**
     * Configure WooCommerce settings
     */
    private static function configure_woocommerce($industry, $config, $settings)
    {
        // Currency
        if (!empty($settings['currency'])) {
            update_option('woocommerce_currency', $settings['currency']);
        }

        // Country
        if (!empty($settings['country'])) {
            update_option('woocommerce_default_country', $settings['country']);
        }

        // Enable guest checkout
        update_option('woocommerce_enable_guest_checkout', 'yes');

        // Enable account creation during checkout
        update_option('woocommerce_enable_signup_and_login_from_checkout', 'yes');

        // Redirect to cart after adding product
        update_option('woocommerce_cart_redirect_after_add', 'no');

        // Enable AJAX add to cart
        update_option('woocommerce_enable_ajax_add_to_cart', 'yes');

        // Shipping settings
        self::setup_simplified_shipping_zones($settings);

        // Payment gateways
        if (!empty($settings['payment_methods'])) {
            self::enable_payment_gateways($settings['payment_methods']);
        }

        // Disable WooCommerce setup wizard
        update_option('woocommerce_onboarding_profile', array(
            'completed' => true,
        ));

        return true;
    }

    /**
     * Setup simplified shipping zones (Visual Shipping Map)
     */
    private static function setup_simplified_shipping_zones($settings)
    {
        $shipping_zones = WC_Shipping_Zones::get_zones();

        // Clear existing zones if any (for fresh setup)
        // In a real scenario, we might want to be more careful, but for this wizard, we enforce the simplified model
        foreach ($shipping_zones as $zone_data) {
            $zone = new WC_Shipping_Zone($zone_data['id']);
            $zone->delete();
        }

        // 1. Domestic Zone (Store Country)
        if (!empty($settings['shipping_domestic'])) {
            $zone = new WC_Shipping_Zone();
            $zone->set_zone_name(__('Domestic', 'masterai-store-builder'));
            $zone->set_zone_order(1);
            $zone->add_location($settings['country'], 'country');
            $zone->save();

            $zone->add_shipping_method('flat_rate');
            $methods = $zone->get_shipping_methods();
            foreach ($methods as $instance_id => $method) {
                if ($method->id === 'flat_rate') {
                    $rate = !empty($settings['shipping_domestic_rate']) ? floatval($settings['shipping_domestic_rate']) : 5.00;
                    update_option('woocommerce_flat_rate_' . $instance_id . '_settings', array(
                        'title' => __('Flat Rate', 'masterai-store-builder'),
                        'cost' => $rate,
                    ));
                }
            }
        }

        // 2. International Zone (Rest of World)
        if (!empty($settings['shipping_international'])) {
            $zone = new WC_Shipping_Zone();
            $zone->set_zone_name(__('International', 'masterai-store-builder'));
            $zone->set_zone_order(2);
            // No locations = Rest of World in WC
            $zone->save();

            $zone->add_shipping_method('flat_rate');
            $methods = $zone->get_shipping_methods();
            foreach ($methods as $instance_id => $method) {
                if ($method->id === 'flat_rate') {
                    $rate = !empty($settings['shipping_international_rate']) ? floatval($settings['shipping_international_rate']) : 15.00;
                    update_option('woocommerce_flat_rate_' . $instance_id . '_settings', array(
                        'title' => __('Flat Rate', 'masterai-store-builder'),
                        'cost' => $rate,
                    ));
                }
            }
        }
    }

    /**
     * Setup free shipping
     */
    private static function setup_free_shipping()
    {
        $shipping_zones = WC_Shipping_Zones::get_zones();

        if (empty($shipping_zones)) {
            $zone = new WC_Shipping_Zone();
            $zone->set_zone_name(__('Default Zone', 'masterai-store-builder'));
            $zone->set_zone_order(0);
            $zone->save();

            $zone->add_shipping_method('free_shipping');
        }
    }

    /**
     * Enable payment gateways
     */
    private static function enable_payment_gateways($methods)
    {
        $gateway_map = array(
            'stripe' => 'stripe',
            'paypal' => 'paypal',
            'bank' => 'bacs',
            'cod' => 'cod',
        );

        foreach ($methods as $method => $enabled) {
            if ($enabled && isset($gateway_map[$method])) {
                $gateway_id = $gateway_map[$method];
                update_option('woocommerce_' . $gateway_id . '_settings', array(
                    'enabled' => 'yes',
                ));
            }
        }
    }

    /**
     * Setup navigation menus
     */
    private static function setup_navigation($industry, $config, $settings)
    {
        // Create primary menu
        $menu_name = __('Primary Menu', 'masterai-store-builder');
        $menu_exists = wp_get_nav_menu_object($menu_name);

        if (!$menu_exists) {
            $menu_id = wp_create_nav_menu($menu_name);

            // Add menu items
            $items = array(
                array('title' => __('Home', 'masterai-store-builder'), 'url' => home_url('/')),
                array('title' => __('Shop', 'masterai-store-builder'), 'url' => get_permalink(wc_get_page_id('shop'))),
                array('title' => __('About', 'masterai-store-builder'), 'url' => home_url('/about')),
                array('title' => __('Contact', 'masterai-store-builder'), 'url' => home_url('/contact')),
            );

            foreach ($items as $item) {
                wp_update_nav_menu_item($menu_id, 0, array(
                    'menu-item-title' => $item['title'],
                    'menu-item-url' => $item['url'],
                    'menu-item-status' => 'publish',
                ));
            }

            // Assign to theme location
            $locations = get_theme_mod('nav_menu_locations');
            $locations['primary'] = $menu_id;
            set_theme_mod('nav_menu_locations', $locations);
        }

        return true;
    }

    /**
     * Apply branding (logo, colors, etc.)
     */
    private static function apply_branding($settings)
    {
        // Store name
        if (!empty($settings['store_name'])) {
            update_option('blogname', $settings['store_name']);
            update_option('masterai_builder_store_name', $settings['store_name']);
        }

        // Store tagline
        if (!empty($settings['store_tagline'])) {
            update_option('blogdescription', $settings['store_tagline']);
            update_option('masterai_builder_store_tagline', $settings['store_tagline']);
        }

        // Colors
        if (!empty($settings['primary_color'])) {
            update_option('masterai_builder_primary_color', $settings['primary_color']);
        }

        if (!empty($settings['secondary_color'])) {
            update_option('masterai_builder_secondary_color', $settings['secondary_color']);
        }

        // Logo handled in theme mods

        return true;
    }
}
