<?php
/**
 * MasterAI Theme Customizer
 *
 * @package MasterAI_Builder
 */

if (!defined('ABSPATH')) {
    exit;
}

class MasterAI_Theme_Customizer
{

    /**
     * Constructor
     */
    public function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_custom_styles'), 100);
        add_action('customize_register', array($this, 'register_customizer_settings'));
    }

    /**
     * Enqueue custom styles based on brand colors
     */
    public function enqueue_custom_styles()
    {
        $primary_color = sanitize_hex_color(get_option('masterai_builder_primary_color', '#FF6B6B'));
        $secondary_color = sanitize_hex_color(get_option('masterai_builder_secondary_color', '#4ECDC4'));

        if (!$primary_color && !$secondary_color) {
            return;
        }

        if (!$primary_color) {
            $primary_color = '#FF6B6B';
        }

        if (!$secondary_color) {
            $secondary_color = '#4ECDC4';
        }

        $logo_width = absint(get_option('masterai_builder_logo_width', 150));
        if ($logo_width < 1) {
            $logo_width = 150;
        }

        $custom_css = $this->generate_custom_css($primary_color, $secondary_color, $logo_width);

        wp_register_style('masterai-custom-branding', false, array(), MasterAI_VERSION);
        wp_enqueue_style('masterai-custom-branding');
        wp_add_inline_style('masterai-custom-branding', esc_html($custom_css));
    }

    /**
     * Generate custom CSS
     */
    private function generate_custom_css($primary, $secondary, $logo_width = 150)
    {
        $css = "
        /* MasterAI Brand Colors */
        :root {
            --masterai-primary: {$primary};
            --masterai-secondary: {$secondary};
        }
        
        /* Primary color applications */
        .woocommerce-Button.button,
        .woocommerce button.button,
        .woocommerce a.button,
        .woocommerce #respond input#submit,
        .woocommerce input.button,
        button.button.alt,
        a.button.alt,
        button.button.loading {
            background-color: {$primary} !important;
            border-color: {$primary} !important;
        }
        
        .woocommerce-Button.button:hover,
        .woocommerce button.button:hover,
        .woocommerce a.button:hover,
        .woocommerce #respond input#submit:hover,
        .woocommerce input.button:hover {
            background-color: " . $this->adjust_brightness($primary, -20) . " !important;
        }
        
        /* Links and accents */
        a,
        .site-title a,
        .main-navigation a:hover,
        .woocommerce-MyAccount-navigation li.is-active a,
        .woocommerce .star-rating span,
        .price ins .amount,
        .price > .amount {
            color: {$primary};
        }
        
        /* Secondary color */
        .woocommerce-info,
        .woocommerce-message {
            border-top-color: {$secondary};
        }
        
        .woocommerce-info::before,
        .woocommerce-message::before {
            color: {$secondary};
        }
        
        /* Product badges */
        .onsale,
        .woocommerce span.onsale {
            background-color: {$secondary};
        }
        
        /* Navigation */
        .main-navigation ul.menu > li.current-menu-item > a,
        .main-navigation ul.menu > li.current-menu-ancestor > a {
            color: {$primary};
        }
        
        /* Widgets */
        .widget a:hover,
        .widget-area .widget a:hover {
            color: {$secondary};
        }

        /* Logo Width */
        .site-header .site-branding img,
        .custom-logo-link img,
        .wp-block-site-logo img,
        .site-logo img,
        header .logo img {
            max-width: {$logo_width}px !important;
            width: {$logo_width}px !important;
            height: auto !important;
        }
        ";

        return $css;
    }

    /**
     * Adjust color brightness
     */
    private function adjust_brightness($hex, $steps)
    {
        // Remove # if present
        $hex = str_replace('#', '', $hex);

        // Convert to RGB
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));

        // Adjust
        $r = max(0, min(255, $r + $steps));
        $g = max(0, min(255, $g + $steps));
        $b = max(0, min(255, $b + $steps));

        // Convert back to hex
        return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT) .
            str_pad(dechex($g), 2, '0', STR_PAD_LEFT) .
            str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
    }

    /**
     * Register customizer settings
     */
    public function register_customizer_settings($wp_customize)
    {
        // Add MasterAI section
        $wp_customize->add_section('masterai_builder_branding', array(
            'title' => __('Store Branding', 'masterai-store-builder'),
            'priority' => 30,
        ));

        // Primary color
        $wp_customize->add_setting('masterai_builder_primary_color', array(
            'default' => '#FF6B6B',
            'sanitize_callback' => 'sanitize_hex_color',
        ));

        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'masterai_builder_primary_color', array(
            'label' => __('Primary Brand Color', 'masterai-store-builder'),
            'section' => 'masterai_builder_branding',
            'settings' => 'masterai_builder_primary_color',
        )));

        // Secondary color
        $wp_customize->add_setting('masterai_builder_secondary_color', array(
            'default' => '#4ECDC4',
            'sanitize_callback' => 'sanitize_hex_color',
        ));

        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'masterai_builder_secondary_color', array(
            'label' => __('Secondary Brand Color', 'masterai-store-builder'),
            'section' => 'masterai_builder_branding',
            'settings' => 'masterai_builder_secondary_color',
        )));
    }
}

// Initialize
new MasterAI_Theme_Customizer();
