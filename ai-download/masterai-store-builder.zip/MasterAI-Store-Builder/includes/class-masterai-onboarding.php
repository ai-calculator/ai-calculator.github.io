<?php
/**
 * MasterAI Onboarding Wizard
 *
 * @package MasterAI_Builder
 */

if (!defined('ABSPATH')) {
    exit;
}

class MasterAI_Onboarding
{

    /**
     * Wizard steps
     */
    private $steps = array();

    /**
     * Detected Country Code
     */
    private $current_country = 'US';

    /**
     * WC Countries List
     */
    private $countries = array();

    /**
     * Detected Currency Code
     */
    private $currency_code = 'USD';

    /**
     * Detected Currency Symbol
     */
    private $currency_symbol = '$';

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->steps = array(
            'welcome' => __('Welcome', 'masterai-store-builder'),
            'industry' => __('Industry', 'masterai-store-builder'),
            'theme' => __('Theme', 'masterai-store-builder'),
            'products' => __('Select Products', 'masterai-store-builder'),
            'details' => __('Store Details', 'masterai-store-builder'),
            'settings' => __('Business Settings', 'masterai-store-builder'),
            'install' => __('Installation', 'masterai-store-builder'),
        );

        add_action('admin_menu', array($this, 'add_wizard_page'));
        add_action('admin_init', array($this, 'redirect_to_wizard'));
        add_action('wp_ajax_masterai_builder_upload_theme', array($this, 'masterai_builder_upload_theme'));
        add_action('wp_ajax_masterai_builder_save_wizard_step', array($this, 'masterai_builder_save_wizard_step'));
        add_action('wp_ajax_masterai_builder_install_template', array($this, 'masterai_builder_install_template'));
    }

    /**
     * Add wizard page to admin menu
     */
    public function add_wizard_page()
    {
        add_submenu_page(
            'masterai-dashboard',
            __('Store Setup Wizard', 'masterai-store-builder'),
            __('Store Setup', 'masterai-store-builder'),
            'manage_options',
            'masterai-wizard',
            array($this, 'render_wizard')
        );
    }

    /**
     * Redirect to wizard after activation
     */
    public function redirect_to_wizard()
    {
        if (get_transient('masterai_builder_activation_redirect')) {
            delete_transient('masterai_builder_activation_redirect');

            if (!get_option('masterai_builder_onboarding_complete')) {
                wp_safe_redirect(admin_url('admin.php?page=masterai-wizard'));
                exit;
            }
        }
    }

    /**
     * Render the wizard
     */
    public function render_wizard()
    {
        $step = isset($_GET['step']) ? sanitize_key($_GET['step']) : 'welcome';

        // Validate step
        if (!array_key_exists($step, $this->steps)) {
            $step = 'welcome';
        }

        wp_enqueue_media();

        // Add critical inline CSS to prevent FOUC
        $critical_css = "
            .masterai-wizard-wrapper { 
                max-width: 1200px; 
                margin: 40px auto; 
                background: #fff; 
                border-radius: 8px; 
                box-shadow: 0 2px 8px rgba(0,0,0,0.1); 
                opacity: 1;
            }
            .masterai-wizard-header { 
                background: linear-gradient(135deg, #7F56D9 0%, #5B48B9 100%); 
                padding: 30px 40px 50px; 
                border-radius: 8px 8px 0 0; 
                color: #fff; 
            }
            .header-content {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 40px;
            }
            .masterai-progress-bar {
                display: flex;
                justify-content: space-between;
                max-width: 800px;
                margin: 0 auto;
                position: relative;
            }
            .masterai-progress-bar .step {
                flex: 1;
                text-align: center;
                position: relative;
            }
            .masterai-progress-bar .step-number {
                width: 32px;
                height: 32px;
                border: 2px solid rgba(255, 255, 255, 0.3);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto 8px;
            }
            .masterai-progress-bar .step-name {
                font-size: 12px;
                display: block;
            }
            .masterai-wizard-content { 
                background: #fff; 
                padding: 20px; 
                min-height: 400px; 
                border-radius: 0 0 8px 8px; 
            }
            .masterai-step { margin: 0; }
            .masterai-step h2 { margin: 0 0 10px 0; font-size: 24px; color: #1e1e1e; }
        ";

        wp_enqueue_style('wp-color-picker');
        wp_enqueue_style('masterai-wizard', MasterAI_PLUGIN_URL . 'assets/css/wizard.css', array(), time());
        $wizard_deps = array('jquery', 'wp-color-picker');
        if (file_exists(MasterAI_PLUGIN_DIR . 'assets/js/puter.js')) {
            wp_enqueue_script('puter-js', MasterAI_PLUGIN_URL . 'assets/js/puter.js', array(), MasterAI_VERSION, true);
            $wizard_deps[] = 'puter-js';
        }
        wp_enqueue_script('masterai-wizard', MasterAI_PLUGIN_URL . 'assets/js/wizard.js', $wizard_deps, time() + 3, true);
        wp_add_inline_style('masterai-wizard', esc_html($critical_css));

        // Detect Geolocation and Countries
        $this->countries = WC()->countries->get_countries();
        $location = class_exists('WC_Geolocation') ? WC_Geolocation::geolocate_ip() : array('country' => 'US');
        $this->current_country = !empty($location['country']) ? $location['country'] : 'US';

        $country_currencies = array(
            'US' => 'USD',
            'GB' => 'GBP',
            'CA' => 'CAD',
            'AU' => 'AUD',
            'JP' => 'JPY',
            'IN' => 'INR',
            'NZ' => 'NZD',
            'CH' => 'CHF',
            'HK' => 'HKD',
            'SG' => 'SGD',
            'SE' => 'SEK',
            'DK' => 'DKK',
            'NO' => 'NOK',
            'ZA' => 'ZAR',
            'CN' => 'CNY',
            'BR' => 'BRL',
            'MX' => 'MXN',
            'KR' => 'KRW',
            'PL' => 'PLN',
            'TR' => 'TRY',
            'AT' => 'EUR',
            'BE' => 'EUR',
            'CY' => 'EUR',
            'EE' => 'EUR',
            'FI' => 'EUR',
            'FR' => 'EUR',
            'DE' => 'EUR',
            'GR' => 'EUR',
            'IE' => 'EUR',
            'IT' => 'EUR',
            'LV' => 'EUR',
            'LT' => 'EUR',
            'LU' => 'EUR',
            'MT' => 'EUR',
            'NL' => 'EUR',
            'PT' => 'EUR',
            'SK' => 'EUR',
            'SI' => 'EUR',
            'ES' => 'EUR'
        );
        $this->currency_code = isset($country_currencies[$this->current_country]) ? $country_currencies[$this->current_country] : 'USD';

        $currency_symbols = array(
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'CAD' => '$',
            'AUD' => '$',
            'JPY' => '¥',
            'INR' => '₹',
            'NZD' => '$',
            'CHF' => 'Fr',
            'HKD' => '$',
            'SGD' => '$',
            'SEK' => 'kr',
            'DKK' => 'kr',
            'NOK' => 'kr',
            'ZAR' => 'R',
            'CNY' => '¥',
            'BRL' => 'R$',
            'MXN' => '$',
            'KRW' => '₩',
            'PLN' => 'zł',
            'TRY' => '₺'
        );
        $this->currency_symbol = isset($currency_symbols[$this->currency_code]) ? $currency_symbols[$this->currency_code] : '$';

        // Localize script
        wp_localize_script('masterai-wizard', 'masteraiWizard', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('masterai_builder_wizard_nonce'),
            'industries' => MasterAI_Installer::get_industries(),
            'ai_enabled' => (bool) get_option('masterai_builder_gemini_key'),
            'currency_symbol' => $this->currency_symbol,
            'currency_code' => $this->currency_code,
            'assets_url' => MasterAI_PLUGIN_URL . 'assets/',
        ));

        ?>
        <div class="masterai-wizard-wrapper">
            <?php $this->render_header($step); ?>
            <div class="masterai-wizard-content">
                <?php
                foreach ($this->steps as $step_key => $step_label) {
                    $method = 'render_' . $step_key . '_step';
                    $is_active = ($step_key === $step);
                    $style = $is_active ? '' : 'display: none;';

                    if (method_exists($this, $method)) {
                        echo '<div class="masterai-step-container" id="step-' . esc_attr($step_key) . '" style="' . esc_attr($style) . '">';
                        $this->$method();
                        echo '</div>';
                    }
                }
                ?>
            </div>

            <!-- AI Settings Modal -->
            <div id="masterai-ai-modal" class="masterai-modal-overlay" style="display: none;">
                <div class="masterai-wizard-modal">
                    <button class="masterai-modal-close" type="button">&times;</button>
                    <h2><?php esc_html_e('Enable AI Features', 'masterai-store-builder'); ?></h2>
                    <p><?php esc_html_e('Enter your free Gemini API key to unlock AI content generation.', 'masterai-store-builder'); ?>
                    </p>
                    <div class="masterai-form-group">
                        <label
                            for="masterai_builder_gemini_key"><?php esc_html_e('Gemini API Key', 'masterai-store-builder'); ?></label>
                        <input type="text" id="masterai_builder_gemini_key" class="regular-text" placeholder="Enter API Key"
                            value="<?php echo esc_attr(get_option('masterai_builder_gemini_key')); ?>">
                        <p class="description">
                            <a href="https://aistudio.google.com/app/apikey"
                                target="_blank"><?php esc_html_e('Get your free key here', 'masterai-store-builder'); ?></a>
                        </p>
                    </div>
                    <div class="masterai-modal-actions">
                        <button type="button" class="button button-primary"
                            id="masterai-save-ai-key"><?php esc_html_e('Save & Enable', 'masterai-store-builder'); ?></button>
                    </div>
                </div>
            </div>

            <!-- AI Creation Modal -->
            <div id="masterai-ai-creation-modal" class="masterai-modal-overlay" style="display: none;">
                <div class="masterai-wizard-modal" style="max-width: 800px;">
                    <button class="masterai-modal-close" type="button">&times;</button>
                    <div class="masterai-modal-header">
                        <h2><?php esc_html_e('AI Product Writer', 'masterai-store-builder'); ?></h2>
                    </div>
                    <div class="masterai-modal-body">
                        <!-- Step 1: Input -->
                        <div class="masterai-ai-step-input">
                            <div class="form-group">
                                <label
                                    for="masterai-ai-input-prompt"><?php esc_html_e('Product Name', 'masterai-store-builder'); ?></label>
                                <input type="text" id="masterai-ai-input-prompt"
                                    placeholder="<?php esc_html_e('e.g. Blue denim jacket', 'masterai-store-builder'); ?>" autofocus>
                            </div>
                            <div class="form-group">
                                <label for="masterai-ai-input-price"><?php
                                /* translators: %s: Currency symbol */
                                printf(esc_html__('Price (%s)', 'masterai-store-builder'), esc_html($this->currency_symbol));
                                ?></label>
                                <input type="number" id="masterai-ai-input-price" placeholder="50.00" step="0.01">
                            </div>
                            <button type="button" class="masterai-button-generate" id="masterai-ai-generate-btn">
                                <span class="dashicons dashicons-superhero"></span>
                                <?php esc_html_e('Generate Product', 'masterai-store-builder'); ?>
                            </button>
                        </div>

                        <!-- Step 2: Loading -->
                        <div class="masterai-ai-step-loading" style="display: none; text-align: center; padding: 20px;">
                            <div class="masterai-spinner dashicons dashicons-update"
                                style="font-size: 40px; width: 40px; height: 40px; margin-bottom: 20px; color: #667eea;"></div>
                            <h3><?php esc_html_e('Generating Magic...', 'masterai-store-builder'); ?></h3>
                            <p><?php esc_html_e('Writing description and finding images.', 'masterai-store-builder'); ?></p>
                            <p style="font-size: 13px; color: #94a3b8; margin-top: 10px;">
                                <?php esc_html_e('This may take 30 seconds to 1 minute...', 'masterai-store-builder'); ?>
                            </p>
                        </div>

                        <!-- Step 3: Preview -->
                        <div class="masterai-ai-step-preview" style="display: none;">
                            <div class="masterai-ai-preview-card">
                                <!-- Populated via JS -->
                            </div>
                            <div class="masterai-ai-preview-actions">
                                <button type="button" class="masterai-button-secondary" id="masterai-ai-retry-btn">
                                    <?php esc_html_e('Try Again', 'masterai-store-builder'); ?>
                                </button>
                                <button type="button" class="masterai-button-add" id="masterai-ai-add-btn">
                                    <?php esc_html_e('Add Product', 'masterai-store-builder'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render wizard header with progress
     */
    private function render_header($current_step)
    {
        ?>
        <div class="masterai-wizard-header">
            <div class="header-content">
                <h1><?php esc_html_e('Store Setup', 'masterai-store-builder'); ?>
                </h1>
                <div style="display: flex; gap: 10px;">

                    <button type="button" class="button masterai-ai-btn" id="masterai-enable-ai">
                        <span class="dashicons dashicons-superhero"></span> <?php esc_html_e('Enable AI', 'masterai-store-builder'); ?>
                    </button>
                </div>
            </div>
            <div class="masterai-progress-bar">
                <?php
                $step_number = 1;
                foreach ($this->steps as $step_key => $step_name) {
                    $classes = array('step');

                    $current_index = array_search($current_step, array_keys($this->steps));
                    $this_index = array_search($step_key, array_keys($this->steps));

                    if ($this_index < $current_index) {
                        $classes[] = 'complete';
                    } elseif ($step_key === $current_step) {
                        $classes[] = 'active';
                    }

                    printf(
                        '<div class="%s" data-step="%s"><span class="step-number">%d</span><span class="step-name">%s</span></div>',
                        esc_attr(implode(' ', $classes)),
                        esc_attr($step_key),
                        esc_html($step_number),
                        esc_html($step_name)
                    );
                    $step_number++;
                }
                ?>
            </div>
        </div>
        <?php
    }

    /**
     * Step 1: Welcome
     */
    private function render_welcome_step()
    {
        ?>
        <div class="masterai-step masterai-step-welcome">
            <div class="masterai-welcome-content">
                <h2><?php esc_html_e('Welcome to MasterAI Store Builder!', 'masterai-store-builder'); ?></h2>
                <p class="lead">
                    <?php esc_html_e('Let\'s set up your professional online store in just 5 minutes.', 'masterai-store-builder'); ?>
                </p>

                <div class="masterai-features">
                    <div class="feature">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php esc_html_e('Industry-Specific Templates', 'masterai-store-builder'); ?></strong>
                        <p><?php esc_html_e('Pre-designed for your business type', 'masterai-store-builder'); ?></p>
                    </div>
                    <div class="feature">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php esc_html_e('Demo Products Included', 'masterai-store-builder'); ?></strong>
                        <p><?php esc_html_e('See exactly how your store will look', 'masterai-store-builder'); ?></p>
                    </div>
                    <div class="feature">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php esc_html_e('Easy Customization', 'masterai-store-builder'); ?></strong>
                        <p><?php esc_html_e('Your brand colors and logo', 'masterai-store-builder'); ?></p>
                    </div>
                </div>

                <div class="masterai-start-options">
                    <label class="masterai-radio-card">
                        <input type="radio" name="start_mode" value="fresh" checked>
                        <div class="radio-card-content">
                            <strong><?php esc_html_e('I\'m starting fresh', 'masterai-store-builder'); ?></strong>
                            <p><?php esc_html_e('Set up a new store with demo products', 'masterai-store-builder'); ?></p>
                        </div>
                    </label>

                    <label class="masterai-radio-card">
                        <input type="radio" name="start_mode" value="existing">
                        <div class="radio-card-content">
                            <strong><?php esc_html_e('I already have products', 'masterai-store-builder'); ?></strong>
                            <p><?php esc_html_e('Just set up the theme and pages', 'masterai-store-builder'); ?></p>
                        </div>
                    </label>
                </div>
            </div>

            <?php $this->render_navigation('', 'industry'); ?>
        </div>
        <?php
    }

    /**
     * Step 2: Industry Selection
     */
    private function render_industry_step()
    {
        $industries = MasterAI_Installer::get_industries();
        ?>
        <div class="masterai-step masterai-step-industry">
            <h2><?php esc_html_e('What will you sell?', 'masterai-store-builder'); ?></h2>
            <p class="subtitle"><?php esc_html_e('Choose the industry that best matches your business', 'masterai-store-builder'); ?>
            </p>

            <div class="masterai-industry-grid">
                <?php foreach ($industries as $key => $industry): ?>
                    <div class="masterai-industry-card" data-industry="<?php echo esc_attr($key); ?>">
                        <div class="industry-icon">
                            <span class="dashicons <?php echo esc_attr($industry['icon']); ?>"></span>
                        </div>
                        <h3><?php echo esc_html($industry['name']); ?></h3>
                        <p><?php echo esc_html($industry['description']); ?></p>
                        <div class="industry-features">
                            <small><?php echo esc_html($industry['demo_products']); ?>
                                <?php esc_html_e('demo products', 'masterai-store-builder'); ?></small>
                        </div>
                        <button class="button button-secondary view-demo" data-industry="<?php echo esc_attr($key); ?>">
                            <?php esc_html_e('Features', 'masterai-store-builder'); ?>
                        </button>
                    </div>
                <?php endforeach; ?>
            </div>

            <input type="hidden" name="selected_industry" id="selected_industry" value="">

            <?php $this->render_navigation('welcome', 'theme'); ?>

            <!-- Industry Preview Modal -->
            <div id="masterai-industry-preview-modal" class="masterai-modal-overlay" style="display: none;">
                <div class="masterai-wizard-modal" style="max-width: 800px; width: 90%;">
                    <button class="masterai-modal-close" type="button">&times;</button>
                    <div class="masterai-modal-header">
                        <h2 id="masterai-preview-title"><?php esc_html_e('Industry Preview', 'masterai-store-builder'); ?></h2>
                    </div>
                    <div class="masterai-modal-body" style="display: flex; gap: 30px;">
                        <div class="masterai-preview-image"
                            style="flex: 1; background: #f0f0f1; border-radius: 8px; min-height: 300px; display: flex; align-items: center; justify-content: center;">
                            <!-- Placeholder for dynamic image or iframe -->
                            <span class="dashicons dashicons-format-image"
                                style="font-size: 60px; color: #ccc; width: 60px; height: 60px;"></span>
                        </div>
                        <div class="masterai-preview-details" style="flex: 1;">
                            <h3 style="margin-top: 0;"><?php esc_html_e('Key Features', 'masterai-store-builder'); ?></h3>
                            <ul class="masterai-preview-features" style="list-style: none; padding: 0; margin-bottom: 30px;">
                                <!-- Populated via JS -->
                            </ul>


                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Step 3: Theme Selection
     */
    private function render_theme_step()
    {
        $industry = isset($_GET['industry']) ? sanitize_key($_GET['industry']) : '';
        if (!$industry && isset($_POST['selected_industry'])) {
            $industry = sanitize_key($_POST['selected_industry']);
        }

        $themes = $this->get_industry_themes($industry);
        ?>
        <div class="masterai-step masterai-step-theme">
            <h2><?php esc_html_e('Choose a Theme', 'masterai-store-builder'); ?></h2>
            <p class="subtitle">
                <?php esc_html_e('Select a design that fits your brand. You can customize it later.', 'masterai-store-builder'); ?>
            </p>

            <div class="masterai-theme-section">
                <h3><?php esc_html_e('Recommended for', 'masterai-store-builder'); ?>
                    <?php echo esc_html($this->get_industry_name($industry)); ?>
                </h3>
                <div class="masterai-theme-grid">
                    <?php
                    if (!empty($themes['recommended'])) {
                        foreach ($themes['recommended'] as $theme) {
                            $this->render_theme_card($theme, true);
                        }
                    }
                    ?>
                </div>
            </div>

            <?php if (!empty($themes['others'])): ?>
                <div class="masterai-theme-section">
                    <h3><?php esc_html_e('More Options', 'masterai-store-builder'); ?></h3>
                    <div class="masterai-theme-grid">
                        <?php
                        foreach ($themes['others'] as $theme) {
                            $this->render_theme_card($theme, false);
                        }
                        ?>
                    </div>
                </div>
            <?php endif; ?>



            <input type="hidden" name="selected_theme" id="selected_theme" value="">

            <div class="masterai-theme-skip">
                <label>
                    <input type="checkbox" name="use_default_theme" id="use_default_theme" value="1">
                    <?php esc_html_e('Skip and use default Storefront theme', 'masterai-store-builder'); ?>
                </label>
            </div>

            <?php $this->render_navigation('industry', 'products'); ?>
        </div>
        <?php
    }

    /**
     * Render individual theme card
     */
    private function render_theme_card($theme, $is_recommended = false)
    {
        $classes = 'masterai-theme-card';
        if ($is_recommended)
            $classes .= ' recommended';
        ?>
        <div class="<?php echo esc_attr($classes); ?>">
            <?php if ($is_recommended): ?>
                <span class="badge-recommended"><?php esc_html_e('Recommended', 'masterai-store-builder'); ?></span>
            <?php endif; ?>

            <div class="theme-screenshot">
                <img src="<?php echo esc_url($theme['image']); ?>" alt="<?php echo esc_attr($theme['name']); ?>">
                <div class="theme-overlay">
                    <button type="button" class="preview-btn" data-theme="<?php echo esc_attr($theme['slug']); ?>">
                        <span class="dashicons dashicons-visibility"></span>
                        <?php esc_html_e('Live Preview', 'masterai-store-builder'); ?>
                    </button>
                </div>
            </div>

            <div class="theme-info">
                <h4><?php echo esc_html($theme['name']); ?></h4>
                <div class="theme-rating">
                    <div class="stars" style="--rating: <?php echo esc_attr($theme['rating']); ?>;">
                        <?php
                        for ($i = 1; $i <= 5; $i++) {
                            echo '<span class="dashicons dashicons-star-' . ($i <= $theme['rating'] ? 'filled' : 'empty') . '"></span>';
                        }
                        ?>
                    </div>
                    <span class="count">(<?php echo esc_html($theme['reviews']); ?>)</span>
                </div>

                <div class="theme-features">
                    <ul>
                        <?php foreach (array_slice($theme['features'], 0, 2) as $feature): ?>
                            <li><span class="dashicons dashicons-yes"></span> <?php echo esc_html($feature); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <div class="theme-meta">
                    <span class="price <?php echo esc_attr($theme['price'] == 'Free' ? 'free' : ''); ?>">
                        <?php echo esc_html($theme['price']); ?>
                    </span>
                </div>
            </div>

            <div class="masterai-select-theme">
                <button type="button" class="button button-primary select-theme-btn"
                    data-theme="<?php echo esc_attr($theme['slug']); ?>">
                    <?php esc_html_e('Select', 'masterai-store-builder'); ?>
                </button>
            </div>
        </div>
        <?php
    }

    /**
     * Get themes for industry
     */
    private function get_industry_themes($industry)
    {
        // 15 Free WooCommerce Store Themes from WordPress.org - All show product collections on homepage
        $all_themes = array(
            'blossom-shop' => array(
                'slug' => 'blossom-shop',
                'name' => 'Blossom Shop',
                'price' => 'Free',
                'rating' => 5,
                'reviews' => 1200,
                'image' => '' . MasterAI_PLUGIN_URL . 'assets/images/theme-placeholder.svg',
                'features' => array('Product Showcase', 'Instagram Feed'),
                'industries' => array('all') // Use 'all' to ensure it appears recommended
            ),

            'store-woocommerce' => array(
                'slug' => 'store-woocommerce',
                'name' => 'Store WooCommerce',
                'price' => 'Free',
                'rating' => 5,
                'reviews' => 780,
                'image' => '' . MasterAI_PLUGIN_URL . 'assets/images/theme-placeholder.svg',
                'features' => array('Product Display', 'Store Layout'),
                'industries' => array('all')
            )
        );

        $recommended = array();
        $others = array();

        // Match themes to industries
        foreach ($all_themes as $slug => $theme) {
            if (in_array($industry, $theme['industries']) || in_array('all', $theme['industries'])) {
                $recommended[] = $theme;
            } else {
                $others[] = $theme;
            }
        }

        // Ensure we always have a theme in recommended (Fallback to Store WooCommerce)
        if (empty($recommended)) {
            $recommended[] = $all_themes['store-woocommerce'];
        }

        return array(
            'recommended' => $recommended,
            'others' => $others
        );
    }

    /**
     * Helper: Get Industry Name
     */
    private function get_industry_name($slug)
    {
        $industries = MasterAI_Installer::get_industries();
        return isset($industries[$slug]) ? $industries[$slug]['name'] : 'Your Store';
    }
    private function render_products_step()
    {
        $products = array();
        if (function_exists('wc_get_products')) {
            $args = array(
                'limit' => 12,
                'status' => 'publish',
            );
            $products = wc_get_products($args);
        }
        $selected_products = get_option('masterai_builder_selected_products', array());
        ?>
        <div class="masterai-step masterai-step-products">
            <h2><?php esc_html_e('Select Products', 'masterai-store-builder'); ?></h2>
            <p class="subtitle">
                <?php esc_html_e('Choose existing products to feature in your MasterAI setup', 'masterai-store-builder'); ?>
            </p>

            <div class="masterai-products-grid">
                <!-- AI Generator Card -->
                <div class="masterai-product-card ai-generator" id="masterai-ai-generator-card"
                    style="display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; border: 2px dashed #667eea; background: #f8fafc;">
                    <div class="card-icon" style="margin-bottom: 10px;">
                        <span class="dashicons dashicons-superhero-alt"
                            style="font-size: 40px; width: 40px; height: 40px; color: #f39c12;"></span>
                    </div>
                    <h3 style="margin: 0 0 15px 0;"><?php esc_html_e('AI Product Writer', 'masterai-store-builder'); ?></h3>
                    <button type="button" class="button button-primary masterai-ai-modal-trigger">
                        <?php esc_html_e('Create', 'masterai-store-builder'); ?>
                    </button>
                </div>
                <?php if (!empty($products)): ?>
                    <?php foreach ($products as $product): ?>
                        <label
                            class="masterai-product-card <?php echo in_array($product->get_id(), $selected_products) ? 'selected' : ''; ?>">
                            <input type="checkbox" name="selected_products[]" value="<?php echo esc_attr($product->get_id()); ?>" <?php checked(in_array($product->get_id(), $selected_products)); ?>>
                            <div class="product-card-content">
                                <div class="product-image">
                                    <?php echo wp_kses_post($product->get_image('thumbnail')); ?>
                                </div>
                                <div class="product-info">
                                    <h4><?php echo esc_html($product->get_name()); ?></h4>
                                    <span class="price"><?php echo wp_kses_post($product->get_price_html()); ?></span>
                                </div>
                                <div class="check-icon"><span class="dashicons dashicons-yes"></span></div>
                            </div>
                        </label>
                    <?php endforeach; ?>
                <?php else: ?>
                    <!-- Demo Products -->
                    <?php
                    $demo_products = array(
                        array(
                            'id' => 'demo_1',
                            'name' => 'Premium T-Shirt (Demo)',
                            'price' => '$25.00',
                            'icon' => 'dashicons-admin-customizer', // Using dashicon as fallback
                        ),
                        array(
                            'id' => 'demo_2',
                            'name' => 'Modern Coffee Mug (Demo)',
                            'price' => '$15.00',
                            'icon' => 'dashicons-coffee',
                        ),
                    );
                    ?>
                    <?php foreach ($demo_products as $demo): ?>
                        <label class="masterai-product-card selected">
                            <input type="checkbox" name="selected_products[]" value="<?php echo esc_attr($demo['id']); ?>" checked>
                            <div class="product-card-content">
                                <div class="product-image"
                                    style="display: flex; align-items: center; justify-content: center; background: #f0f0f1; color: #ccc;">
                                    <span class="dashicons <?php echo esc_attr($demo['icon']); ?>"
                                        style="font-size: 48px; width: 48px; height: 48px;"></span>
                                </div>
                                <div class="product-info">
                                    <h4><?php echo esc_html($demo['name']); ?></h4>
                                    <span class="price"><?php echo esc_html($demo['price']); ?></span>
                                </div>
                                <div class="check-icon"><span class="dashicons dashicons-yes"></span></div>
                            </div>
                        </label>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <?php if (empty($products)): ?>
                <div class="notice notice-info inline" style="margin-top: 20px;">
                    <p><?php esc_html_e('We added some demo products for you to get started. You can remove them later.', 'masterai-store-builder'); ?>
                    </p>
                </div>
            <?php endif; ?>

            <?php $this->render_navigation('industry', 'details'); ?>
        </div>
        <?php
    }

    /**
     * Step 3: Store Details
     */
    private function render_details_step()
    {
        $store_name = get_option('masterai_builder_store_name', get_bloginfo('name'));
        $store_description = get_option('masterai_builder_store_description', get_bloginfo('description'));
        $logo_id = get_option('masterai_builder_logo_id');
        ?>
        <div class="masterai-step masterai-step-details">
            <h2><?php esc_html_e('Tell us about your store', 'masterai-store-builder'); ?></h2>

            <div class="masterai-form">
                <div class="form-group">
                    <label for="store_name"><?php esc_html_e('Store Name', 'masterai-store-builder'); ?> <span
                            class="required">*</span></label>
                    <input type="text" id="store_name" name="store_name" class="regular-text"
                        value="<?php echo esc_attr($store_name); ?>" required>
                    <p class="description">
                        <?php esc_html_e('This will be displayed in your store header and emails', 'masterai-store-builder'); ?>
                    </p>
                </div>

                <div class="form-group">
                    <label for="store_description"><?php esc_html_e('Store Description', 'masterai-store-builder'); ?></label>
                    <?php if (get_option('masterai_builder_gemini_key')): ?>
                        <button type="button" class="button button-small masterai-ai-description-btn"
                            style="float: right; margin-bottom: 5px;">
                            <span class="dashicons dashicons-superhero"></span>
                            <?php esc_html_e('Generate with AI', 'masterai-store-builder'); ?>
                        </button>
                    <?php endif; ?>
                    <textarea id="store_description" name="store_description" class="regular-text"
                        rows="3"><?php echo esc_textarea($store_description); ?></textarea>

                    <div id="masterai-ai-description-results" style="display:none; margin-top: 10px;"></div>

                    <p class="description">
                        <?php esc_html_e('Briefly describe your store for customers and SEO', 'masterai-store-builder'); ?>
                    </p>
                </div>





                <div class="form-group">
                    <label><?php esc_html_e('Store Logo', 'masterai-store-builder'); ?></label>
                    <div class="masterai-logo-upload">
                        <input type="hidden" name="logo_id" id="logo_id" value="<?php echo esc_attr($logo_id); ?>">
                        <div class="logo-preview" id="logo-preview">
                            <?php
                            $logo_id = get_option('masterai_builder_logo_id');
                            $logo_width = get_option('masterai_builder_logo_width', 150);
                            if ($logo_id) {
                                echo wp_get_attachment_image($logo_id, 'medium', false, array('style' => 'max-width: ' . esc_attr($logo_width) . 'px; height: auto;'));
                            } else {
                                echo '<span class="dashicons dashicons-format-image"></span>';
                            }
                            ?>
                        </div>
                        <button type="button" class="button button-secondary masterai-upload-logo">
                            <?php echo $logo_id ? esc_html__('Change Logo', 'masterai-store-builder') : esc_html__('Upload Logo', 'masterai-store-builder'); ?>
                        </button>
                        <button type="button" class="button button-link-delete masterai-remove-logo" <?php echo $logo_id ? '' : 'style="display:none;"'; ?>>
                            <?php esc_html_e('Remove Logo', 'masterai-store-builder'); ?>
                        </button>
                    </div>

                    <div class="masterai-logo-width-control"
                        style="margin-top: 15px; <?php echo $logo_id ? '' : 'display:none;'; ?>">
                        <label for="logo_width" style="font-weight: normal; font-size: 13px;">
                            <?php esc_html_e('Logo Size:', 'masterai-store-builder'); ?>
                            <span
                                id="logo_width_display"><?php echo esc_html(get_option('masterai_builder_logo_width', 150)); ?>px</span>
                        </label>
                        <input type="range" id="logo_width" name="logo_width" min="50" max="400" step="5"
                            value="<?php echo esc_attr(get_option('masterai_builder_logo_width', 150)); ?>"
                            style="width: 100%; max-width: 300px;">
                    </div>
                </div>

                <div class="form-group">
                    <label><?php esc_html_e('Brand Colors', 'masterai-store-builder'); ?></label>
                    <div class="masterai-color-picker-group">
                        <div class="color-picker-item">
                            <label for="primary_color"><?php esc_html_e('Primary Color', 'masterai-store-builder'); ?></label>
                            <input type="text" id="primary_color" name="primary_color" class="masterai-color-picker"
                                value="#FF6B6B">
                        </div>
                        <div class="color-picker-item">
                            <label for="secondary_color"><?php esc_html_e('Secondary Color', 'masterai-store-builder'); ?></label>
                            <input type="text" id="secondary_color" name="secondary_color" class="masterai-color-picker"
                                value="#4ECDC4">
                        </div>
                    </div>

                    <div class="color-presets">
                        <p><?php esc_html_e('Or choose a preset:', 'masterai-store-builder'); ?></p>
                        <button type="button" class="color-preset" data-primary="#FF6B6B" data-secondary="#4ECDC4">
                            <span style="background: #FF6B6B"></span>
                            <span style="background: #4ECDC4"></span>
                            <?php esc_html_e('Bold & Modern', 'masterai-store-builder'); ?>
                        </button>
                        <button type="button" class="color-preset" data-primary="#2D6A4F" data-secondary="#95D5B2">
                            <span style="background: #2D6A4F"></span>
                            <span style="background: #95D5B2"></span>
                            <?php esc_html_e('Calm & Natural', 'masterai-store-builder'); ?>
                        </button>
                        <button type="button" class="color-preset" data-primary="#1A1A2E" data-secondary="#D4AF37">
                            <span style="background: #1A1A2E"></span>
                            <span style="background: #D4AF37"></span>
                            <?php esc_html_e('Luxury & Elegant', 'masterai-store-builder'); ?>
                        </button>
                        <button type="button" class="color-preset" data-primary="#FF6B9D" data-secondary="#FEC601">
                            <span style="background: #FF6B9D"></span>
                            <span style="background: #FEC601"></span>
                            <?php esc_html_e('Fun & Playful', 'masterai-store-builder'); ?>
                        </button>
                    </div>
                </div>
            </div>

            <?php $this->render_navigation('products', 'settings'); ?>
        </div>
        <?php
    }

    /**
     * Step 4: Business Settings
     */
    private function render_settings_step()
    {
        ?>
        <div class="masterai-step masterai-step-settings">
            <h2><?php esc_html_e('Business Settings', 'masterai-store-builder'); ?></h2>

            <div class="masterai-form">
                <div class="form-group">
                    <label for="store_currency"><?php esc_html_e('Currency', 'masterai-store-builder'); ?> <span
                            class="required">*</span></label>
                    <select id="store_currency" name="store_currency" class="regular-text">
                        <?php
                        // Available currencies list
                        $currencies = array(
                            'USD' => 'US Dollar ($)',
                            'EUR' => 'Euro (€)',
                            'GBP' => 'British Pound (£)',
                            'CAD' => 'Canadian Dollar ($)',
                            'AUD' => 'Australian Dollar ($)',
                            'JPY' => 'Japanese Yen (¥)',
                            'INR' => 'Indian Rupee (₹)',
                            'NZD' => 'New Zealand Dollar ($)',
                            'CHF' => 'Swiss Franc (Fr)',
                            'HKD' => 'Hong Kong Dollar ($)',
                            'SGD' => 'Singapore Dollar ($)',
                            'SEK' => 'Swedish Krona (kr)',
                            'DKK' => 'Danish Krone (kr)',
                            'NOK' => 'Norwegian Krone (kr)',
                            'ZAR' => 'South African Rand (R)',
                            'CNY' => 'Chinese Yuan (¥)',
                            'BRL' => 'Brazilian Real (R$)',
                            'MXN' => 'Mexican Peso ($)',
                            'KRW' => 'South Korean Won (₩)',
                            'PLN' => 'Polish Złoty (zł)',
                            'TRY' => 'Turkish Lira (₺)',
                        );
                        foreach ($currencies as $code => $name) {
                            printf('<option value="%s" %s>%s</option>', esc_attr($code), selected($this->currency_code, $code, false), esc_html($name));
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="store_country"><?php esc_html_e('Store Location', 'masterai-store-builder'); ?> <span
                            class="required">*</span></label>
                    <select id="store_country" name="store_country" class="regular-text">
                        <?php
                        $countries_list = $this->countries;
                        $selected_country = $this->current_country;
                        $current_country_name = isset($countries_list[$selected_country]) ? $countries_list[$selected_country] : (isset($countries_list['US']) ? $countries_list['US'] : 'United States');

                        foreach ($countries_list as $code => $name) {
                            printf(
                                '<option value="%s" %s>%s</option>',
                                esc_attr($code),
                                selected($selected_country, $code, false),
                                esc_html($name)
                            );
                        }
                        ?>
                    </select>
                    <p class="description" style="margin-top: 5px; color: #666;">
                        <?php
                        $country_note = sprintf(
                            /* translators: %s: Current country name */
                            esc_html__('(Your current location is %s, you can change store location)', 'masterai-store-builder'),
                            '<strong>' . esc_html($current_country_name) . '</strong>'
                        ); ?>
                        <?php echo wp_kses_post($country_note); ?>
                    </p>
                </div>


                <div class="form-group">
                    <label><?php esc_html_e('What will you offer?', 'masterai-store-builder'); ?></label>
                    <label class="masterai-checkbox">
                        <input type="checkbox" name="offer_physical" value="1" checked>
                        <?php esc_html_e('Physical products (shipping required)', 'masterai-store-builder'); ?>
                    </label>
                    <label class="masterai-checkbox">
                        <input type="checkbox" name="offer_digital" value="1">
                        <?php esc_html_e('Digital downloads', 'masterai-store-builder'); ?>
                    </label>
                    <label class="masterai-checkbox">
                        <input type="checkbox" name="offer_services" value="1">
                        <?php esc_html_e('Services or appointments', 'masterai-store-builder'); ?>
                    </label>
                </div>

                <div class="form-group shipping-options">
                    <label><?php esc_html_e('Where do you ship?', 'masterai-store-builder'); ?></label>

                    <div class="masterai-shipping-grid">
                        <!-- Domestic -->
                        <div class="masterai-shipping-card domestic selected">
                            <div class="shipping-header">
                                <label class="masterai-checkbox">
                                    <input type="checkbox" name="shipping_domestic" value="1" checked>
                                    <strong><?php esc_html_e('Domestic', 'masterai-store-builder'); ?></strong>
                                </label>
                                <span class="badge domestic-country"><?php echo esc_html($current_country_name); ?></span>
                            </div>
                            <div class="shipping-body">
                                <div class="masterai-input-group">
                                    <label><?php esc_html_e('Flat Rate Cost', 'masterai-store-builder'); ?></label>
                                    <div class="input-with-icon">
                                        <span class="currency-symbol"><?php echo esc_html($this->currency_symbol); ?></span>
                                        <input type="number" name="shipping_domestic_rate" value="5.00" step="0.01" min="0">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- International -->
                        <div class="masterai-shipping-card international">
                            <div class="shipping-header">
                                <label class="masterai-checkbox">
                                    <input type="checkbox" name="shipping_international" value="1">
                                    <strong><?php esc_html_e('Rest of the World', 'masterai-store-builder'); ?></strong>
                                </label>
                                <span class="badge global"><?php esc_html_e('International', 'masterai-store-builder'); ?></span>
                            </div>
                            <div class="shipping-body">
                                <div class="masterai-input-group">
                                    <label><?php esc_html_e('Flat Rate Cost', 'masterai-store-builder'); ?></label>
                                    <div class="input-with-icon">
                                        <span class="currency-symbol"><?php echo esc_html($this->currency_symbol); ?></span>
                                        <input type="number" name="shipping_international_rate" value="15.00" step="0.01"
                                            min="0">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php $this->render_navigation('details', 'install'); ?>
        </div>
        <?php
    }



    /**
     * Step 6: Installation
     */
    private function render_install_step()
    {
        ?>
        <div class="masterai-step masterai-step-install">
            <!-- Preview Section (Step 8 Initial View) -->
            <div class="masterai-install-preview" id="masterai-install-preview">
                <h2><?php esc_html_e('Review Your Store', 'masterai-store-builder'); ?></h2>
                <p class="subtitle"><?php esc_html_e('One last look before we build everything for you.', 'masterai-store-builder'); ?>
                </p>

                <div class="masterai-preview-container-split">
                    <!-- Left: Visual Preview -->
                    <div class="masterai-preview-visual">
                        <div class="masterai-browser-mockup">
                            <div class="browser-bar">
                                <span class="dot red"></span>
                                <span class="dot yellow"></span>
                                <span class="dot green"></span>
                                <div class="browser-url"><?php echo esc_url(home_url()); ?></div>
                            </div>
                            <div class="browser-viewport">
                                <!-- Theme Preview Image populated via JS -->
                                <div class="masterai-theme-preview-container"
                                    style="width:100%; height:100%; position:relative; overflow:hidden;">
                                    <img id="masterai-theme-preview-img" src="" alt="Theme Preview"
                                        style="width:100%; height:100%; object-fit:cover; object-position:top; display:none;">
                                    <div id="masterai-theme-preview-placeholder"
                                        style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:#f0f0f1;">
                                        <span class="dashicons dashicons-format-image"
                                            style="font-size:80px; width:80px; height:80px; color:#ccc;"></span>
                                    </div>
                                </div>
                                <div class="preview-overlay-info">
                                    <h3 id="preview-store-name"></h3>
                                    <p id="preview-tagline"></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right: Summary Details -->
                    <div class="masterai-preview-details">
                        <h3><?php esc_html_e('Store Summary', 'masterai-store-builder'); ?></h3>
                        <ul class="masterai-summary-list">
                            <li>
                                <span class="icon"><span class="dashicons dashicons-store"></span></span>
                                <div class="summary-info">
                                    <label><?php esc_html_e('Industry', 'masterai-store-builder'); ?></label>
                                    <strong id="summary-industry">-</strong>
                                </div>
                            </li>
                            <li>
                                <span class="icon"><span class="dashicons dashicons-desktop"></span></span>
                                <div class="summary-info">
                                    <label><?php esc_html_e('Theme', 'masterai-store-builder'); ?></label>
                                    <strong id="summary-theme">-</strong>
                                </div>
                            </li>
                            <li>
                                <span class="icon"><span class="dashicons dashicons-cart"></span></span>
                                <div class="summary-info">
                                    <label><?php esc_html_e('Products', 'masterai-store-builder'); ?></label>
                                    <strong id="summary-products">0 Selected</strong>
                                </div>
                            </li>
                            <li>
                                <span class="icon"><span class="dashicons dashicons-admin-site"></span></span>
                                <div class="summary-info">
                                    <label><?php esc_html_e('Location & Currency', 'masterai-store-builder'); ?></label>
                                    <strong id="summary-location">-</strong>
                                </div>
                            </li>
                        </ul>

                        <div class="masterai-preview-actions">
                            <button type="button" class="button button-secondary masterai-btn-back-preview">
                                <?php esc_html_e('Back to Edit', 'masterai-store-builder'); ?>
                            </button>
                            <button type="button" class="button button-primary masterai-btn-launch"
                                id="masterai-start-install-btn">
                                <?php esc_html_e('Install & Launch Store', 'masterai-store-builder'); ?>
                                <span class="dashicons dashicons-rocket"></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Installation Progress (Hidden Initially) -->
            <div class="masterai-install-progress" style="display: none;">
                <div class="install-icon">
                    <span class="dashicons dashicons-update-alt masterai-spinner"></span>
                </div>
                <h2 id="install-status"><?php esc_html_e('Building your store...', 'masterai-store-builder'); ?></h2>
                <div class="progress-steps" id="progress-steps">
                    <div class="progress-step" data-step="theme">
                        <span class="dashicons dashicons-minus"></span>
                        <?php esc_html_e('Installing theme...', 'masterai-store-builder'); ?>
                    </div>
                    <div class="progress-step" data-step="pages">
                        <span class="dashicons dashicons-minus"></span>
                        <?php esc_html_e('Creating pages...', 'masterai-store-builder'); ?>
                    </div>
                    <div class="progress-step" data-step="products">
                        <span class="dashicons dashicons-minus"></span>
                        <?php esc_html_e('Adding demo products...', 'masterai-store-builder'); ?>
                    </div>
                    <div class="progress-step" data-step="settings">
                        <span class="dashicons dashicons-minus"></span>
                        <?php esc_html_e('Configuring settings...', 'masterai-store-builder'); ?>
                    </div>
                    <div class="progress-step" data-step="navigation">
                        <span class="dashicons dashicons-minus"></span>
                        <?php esc_html_e('Setting up navigation...', 'masterai-store-builder'); ?>
                    </div>
                </div>

                <div class="progress-bar">
                    <div class="progress-fill" id="progress-fill" style="width: 0%"></div>
                </div>
                <p class="progress-text"><span id="progress-percent">0</span>%
                    <?php esc_html_e('complete', 'masterai-store-builder'); ?>
                </p>
            </div>

            <div class="masterai-install-complete" id="install-complete" style="display: none;">
                <div class="success-icon">
                    <span class="dashicons dashicons-yes-alt"></span>
                </div>
                <h2><?php esc_html_e('Your store is ready!', 'masterai-store-builder'); ?></h2>
                <p><?php esc_html_e('Congratulations! Your professional online store has been set up successfully.', 'masterai-store-builder'); ?>
                </p>

                <div class="masterai-next-steps">
                    <h3><?php esc_html_e('What\'s Next?', 'masterai-store-builder'); ?></h3>
                    <div class="next-step-item">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php esc_html_e('Replace demo products', 'masterai-store-builder'); ?></strong>
                        <p><?php esc_html_e('Add your own products or keep demos as templates', 'masterai-store-builder'); ?></p>
                    </div>
                    <div class="next-step-item">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php esc_html_e('Customize your design', 'masterai-store-builder'); ?></strong>
                        <p><?php esc_html_e('Fine-tune colors, fonts, and layout', 'masterai-store-builder'); ?></p>
                    </div>
                    <div class="next-step-item">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php esc_html_e('Test checkout', 'masterai-store-builder'); ?></strong>
                        <p><?php esc_html_e('Make sure everything works smoothly', 'masterai-store-builder'); ?></p>
                    </div>
                </div>

                <div class="masterai-action-buttons">
                    <a href="<?php echo esc_url(home_url('/shop')); ?>" class="button button-primary button-hero"
                        target="_blank">
                        <?php esc_html_e('View Your Store', 'masterai-store-builder'); ?>
                    </a>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=masterai-dashboard')); ?>"
                        class="button button-secondary button-hero">
                        <?php esc_html_e('Go to Dashboard', 'masterai-store-builder'); ?>
                    </a>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render navigation buttons
     */
    private function render_navigation($prev_step, $next_step)
    {
        ?>
        <div class="masterai-wizard-actions">
            <?php if ($prev_step): ?>
                <a href="<?php echo esc_url(add_query_arg('step', $prev_step)); ?>" class="button button-secondary masterai-btn-back"
                    data-prev-step="<?php echo esc_attr($prev_step); ?>">
                    <span class="dashicons dashicons-arrow-left-alt2"></span>
                    <?php esc_html_e('Back', 'masterai-store-builder'); ?>
                </a>
            <?php endif; ?>

            <div class="masterai-next-wrapper" style="position: relative; display: inline-flex;">
                <button type="button" class="button button-primary masterai-btn-next"
                    data-next-step="<?php echo esc_attr($next_step); ?>">
                    <?php
                    if ($next_step === 'install') {
                        esc_html_e('Install My Store', 'masterai-store-builder');
                    } else {
                        esc_html_e('Continue', 'masterai-store-builder');
                    }
                    ?>
                    <span class="dashicons dashicons-arrow-right-alt2"></span>
                </button>
            </div>


        </div>
        <?php
    }

    /**
     * AJAX: Upload Theme
     */
    public function masterai_builder_upload_theme()
    {
        check_ajax_referer('masterai_builder_wizard_nonce', 'nonce');

        if (!current_user_can('install_themes')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        if (empty($_FILES['theme_zip'])) {
            wp_send_json_error(array('message' => __('No file uploaded', 'masterai-store-builder')));
        }

        // This is a placeholder for actual theme upload processing
        // In a real implementation, this would handle WP_Filesystem, unzip, and activation

        wp_send_json_success(array(
            'message' => __('Theme uploaded successfully', 'masterai-store-builder'),
            'theme_slug' => 'custom-theme', // Mock slug
            'theme_name' => sanitize_file_name(wp_unslash($_FILES['theme_zip']['name']))
        ));
    }

    /**
     * AJAX: Save Wizard Step
     */
    public function masterai_builder_save_wizard_step()
    {
        check_ajax_referer('masterai_builder_wizard_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        $step = isset($_POST['step']) ? sanitize_key($_POST['step']) : '';
        $data = isset($_POST['data']) ? $_POST['data'] : array();

        if (empty($step)) {
            wp_send_json_error(array('message' => __('Invalid step', 'masterai-store-builder')));
        }

        // DEBUG: Trace saving process
        error_log('MasterAI Wizard Save Step: ' . $step);
        error_log('MasterAI Wizard Data: ' . print_r($data, true));

        // Get existing data
        $wizard_data = get_option('masterai_builder_wizard_data', array());

        // Merge new data
        $wizard_data[$step] = $data;

        // Save back
        update_option('masterai_builder_wizard_data', $wizard_data);

        // ✅ IMPORTANT: Save logo_id separately for easy access
        if ($step === 'details' && isset($data['logo_id']) && !empty($data['logo_id'])) {
            update_option('masterai_builder_logo_id', absint($data['logo_id']));
        }

        // Save logo width
        if ($step === 'details' && isset($data['logo_width'])) {
            update_option('masterai_builder_logo_width', absint($data['logo_width']));
        }

        // Also save other important settings
        if ($step === 'details') {
            if (isset($data['store_name'])) {
                update_option('masterai_builder_store_name', sanitize_text_field($data['store_name']));
                update_option('blogname', sanitize_text_field($data['store_name']));
            }
            if (isset($data['store_description'])) {
                error_log('MasterAI Store Description Found: ' . $data['store_description']);
                update_option('masterai_builder_store_description', sanitize_textarea_field($data['store_description']));
                update_option('blogdescription', sanitize_textarea_field($data['store_description']));
            } else {
                error_log('MasterAI Store Description MISSING in data');
            }
            if (isset($data['primary_color'])) {
                update_option('masterai_builder_primary_color', sanitize_hex_color($data['primary_color']));
            }
            if (isset($data['secondary_color'])) {
                update_option('masterai_builder_secondary_color', sanitize_hex_color($data['secondary_color']));
            }
        }


        wp_send_json_success(array('message' => __('Saved', 'masterai-store-builder')));
    }

    /**
     * AJAX: Install Template (Final Step)
     */
    public function masterai_builder_install_template()
    {
        check_ajax_referer('masterai_builder_wizard_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'masterai-store-builder')));
        }

        $wizard_data = get_option('masterai_builder_wizard_data', array());
        $theme_slug = isset($wizard_data['theme']['theme']) ? sanitize_text_field($wizard_data['theme']['theme']) : 'storefront';

        // Store user-selected theme slug as a recommendation only.
        update_option('masterai_builder_recommended_theme', sanitize_key($theme_slug));

        // Apply logo
        if (isset($wizard_data['details']['logo_id'])) {
            $this->apply_logo($wizard_data['details']['logo_id']);
        }

        // 2. Mark onboarding as complete
        update_option('masterai_builder_onboarding_complete', 'yes');

        wp_send_json_success(array(
            'message' => __('Installation complete', 'masterai-store-builder'),
            'redirect' => admin_url('admin.php?page=masterai-dashboard')
        ));
    }

    /**
     * Store selected theme as recommendation only.
     */
    private function install_theme($slug)
    {
        if (empty($slug)) {
            $slug = 'storefront';
        }
        update_option('masterai_builder_recommended_theme', sanitize_key($slug));
        return true;
    }

    /**
     * Apply logo during installation
     */
    private function apply_logo($logo_id)
    {
        if (empty($logo_id)) {
            return;
        }

        // Set as site logo (theme mod)
        set_theme_mod('custom_logo', absint($logo_id));

        // Also save as option for backup
        update_option('masterai_builder_logo_id', absint($logo_id));

        // For WooCommerce stores, also set as site icon
        update_option('site_icon', absint($logo_id));
    }
}
