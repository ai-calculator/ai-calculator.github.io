<?php
/**
 * Industrial Product Filter
 * 
 * @package MasterAI_Builder
 */

if (!defined('ABSPATH')) {
    exit;
}

class MasterAI_Industrial_Filter
{
    /**
     * Init
     */
    public static function init()
    {
        // Check if feature is enabled
        if (!get_option('masterai_builder_enable_industrial_filter')) {
            return;
        }

        // Hook into frontend
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));
        add_action('woocommerce_before_shop_loop', array(__CLASS__, 'render_filter_bar'), 20);
        add_action('woocommerce_product_query', array(__CLASS__, 'handle_filter_query'));
    }

    /**
     * Enqueue Assets
     */
    public static function enqueue_assets()
    {
        if (!is_shop() && !is_product_category()) {
            return;
        }

        wp_enqueue_style('masterai-industrial-filter', MasterAI_PLUGIN_URL . 'assets/css/industrial-filter.css', array(), '1.0');
    }

    /**
     * Render Filter Bar
     */
    public static function render_filter_bar()
    {
        // Get current values
        $current_id = isset($_GET['masterai_builder_id']) ? sanitize_text_field($_GET['masterai_builder_id']) : '';
        $current_od = isset($_GET['masterai_builder_od']) ? sanitize_text_field($_GET['masterai_builder_od']) : '';
        $current_material = isset($_GET['masterai_builder_material']) ? sanitize_text_field($_GET['masterai_builder_material']) : '';

        ?>
        <div class="masterai-industrial-filter-bar">
            <form method="GET" action="">

                <div class="masterai-filter-group">
                    <label>
                        <?php esc_html_e('Inner Diameter (mm)', 'masterai-store-builder'); ?>
                    </label>
                    <input type="number" name="masterai_builder_id" placeholder="e.g. 10"
                        value="<?php echo esc_attr($current_id); ?>">
                </div>

                <div class="masterai-filter-group">
                    <label>
                        <?php esc_html_e('Outer Diameter (mm)', 'masterai-store-builder'); ?>
                    </label>
                    <input type="number" name="masterai_builder_od" placeholder="e.g. 20"
                        value="<?php echo esc_attr($current_od); ?>">
                </div>

                <div class="masterai-filter-group">
                    <label>
                        <?php esc_html_e('Material', 'masterai-store-builder'); ?>
                    </label>
                    <select name="masterai_builder_material">
                        <option value="">
                            <?php esc_html_e('Any Material', 'masterai-store-builder'); ?>
                        </option>
                        <option value="NBR" <?php selected($current_material, 'NBR'); ?>>NBR (Nitrile)</option>
                        <option value="FKM" <?php selected($current_material, 'FKM'); ?>>FKM (Viton)</option>
                        <option value="VMQ" <?php selected($current_material, 'VMQ'); ?>>VMQ (Silicone)</option>
                        <option value="EPDM" <?php selected($current_material, 'EPDM'); ?>>EPDM</option>
                    </select>
                </div>

                <div class="masterai-filter-actions">
                    <button type="submit" class="button button-primary">
                        <?php esc_html_e('Filter', 'masterai-store-builder'); ?>
                    </button>
                    <a href="<?php echo esc_url(remove_query_arg(array('masterai_builder_id', 'masterai_builder_od', 'masterai_builder_material'))); ?>"
                        class="masterai-filter-reset">
                        <?php esc_html_e('Reset', 'masterai-store-builder'); ?>
                    </a>
                </div>

            </form>
        </div>
        <?php
    }

    /**
     * Handle Query
     */
    public static function handle_filter_query($q)
    {
        if (is_admin() || !$q->is_main_query()) {
            return;
        }

        $meta_query = $q->get('meta_query');
        if (!$meta_query) {
            $meta_query = array();
        }

        // Inner Diameter
        if (!empty($_GET['masterai_builder_id'])) {
            $meta_query[] = array(
                'key' => 'masterai_builder_inner_diameter',
                'value' => sanitize_text_field($_GET['masterai_builder_id']),
                'compare' => '=',
                'type' => 'NUMERIC'
            );
        }

        // Outer Diameter
        if (!empty($_GET['masterai_builder_od'])) {
            $meta_query[] = array(
                'key' => 'masterai_builder_outer_diameter',
                'value' => sanitize_text_field($_GET['masterai_builder_od']),
                'compare' => '=',
                'type' => 'NUMERIC'
            );
        }

        // Material
        if (!empty($_GET['masterai_builder_material'])) {
            $meta_query[] = array(
                'key' => 'masterai_builder_material',
                'value' => sanitize_text_field($_GET['masterai_builder_material']),
                'compare' => '='
            );
        }

        if (!empty($meta_query)) {
            $q->set('meta_query', $meta_query);
        }
    }
}
