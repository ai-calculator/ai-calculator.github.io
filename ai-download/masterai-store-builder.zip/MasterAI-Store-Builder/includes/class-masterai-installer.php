<?php
/**
 * MasterAI Installer
 *
 * @package MasterAI_Builder
 */

if (!defined('ABSPATH')) {
    exit;
}

class MasterAI_Installer
{

    /**
     * Install plugin
     */
    public static function install()
    {
        if (!is_blog_installed()) {
            return;
        }

        // Check if already installed
        if (self::is_installed()) {
            self::update();
            return;
        }

        self::create_options();


        update_option('masterai_builder_version', MasterAI_VERSION);
        update_option('masterai_builder_install_date', current_time('mysql'));

        // Schedule demo content import
        if (!get_option('masterai_builder_demo_content_installed')) {
            wp_schedule_single_event(time() + 30, 'masterai_builder_deferred_install_demo_content');
        }
    }

    /**
     * Check if plugin is installed
     */
    private static function is_installed()
    {
        return (bool) get_option('masterai_builder_version');
    }

    /**
     * Update plugin
     */
    private static function update()
    {
        $current_version = get_option('masterai_builder_version');

        if (version_compare($current_version, MasterAI_VERSION, '<')) {
            // Run update routines
            update_option('masterai_builder_version', MasterAI_VERSION);
        }
    }

    /**
     * Run deferred demo import
     */
    public static function run_demo_import()
    {
        if (get_option('masterai_builder_demo_content_installed')) {
            return;
        }

        // Check for WooCommerce
        if (!class_exists('WooCommerce')) {
            return;
        }

        // Import
        $industry = get_option('masterai_builder_industry', 'fashion');
        if (!class_exists('MasterAI_Demo_Importer')) {
            require_once MasterAI_PLUGIN_DIR . 'includes/class-masterai-demo-importer.php';
        }
        $importer = new MasterAI_Demo_Importer();
        $importer->import_products($industry);

        update_option('masterai_builder_demo_content_installed', true);
    }

    /**
     * Create default options
     */
    private static function create_options()
    {
        $defaults = array(
            'masterai_builder_onboarding_complete' => false,
            'masterai_builder_industry' => '',
            'masterai_builder_store_name' => get_bloginfo('name'),
            'masterai_builder_store_tagline' => get_bloginfo('description'),
            'masterai_builder_primary_color' => '#FF6B6B',
            'masterai_builder_secondary_color' => '#4ECDC4',
            'masterai_builder_template_installed' => false,
            'masterai_builder_demo_content_installed' => false,
        );

        foreach ($defaults as $key => $value) {
            if (!get_option($key)) {
                add_option($key, $value);
            }
        }
    }



    /**
     * Get available industries
     */
    public static function get_industries()
    {
        return array(
            'fashion' => array(
                'name' => __('Fashion & Apparel', 'masterai-store-builder'),
                'icon' => 'dashicons-store',
                'description' => __('Clothing, shoes, and accessories', 'masterai-store-builder'),
                'demo_products' => 12,
                'features' => array('Size variations', 'Color swatches', 'Size guide', 'Lookbook gallery'),
            ),
            'food' => array(
                'name' => __('Food & Beverage', 'masterai-store-builder'),
                'icon' => 'dashicons-food',
                'description' => __('Restaurants, bakeries, and food delivery', 'masterai-store-builder'),
                'demo_products' => 15,
                'features' => array('Menu layouts', 'Allergen info', 'Delivery options', 'Opening hours'),
            ),
            'digital' => array(
                'name' => __('Digital Products', 'masterai-store-builder'),
                'icon' => 'dashicons-download',
                'description' => __('eBooks, templates, software, courses', 'masterai-store-builder'),
                'demo_products' => 8,
                'features' => array('Instant download', 'License keys', 'File versioning', 'Preview system'),
            ),
            'beauty' => array(
                'name' => __('Beauty & Wellness', 'masterai-store-builder'),
                'icon' => 'dashicons-heart',
                'description' => __('Skincare, makeup, and health products', 'masterai-store-builder'),
                'demo_products' => 10,
                'features' => array('Ingredient lists', 'Before/after', 'Skin quiz', 'Subscriptions'),
            ),
            'home' => array(
                'name' => __('Home & Decor', 'masterai-store-builder'),
                'icon' => 'dashicons-admin-home',
                'description' => __('Furniture, lighting, and home accessories', 'masterai-store-builder'),
                'demo_products' => 12,
                'features' => array('Room visualization', 'Bulk orders', 'Dimensions', 'Materials'),
            ),
            'courses' => array(
                'name' => __('Courses & Coaching', 'masterai-store-builder'),
                'icon' => 'dashicons-welcome-learn-more',
                'description' => __('Online courses, coaching, and memberships', 'masterai-store-builder'),
                'demo_products' => 6,
                'features' => array('Course curriculum', 'Booking calendar', 'Testimonials', 'Members area'),
            ),
            'handmade' => array(
                'name' => __('Art & Handmade', 'masterai-store-builder'),
                'icon' => 'dashicons-art',
                'description' => __('Crafts, artwork, and custom creations', 'masterai-store-builder'),
                'demo_products' => 10,
                'features' => array('Custom orders', 'Process photos', 'Artist bio', 'Commission requests'),
            ),
            'jewelry' => array(
                'name' => __('Jewelry & Watches', 'masterai-store-builder'),
                'icon' => 'dashicons-awards',
                'description' => __('Fine jewelry, watches, and accessories', 'masterai-store-builder'),
                'demo_products' => 8,
                'features' => array('360° view', 'Material details', 'Size guide', 'Gift packaging'),
            ),
            'services' => array(
                'name' => __('Services & Bookings', 'masterai-store-builder'),
                'icon' => 'dashicons-calendar-alt',
                'description' => __('Appointments, consultations, rentals', 'masterai-store-builder'),
                'demo_products' => 5,
                'features' => array('Booking calendar', 'Staff selection', 'Time slots', 'Deposits'),
            ),
            'industrial' => array(
                'name' => __('Industrial & Hardware', 'masterai-store-builder'),
                'icon' => 'dashicons-hammer',
                'description' => __('Parts, tools, and technical equipment', 'masterai-store-builder'),
                'demo_products' => 10,
                'features' => array('Advanced Search', 'Tolerance Filter', 'Material Guide', 'Bulk Pricing'),
            ),
            'electronics' => array(
                'name' => __('Electronics & Gadgets', 'masterai-store-builder'),
                'icon' => 'dashicons-smartphone',
                'description' => __('Computers, phones, and high-tech accessories', 'masterai-store-builder'),
                'demo_products' => 12,
                'features' => array('Technical specs', 'Compare products', 'Warranty info', 'Brand filters'),
            ),
            'pets' => array(
                'name' => __('Pet Supplies', 'masterai-store-builder'),
                'icon' => 'dashicons-pets',
                'description' => __('Food, toys, and accessories for your pets', 'masterai-store-builder'),
                'demo_products' => 10,
                'features' => array('Pet personality', 'Auto-ship', 'Pet sizes', 'Ingredient info'),
            ),
        );
    }
}
